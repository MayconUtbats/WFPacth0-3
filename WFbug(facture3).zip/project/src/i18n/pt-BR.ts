export const ptBR = {
  // ... existing translations ...
  
  stadium: {
    title: 'Estádio',
    description: 'Gerencie seu estádio e suas instalações',
    overview: 'Visão Geral',
    rename: 'Renomear',
    capacity: 'Capacidade',
    ticketPrice: 'Preço do Ingresso',
    maintenanceCost: 'Custo de Manutenção',
    rating: 'Avaliação',
    attendance: 'Ocupação',
    seats: 'lugares',
    level: 'nível',
    current: 'Atual',
    progress: 'Progresso',

    facilities: {
      title: 'Instalações',
      description: 'Melhore as instalações do seu estádio',
      level: 'Nível {{level}}',
      parking: 'Estacionamento',
      parkingDesc: 'Aumente a capacidade de estacionamento para os torcedores',
      shops: 'Lojas',
      shopsDesc: 'Lojas oficiais e pontos de venda de produtos do clube',
      food: 'Alimentação',
      foodDesc: 'Lanchonetes e restaurantes para os torcedores',
      vip: 'Área VIP',
      vipDesc: 'Camarotes e áreas exclusivas',
      screens: 'Telões',
      screensDesc: 'Telões para replay e informações',
      wifi: 'Wi-Fi',
      wifiDesc: 'Conectividade para os torcedores',
      accessibility: 'Acessibilidade',
      accessibilityDesc: 'Melhorias para acessibilidade',
      medical: 'Departamento Médico',
      medicalDesc: 'Atendimento médico e primeiros socorros'
    },

    upgrades: {
      title: 'Melhorias',
      description: 'Expanda e melhore seu estádio',
      capacity: 'Capacidade',
      capacityDesc: 'Aumente o número de lugares no estádio',
      comfort: 'Conforto',
      comfortDesc: 'Melhore a experiência dos torcedores'
    },

    maintenance: {
      title: 'Manutenção',
      status: 'Estado Atual',
      good: 'Bom',
      fair: 'Regular',
      poor: 'Ruim',
      routine: 'Manutenção de Rotina',
      routineDesc: 'Manutenção básica e limpeza',
      major: 'Manutenção Completa',
      majorDesc: 'Reforma geral das instalações',
      emergency: 'Manutenção Emergencial',
      emergencyDesc: 'Reparos urgentes necessários',
      improvement: 'melhoria',
      warning: 'O estádio precisa de manutenção urgente!'
    },

    stats: {
      title: 'Estatísticas',
      averageAttendance: 'Média de Público',
      seasonRevenue: 'Receita da Temporada',
      maintenanceCosts: 'Custos de Manutenção',
      recentMatches: 'Partidas Recentes'
    }
  }
};