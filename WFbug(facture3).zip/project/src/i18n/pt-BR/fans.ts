export const fans = {
  title: 'Torcida',
  description: 'Gerencie sua base de torcedores',

  overview: {
    title: 'Visão Geral',
    totalFans: 'Total de Torcedores',
    matchdayAttendance: 'Presença no Estádio',
    satisfaction: 'Satisfação',
    loyalty: 'Lealdade'
  },

  categories: {
    casual: 'Casuais',
    regular: 'Regulares',
    fanatic: 'Fanáticos'
  },

  demographics: {
    young: 'Jovens',
    adult: 'Adultos',
    senior: 'Seniores'
  },

  actions: {
    title: 'Ações',
    promotion: 'Campanha Promocional',
    event: 'Evento com Torcedores',
    socialMedia: 'Redes Sociais'
  },

  events: {
    title: 'Eventos',
    protest: 'Protesto',
    celebration: 'Celebração',
    support: 'Apoio',
    criticism: 'Crítica'
  },

  stats: {
    title: 'Estatísticas',
    growth: 'Crescimento',
    attendance: 'Público',
    revenue: 'Receita',
    satisfaction: 'Satisfação'
  }
};