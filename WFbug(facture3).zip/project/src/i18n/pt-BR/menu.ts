export const menu = {
  overview: 'Visão Geral',
  squad: 'Elenco',
  stadium: 'Estádio',
  youthAcademy: 'Base',
  fans: 'Torcida',
  finances: 'Finanças',
  freeAgents: 'Jogadores Livres',
  division: 'Divisão',
  transfers: 'Transferências',
  competitions: 'Competições',
};