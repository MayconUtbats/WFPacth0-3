import { auth } from './auth';
import { common } from './common';
import { menu } from './menu';
import { stadium } from './stadium';
import { academy } from './academy';
import { finances } from './finances';
import { fans } from './fans';

export const ptBR = {
  auth,
  common,
  menu,
  stadium,
  academy,
  finances,
  fans,
};