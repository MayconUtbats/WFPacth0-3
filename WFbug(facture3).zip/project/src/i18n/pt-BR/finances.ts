export const finances = {
  title: 'Finanças',
  description: 'Gestão financeira do clube',

  summary: {
    title: 'Resumo',
    balance: 'Saldo',
    monthlyIncome: 'Receita Mensal',
    monthlyExpenses: 'Despesas Mensais',
    monthlyBalance: 'Saldo Mensal'
  },

  income: {
    title: 'Receitas',
    description: 'Fontes de receita do clube',
    matchday: 'Bilheteria',
    sponsorship: 'Patrocínio',
    tvRights: 'Direitos de TV',
    total: 'Total'
  },

  expenses: {
    title: 'Despesas',
    description: 'Custos e despesas do clube',
    wages: 'Salários',
    facilities: 'Instalações',
    transfers: 'Transferências',
    other: 'Outros',
    total: 'Total'
  },

  transactions: {
    title: 'Transações',
    recent: 'Transações Recentes',
    date: 'Data',
    description: 'Descrição',
    amount: 'Valor',
    category: 'Categoria'
  }
};