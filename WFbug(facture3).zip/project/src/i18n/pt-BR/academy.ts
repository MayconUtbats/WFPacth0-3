export const academy = {
  title: 'Academia de Base',
  description: 'Gerencie os jovens talentos do seu clube',
  
  overview: {
    title: 'Visão Geral',
    description: 'Status atual da academia',
    totalPlayers: 'Total de Jogadores',
    averageAge: 'Média de Idade',
    potentialStars: 'Jogadores Promissores',
    graduationDate: 'Próxima Formatura'
  },

  facilities: {
    title: 'Instalações',
    description: 'Melhore as instalações da base',
    training: 'Centro de Treinamento',
    trainingDesc: 'Melhore a qualidade dos treinos',
    scouting: 'Departamento de Observação',
    scoutingDesc: 'Encontre talentos mais promissores',
    education: 'Centro Educacional',
    educationDesc: 'Desenvolva a formação dos jovens',
    medical: 'Departamento Médico',
    medicalDesc: 'Cuide da saúde dos atletas',
    level: 'Nível',
    upgrade: 'Melhorar',
    maxLevel: 'Nível Máximo Atingido'
  },

  training: {
    title: 'Treinamento',
    description: 'Desenvolva as habilidades dos jovens',
    schedule: 'Programação',
    intensity: 'Intensidade',
    focus: 'Foco',
    progress: 'Progresso',
    train: 'Treinar',
    rest: 'Descansar'
  },

  recruitment: {
    title: 'Recrutamento',
    description: 'Encontre novos talentos',
    scout: 'Observar',
    trials: 'Peneiras',
    network: 'Rede de Olheiros',
    regions: 'Regiões',
    cost: 'Custo',
    duration: 'Duração',
    success: 'Taxa de Sucesso',
    available: '{spots} vagas disponíveis',
    full: 'Academia Lotada',
    scoutLevel: 'Nível de Observação',
    nextGraduation: 'Próxima Formatura'
  },

  players: {
    title: 'Jogadores',
    name: 'Nome',
    age: 'Idade',
    position: 'Posição',
    potential: 'Potencial',
    development: 'Desenvolvimento',
    status: 'Status',
    actions: 'Ações',
    promote: 'Promover',
    release: 'Dispensar',
    graduate: 'Formar',
    contract: 'Contrato'
  },

  stats: {
    title: 'Estatísticas',
    players: 'Jogadores',
    graduates: 'Formados',
    success: 'Taxa de Sucesso',
    investment: 'Investimento',
    return: 'Retorno',
    level: 'Nível',
    reputation: 'Reputação',
    monthlyFee: 'Custo Mensal'
  }
};