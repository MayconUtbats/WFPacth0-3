```typescript
export interface Match {
  id: string;
  competition: string;
  homeTeam: string; // Team ID
  awayTeam: string; // Team ID
  date: Date;
  stadium: string;
  attendance: number;
  result?: MatchResult;
  events: MatchEvent[];
  stats: MatchStats;
  isPlayed: boolean;
}

export interface MatchResult {
  homeScore: number;
  awayScore: number;
  extraTime?: {
    homeScore: number;
    awayScore: number;
  };
  penalties?: {
    homeScore: number;
    awayScore: number;
  };
}

export interface MatchEvent {
  minute: number;
  type: 'goal' | 'card' | 'injury' | 'substitution' | 'chance';
  team: string;
  player: string;
  description: string;
  assistPlayer?: string;
}

export interface MatchStats {
  possession: number;
  shots: number;
  shotsOnTarget: number;
  corners: number;
  fouls: number;
  yellowCards: number;
  redCards: number;
  offsides: number;
  passes: number;
  passAccuracy: number;
}
```