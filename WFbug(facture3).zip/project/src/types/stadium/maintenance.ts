```typescript
export type MaintenanceType = 'routine' | 'major' | 'emergency';

export interface MaintenanceRecord {
  id: string;
  date: Date;
  type: MaintenanceType;
  cost: number;
  improvement: number;
}

export interface MaintenanceStats {
  totalSpent: number;
  lastMaintenance: Date;
  records: MaintenanceRecord[];
}
```