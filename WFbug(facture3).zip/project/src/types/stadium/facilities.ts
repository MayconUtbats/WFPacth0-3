```typescript
export interface StadiumFacilities {
  parking: number;
  shops: number;
  food: number;
  vip: number;
  screens: number;
  wifi: number;
  accessibility: number;
}

export interface FacilityUpgrade {
  currentLevel: number;
  maxLevel: number;
  cost: number;
  effect: {
    type: 'comfort' | 'revenue' | 'attendance';
    value: number;
  };
}
```