```typescript
export interface ContinentalCompetition {
  id: string;
  name: string;
  type: 'libertadores' | 'champions';
  teams: string[];
  groups: ContinentalGroup[];
  knockoutStages: KnockoutStage[];
  season: number;
  currentStage: 'group' | 'round_of_16' | 'quarter' | 'semi' | 'final';
  schedule: ContinentalSchedule;
}

export interface ContinentalGroup {
  id: string;
  name: string;
  teams: string[];
  matches: string[];
  standings: GroupStanding[];
}

export interface KnockoutStage {
  id: string;
  name: string;
  matches: string[];
  teams: string[];
  round: number;
  completed: boolean;
}

export interface GroupStanding {
  teamId: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
}

export interface ContinentalSchedule {
  groupStage: {
    startDate: Date;
    endDate: Date;
    matchdays: number[];
  };
  knockoutStage: {
    rounds: {
      name: string;
      firstLeg: Date;
      secondLeg: Date;
    }[];
  };
}
```