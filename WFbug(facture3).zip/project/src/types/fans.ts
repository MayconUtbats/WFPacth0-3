export interface FanBase {
  total: number;
  loyalty: number; // 0-100
  satisfaction: number; // 0-100
  matchdayAttendance: number;
  growth: {
    weekly: number;
    monthly: number;
    yearly: number;
  };
  categories: {
    casual: number;
    regular: number;
    fanatic: number;
  };
  demographics: {
    young: number; // 0-25 years
    adult: number; // 26-45 years
    senior: number; // 46+ years
  };
  losses: {
    natural: number; // Natural deaths
    inactive: number; // Lost interest
    total: number;
  };
}

export interface FanMood {
  overall: 'hostile' | 'unhappy' | 'neutral' | 'happy' | 'ecstatic';
  matchday: number; // 0-100
  season: number; // 0-100
  management: number; // 0-100
}

export interface FanEvent {
  id: string;
  type: 'protest' | 'celebration' | 'support' | 'criticism' | 'loss';
  description: string;
  impact: number; // -100 to 100
  date: Date;
}

export interface FanGrowthFactors {
  victories: number;
  trophies: number;
  starPlayers: number;
  marketingLevel: number;
  stadiumQuality: number;
  ticketPrices: number;
  leaguePosition: number;
}

export interface FanAgeingConfig {
  yearlyAgingRate: number; // Percentage of fans that age each year
  naturalDeathRate: number; // Percentage of senior fans that pass away each year
  inactivityRate: number; // Percentage of fans that become inactive each year
  youngReplacementRate: number; // Rate at which young fans replace lost fans
}