export interface PlayerStatistics {
  jogos: number;
  gols: number;
  assistencias: number;
  cartoes_amarelos: number;
  cartoes_vermelhos: number;
  media_notas: number;
  minutos_jogados: number;
  clean_sheets?: number;
}

export interface Player {
  id: string;
  name: string;
  position: 'GK' | 'DEF' | 'MID' | 'FWD';
  rating: number;
  stamina: number;
  salary: number;
}