```typescript
export interface League {
  id: string;
  name: string;
  country: string;
  division: number;
  teams: string[]; // Team IDs
  maxTeams: number;
  season: number;
  matches: string[]; // Match IDs
  standings: LeagueStanding[];
  schedule: LeagueSchedule;
  promotionSpots: number;
  relegationSpots: number;
}

export interface LeagueStanding {
  teamId: string;
  position: number;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
  form: ('W' | 'D' | 'L')[];
}

export interface LeagueSchedule {
  currentMatchday: number;
  totalMatchdays: number;
  fixtures: LeagueFixture[];
}

export interface LeagueFixture {
  id: string;
  matchday: number;
  homeTeamId: string;
  awayTeamId: string;
  date: Date;
  result?: {
    homeScore: number;
    awayScore: number;
  };
}
```