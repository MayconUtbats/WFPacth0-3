export interface Colors {
  primary: string;
  secondary: string;
  accent: string;
}

export interface ColorScheme {
  background: string;
  foreground: string;
  border: string;
  primary: ColorSet;
  secondary: ColorSet;
  accent: ColorSet;
}

export interface ColorSet {
  light: string;
  main: string;
  dark: string;
  contrast: string;
}