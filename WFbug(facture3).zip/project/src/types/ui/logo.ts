export interface Logo {
  shape: LogoShape;
  icon: LogoIcon;
  style: LogoStyle;
}

export type LogoShape = 
  | 'shield-classic'
  | 'shield-modern'
  | 'circle'
  | 'hexagon'
  | 'diamond'
  | 'pentagon'
  | 'star'
  | 'square';

export type LogoIcon =
  | 'trophy'
  | 'shield'
  | 'star'
  | 'crown'
  | 'sword'
  | 'flame'
  | 'mountain'
  | 'sun'
  | 'moon'
  | 'lightning'
  | 'flower'
  | 'rocket'
  | 'gem'
  | 'heart'
  | 'flag'
  | 'anchor'
  | 'compass'
  | 'target';

export type LogoStyle =
  | 'solid'
  | 'outline'
  | 'gradient'
  | 'modern'
  | 'retro'
  | 'minimalist'
  | 'metallic'
  | '3d';