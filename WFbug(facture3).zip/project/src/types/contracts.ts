import { Player } from './game';

export interface ContractOffer {
  id: string;
  playerId: string;
  teamId: string;
  baseSalary: number;
  duration: number;
  bonuses: ContractBonuses;
  clauses: ContractClauses;
  status: 'pending' | 'accepted' | 'rejected' | 'expired';
  createdAt: Date;
  expiresAt: Date;
}

export interface ContractBonuses {
  goalBonus: number;
  assistBonus: number;
  cleanSheetBonus: number;
  winBonus: number;
  titleBonus: number;
  appearanceBonus: number;
}

export interface ContractClauses {
  releaseClause?: number;
  minimumPlayingTime?: number;
  sellOnClause?: number;
  relegationReleaseClause?: boolean;
  championshipReleaseClause?: boolean;
}

export interface NegotiationCard {
  id: string;
  type: 'salary' | 'bonus' | 'clause' | 'duration';
  name: string;
  description: string;
  value: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  effect: NegotiationEffect;
}

export interface NegotiationEffect {
  target: keyof ContractOffer | keyof ContractBonuses | keyof ContractClauses;
  modifier: number;
  condition?: string;
}

export interface PlayerReputation {
  loyalty: number;
  consistency: number;
  professionalism: number;
  ambition: number;
  relationship: number;
}

export interface NegotiationState {
  currentOffer: ContractOffer;
  playerDemands: Partial<ContractOffer>;
  availableCards: NegotiationCard[];
  usedCards: NegotiationCard[];
  round: number;
  maxRounds: number;
  playerMood: 'happy' | 'neutral' | 'unhappy';
  lastAction: string;
}