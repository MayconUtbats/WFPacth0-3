import { Team } from '../core/team';
import { Player } from '../core/player';

export interface Match {
  id: string;
  competition: string;
  homeTeam: Team;
  awayTeam: Team;
  date: Date;
  venue: string;
  attendance: number;
  weather: Weather;
  result?: MatchResult;
  events: MatchEvent[];
  stats: MatchStats;
  tactics: TeamTactics;
}

// ... (rest of the match-related interfaces)