```typescript
export interface YouthAcademy {
  id: string;
  level: number;
  maxLevel: number;
  currentPlayers: YouthPlayer[];
  maxPlayers: number;
  monthlyFee: number;
  upgradeCost: number;
  nextGraduationDate: Date;
  facilities: AcademyFacilities;
}

export interface YouthPlayer {
  id: string;
  name: string;
  age: number;
  position: 'GK' | 'DEF' | 'MID' | 'FWD';
  potential: number;
  currentAbility: number;
  graduationDate: Date;
  monthlySalary: number;
  attributes: PlayerAttributes;
  development: PlayerDevelopment;
}

export interface AcademyFacilities {
  training: number;
  scouting: number;
  education: number;
  medical: number;
}

export interface PlayerAttributes {
  technical: number;
  physical: number;
  mental: number;
}

export interface PlayerDevelopment {
  progress: number;
  lastTrainingDate: Date;
  monthlyGrowth: number;
}
```