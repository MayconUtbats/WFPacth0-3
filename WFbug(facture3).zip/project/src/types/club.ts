export interface Club {
  id: string;
  name: string;
  shortName: string;
  country: string;
  league: string;
  division: number;
  founded: number;
  colors: ClubColors;
  logo: ClubLogo;
  players: string[]; // Player IDs
  staff: string[]; // Staff IDs
  facilities: ClubFacilities;
  finances: ClubFinances;
  reputation: ClubReputation;
}

export interface ClubColors {
  primary: string;
  secondary: string;
  accent: string;
}

export interface ClubLogo {
  shape: string;
  icon: string;
}

export interface ClubFacilities {
  stadium: {
    id: string;
    capacity: number;
    condition: number;
    facilities: number;
  };
  training: {
    level: number;
    condition: number;
    facilities: number;
  };
  youth: {
    level: number;
    facilities: number;
    recruitment: number;
  };
}

export interface ClubFinances {
  balance: number;
  income: {
    matchday: number;
    commercial: number;
    broadcasting: number;
    prizes: number;
  };
  expenses: {
    wages: number;
    facilities: number;
    transfers: number;
    other: number;
  };
  transferBudget: number;
  wageBudget: number;
}

export interface ClubReputation {
  domestic: number;
  continental: number;
  global: number;
  prestige: number;
  fanbase: number;
}