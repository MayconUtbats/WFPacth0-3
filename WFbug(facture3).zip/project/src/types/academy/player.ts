```typescript
export type YouthPosition = 'GK' | 'DEF' | 'MID' | 'FWD';

export interface YouthPlayer {
  id: string;
  name: string;
  age: number;
  position: YouthPosition;
  potential: number;
  currentAbility: number;
  graduationDate: Date;
  monthlySalary: number;
  attributes: PlayerAttributes;
  development: PlayerDevelopment;
}

export interface PlayerAttributes {
  technical: number;
  physical: number;
  mental: number;
}

export interface PlayerDevelopment {
  progress: number;
  lastTrainingDate: Date;
  monthlyGrowth: number;
}
```