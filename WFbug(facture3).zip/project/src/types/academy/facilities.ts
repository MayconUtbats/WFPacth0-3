```typescript
export interface AcademyFacilities {
  training: number;
  scouting: number;
  education: number;
  medical: number;
}

export interface FacilityUpgrade {
  currentLevel: number;
  maxLevel: number;
  cost: number;
  effect: {
    type: 'development' | 'scouting' | 'education' | 'medical';
    value: number;
  };
}
```