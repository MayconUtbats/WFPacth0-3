```typescript
export interface Stadium {
  id: string;
  name: string;
  capacity: number;
  currentAttendance: number;
  ticketPrice: number;
  maintenanceCost: number;
  expansionCost: number;
  comfort: number;
  maintenanceLevel: number;
  averageAttendance: number;
  seasonRevenue: number;
  maintenanceCosts: number;
  facilities: StadiumFacilities;
  stats: StadiumStats;
}

export interface StadiumFacilities {
  parking: number;
  shops: number;
  food: number;
  vip: number;
  screens: number;
  wifi: number;
  accessibility: number;
  medical: number;
}

export interface StadiumStats {
  totalAttendance: number;
  totalRevenue: number;
  matchesPlayed: number;
  sellouts: number;
  averageAttendance: number;
  highestAttendance: number;
  lowestAttendance: number;
  maintenanceHistory: MaintenanceRecord[];
}

export interface MaintenanceRecord {
  id: string;
  date: Date;
  type: 'routine' | 'major' | 'emergency';
  cost: number;
  improvement: number;
}
```