// Update TeamLogo interface
export interface TeamLogo {
  shape: string;
  icon: string;
  style: 'solid' | 'outline' | 'gradient' | 'modern' | 'retro' | 'minimalist' | 'metallic' | '3d';
}

export interface Team {
  id: string;
  name: string;
  shortName: string;
  country: string;
  league: string;
  division: number;
  founded: number;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  logo: TeamLogo;
  players: Player[];
  budget: number;
}

export interface Player {
  id: string;
  name: string;
  position: 'GK' | 'DEF' | 'MID' | 'FWD';
  rating: number;
  stamina: number;
  salary: number;
}