import { Player } from './game';

export interface MatchState {
  minute: number;
  homeScore: number;
  awayScore: number;
  possession: 'home' | 'away';
  homePossession: number;
  awayPossession: number;
  events: MatchEvent[];
  homeStats: TeamMatchStats;
  awayStats: TeamMatchStats;
  isHalfTime: boolean;
}

export interface MatchEvent {
  minute: number;
  type: 'goal' | 'chance' | 'card' | 'injury' | 'substitution' | 'buildup' | 'transition' | 'general';
  team: string;
  player: Player;
  description: string;
  assistPlayer?: Player;
}

export interface TeamMatchStats {
  shots: number;
  shotsOnTarget: number;
  possession: number;
  passes: number;
  passAccuracy: number;
  fouls: number;
  yellowCards: number;
  redCards: number;
  corners: number;
  offsides: number;
}

export interface MatchResult {
  homeScore: number;
  awayScore: number;
  events: MatchEvent[];
  stats: {
    home: TeamMatchStats;
    away: TeamMatchStats;
  };
  extraTime?: {
    homeScore: number;
    awayScore: number;
  };
  penalties?: {
    homeScore: number;
    awayScore: number;
  };
}

export interface TacticalSetup {
  formation: string;
  style: 'possession' | 'counter' | 'balanced' | 'direct';
  pressing: 'high' | 'medium' | 'low';
  mentality: 'defensive' | 'balanced' | 'attacking' | 'all-out';
}