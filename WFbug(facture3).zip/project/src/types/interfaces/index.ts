// Export all interfaces from a central location
export * from './academy.interface';
export * from './auth.interface';
export * from './club.interface';
export * from './competition.interface';
export * from './contract.interface';
export * from './fan.interface';
export * from './finance.interface';
export * from './game.interface';
export * from './match.interface';
export * from './player.interface';
export * from './stadium.interface';
export * from './transfer.interface';