interface PersonalityTrait {
  id: string;
  name: string;
  description: string;
  effects: {
    developmentRate?: number;
    moraleImpact?: number;
    teamworkImpact?: number;
    performanceImpact?: number;
  };
}

export interface PlayerPersonality {
  traits: PersonalityTrait[];
  ambition: number; // 1-100
  professionalism: number; // 1-100
  temperament: number; // 1-100
  loyalty: number; // 1-100
}

export const PERSONALITY_TRAITS: PersonalityTrait[] = [
  {
    id: 'ambitious',
    name: 'Ambicioso',
    description: 'Busca constantemente melhorar e alcançar objetivos maiores',
    effects: {
      developmentRate: 1.2,
      moraleImpact: -0.1,
    }
  },
  {
    id: 'professional',
    name: 'Profissional',
    description: 'Mantém alto nível de comprometimento e disciplina',
    effects: {
      developmentRate: 1.1,
      moraleImpact: 0.1,
      performanceImpact: 0.05,
    }
  },
  {
    id: 'leader',
    name: 'Líder',
    description: 'Influencia positivamente os companheiros de equipe',
    effects: {
      teamworkImpact: 0.2,
      moraleImpact: 0.1,
    }
  },
  {
    id: 'inconsistent',
    name: 'Inconstante',
    description: 'Alterna bons e maus momentos com frequência',
    effects: {
      performanceImpact: -0.1,
      moraleImpact: -0.05,
    }
  },
  {
    id: 'determined',
    name: 'Determinado',
    description: 'Mantém alto nível de foco e dedicação',
    effects: {
      developmentRate: 1.15,
      performanceImpact: 0.05,
    }
  },
];