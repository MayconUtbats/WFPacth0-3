export interface ScoutReport {
  id: string;
  playerId: string;
  scoutId: string;
  date: Date;
  accuracy: number; // 0-100
  attributes: {
    technical?: number;
    physical?: number;
    mental?: number;
  };
  potential?: number;
  notes?: string;
  confidence: 'low' | 'medium' | 'high';
}

export interface Scout {
  id: string;
  name: string;
  level: number; // 1-5
  specialization?: 'youth' | 'professional' | 'international';
  accuracy: number; // 0-100
  cost: number;
  region?: string[];
}

export interface ScoutingDepartment {
  scouts: Scout[];
  reports: ScoutReport[];
  budget: number;
  maxScouts: number;
}