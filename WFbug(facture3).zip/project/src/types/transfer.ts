export interface TransferListing {
  id: string;
  playerId: string;
  sellingTeamId: string;
  askingPrice: number;
  minimumPrice: number;
  listedDate: Date;
  expiryDate: Date;
  status: 'active' | 'completed' | 'expired' | 'cancelled';
}

export interface TransferOffer {
  id: string;
  listingId: string;
  buyingTeamId: string;
  offeredAmount: number;
  offerDate: Date;
  status: 'pending' | 'accepted' | 'rejected' | 'expired';
  includedPlayers?: string[]; // For player exchanges
}

export interface MarketValue {
  baseValue: number;
  ageMultiplier: number;
  performanceMultiplier: number;
  potentialMultiplier: number;
  contractMultiplier: number;
  finalValue: number;
}

export interface TransferRules {
  minValueMultiplier: number; // Minimum percentage of market value (e.g., 0.5 for 50%)
  maxValueMultiplier: number; // Maximum percentage of market value (e.g., 2 for 200%)
  transferTaxRate: number; // Percentage of transfer fee taken as tax
  minDaysBetweenTransfers: number; // Minimum days between transfers for the same player
  transferWindowOpen: boolean; // Whether the transfer window is currently open
}