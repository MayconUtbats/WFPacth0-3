export type Position = 'GK' | 'DEF' | 'MID' | 'FWD';

export interface Player {
  id: string;
  name: string;
  position: Position;
  age: number;
  nationality: string;
  rating: number;
  potential?: number;
  stamina: number;
  salary: number;
  value: number;
  contract: PlayerContract;
  attributes: PlayerAttributes;
  stats: PlayerStats;
  personality: PlayerPersonality;
  history: PlayerHistory[];
}

export interface PlayerContract {
  startDate: Date;
  endDate: Date;
  salary: number;
  releaseClause?: number;
  bonuses: ContractBonuses;
}

export interface ContractBonuses {
  appearance: number;
  goal: number;
  assist: number;
  cleanSheet: number;
  win: number;
  trophy: number;
}

export interface PlayerAttributes {
  technical: TechnicalAttributes;
  physical: PhysicalAttributes;
  mental: MentalAttributes;
  goalkeeper?: GoalkeeperAttributes;
}

// ... (rest of the player-related interfaces)