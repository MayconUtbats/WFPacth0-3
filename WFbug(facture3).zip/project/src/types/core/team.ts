import { Player } from './player';
import { Colors } from '../ui/colors';
import { Logo } from '../ui/logo';

export interface Team {
  id: string;
  name: string;
  shortName: string;
  country: string;
  city: string;
  region: string;
  league: string;
  division: number;
  founded: number;
  motto?: string;
  colors: Colors;
  logo: Logo;
  players: Player[];
  budget: number;
  reputation: TeamReputation;
  facilities: TeamFacilities;
}

export interface TeamReputation {
  domestic: number;
  continental: number;
  global: number;
  prestige: number;
  fanbase: number;
}

export interface TeamFacilities {
  training: FacilityLevel;
  youth: FacilityLevel;
  medical: FacilityLevel;
  scouting: FacilityLevel;
}

export interface FacilityLevel {
  level: number;
  condition: number;
  maxLevel: number;
  upgradeCost: number;
  maintenanceCost: number;
}