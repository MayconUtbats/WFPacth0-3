```typescript
import { create } from 'zustand';
import { YouthAcademy, YouthPlayer } from '../types/academy';
import { addMonths } from 'date-fns';
import { generatePlayerName } from '../utils/nameGenerator';

interface AcademyState {
  academy: YouthAcademy | null;
  initializeAcademy: () => void;
  generateYouthPlayer: () => void;
  trainPlayers: () => void;
  upgradeFacility: (facilityId: keyof YouthAcademy['facilities']) => void;
  graduatePlayer: (playerId: string) => void;
  dismissPlayer: (playerId: string) => void;
}

export const useAcademyStore = create<AcademyState>((set, get) => ({
  academy: null,

  initializeAcademy: () => {
    const newAcademy: YouthAcademy = {
      id: crypto.randomUUID(),
      level: 1,
      maxLevel: 5,
      currentPlayers: [],
      maxPlayers: 5,
      monthlyFee: 50000,
      upgradeCost: 1000000,
      nextGraduationDate: addMonths(new Date(), 3),
      facilities: {
        training: 1,
        scouting: 1,
        education: 1,
        medical: 1,
      },
    };
    set({ academy: newAcademy });
  },

  generateYouthPlayer: () => {
    const { academy } = get();
    if (!academy || academy.currentPlayers.length >= academy.maxPlayers) return;

    const newPlayer: YouthPlayer = {
      id: crypto.randomUUID(),
      name: generatePlayerName(),
      age: 15 + Math.floor(Math.random() * 4),
      position: ['GK', 'DEF', 'MID', 'FWD'][Math.floor(Math.random() * 4)],
      potential: 60 + Math.floor(Math.random() * 40),
      currentAbility: 40 + Math.floor(Math.random() * 20),
      graduationDate: addMonths(new Date(), 3),
      monthlySalary: 1000,
      attributes: {
        technical: 40 + Math.floor(Math.random() * 20),
        physical: 40 + Math.floor(Math.random() * 20),
        mental: 40 + Math.floor(Math.random() * 20),
      },
      development: {
        progress: 0,
        lastTrainingDate: new Date(),
        monthlyGrowth: 0,
      },
    };

    set(state => ({
      academy: state.academy ? {
        ...state.academy,
        currentPlayers: [...state.academy.currentPlayers, newPlayer],
      } : null,
    }));
  },

  trainPlayers: () => {
    set(state => ({
      academy: state.academy ? {
        ...state.academy,
        currentPlayers: state.academy.currentPlayers.map(player => ({
          ...player,
          currentAbility: Math.min(player.currentAbility + 1, player.potential),
          development: {
            ...player.development,
            progress: Math.min(player.development.progress + 10, 100),
            lastTrainingDate: new Date(),
          },
        })),
      } : null,
    }));
  },

  upgradeFacility: (facilityId) => {
    set(state => {
      if (!state.academy) return state;
      const currentLevel = state.academy.facilities[facilityId];
      if (currentLevel >= state.academy.level) return state;

      return {
        academy: {
          ...state.academy,
          facilities: {
            ...state.academy.facilities,
            [facilityId]: currentLevel + 1,
          },
        },
      };
    });
  },

  graduatePlayer: (playerId) => {
    set(state => ({
      academy: state.academy ? {
        ...state.academy,
        currentPlayers: state.academy.currentPlayers.filter(p => p.id !== playerId),
      } : null,
    }));
  },

  dismissPlayer: (playerId) => {
    set(state => ({
      academy: state.academy ? {
        ...state.academy,
        currentPlayers: state.academy.currentPlayers.filter(p => p.id !== playerId),
      } : null,
    }));
  },
}));
```