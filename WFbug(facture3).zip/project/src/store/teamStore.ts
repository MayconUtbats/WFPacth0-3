import { create } from 'zustand';
import { Team } from '../types/game';
import { exampleTeams } from '../data/exampleTeams';

interface TeamState {
  teams: Team[];
  selectedTeam: Team | null;
  selectTeam: (teamId: string) => void;
}

export const useTeamStore = create<TeamState>((set, get) => ({
  // Inicializa com os times de exemplo
  teams: exampleTeams,
  selectedTeam: null,

  selectTeam: (teamId) => {
    const team = get().teams.find(t => t.id === teamId);
    set({ selectedTeam: team || null });
  },
}));