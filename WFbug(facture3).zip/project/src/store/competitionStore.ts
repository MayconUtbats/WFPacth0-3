```typescript
import { create } from 'zustand';
import { ContinentalCompetition, KnockoutStage } from '../types/competition';
import { LEAGUE_CONFIG } from '../constants/leagues';
import { generateContinentalSchedule } from '../utils/competition/scheduler';
import { updateGroupStandings } from '../utils/competition/standings';

interface CompetitionState {
  continentalCompetitions: ContinentalCompetition[];
  initializeContinental: (type: 'libertadores' | 'champions', season: number) => void;
  addTeamToContinental: (competitionId: string, teamId: string) => void;
  updateMatchResult: (competitionId: string, matchId: string, homeScore: number, awayScore: number) => void;
  advanceToKnockoutStage: (competitionId: string) => void;
  getTeamCompetitions: (teamId: string) => ContinentalCompetition[];
}

export const useCompetitionStore = create<CompetitionState>((set, get) => ({
  continentalCompetitions: [],

  initializeContinental: (type, season) => {
    const competition: ContinentalCompetition = {
      id: crypto.randomUUID(),
      name: LEAGUE_CONFIG.CONTINENTAL[type].name,
      type,
      teams: [],
      groups: [],
      knockoutStages: [],
      season,
      currentStage: 'group',
      schedule: generateContinentalSchedule(season),
    };

    set(state => ({
      continentalCompetitions: [...state.continentalCompetitions, competition]
    }));
  },

  addTeamToContinental: (competitionId, teamId) => {
    set(state => ({
      continentalCompetitions: state.continentalCompetitions.map(comp => {
        if (comp.id !== competitionId) return comp;

        // Add team to a group with space
        const availableGroup = comp.groups.find(g => g.teams.length < 4);
        if (!availableGroup) return comp;

        const updatedGroup = {
          ...availableGroup,
          teams: [...availableGroup.teams, teamId]
        };

        return {
          ...comp,
          teams: [...comp.teams, teamId],
          groups: comp.groups.map(g => 
            g.id === availableGroup.id ? updatedGroup : g
          )
        };
      })
    }));
  },

  updateMatchResult: (competitionId, matchId, homeScore, awayScore) => {
    set(state => ({
      continentalCompetitions: state.continentalCompetitions.map(comp => {
        if (comp.id !== competitionId) return comp;

        // Update match result and standings
        if (comp.currentStage === 'group') {
          const updatedGroups = comp.groups.map(group => {
            const matchIndex = group.matches.indexOf(matchId);
            if (matchIndex === -1) return group;

            const updatedMatches = [...group.matches];
            updatedMatches[matchIndex] = {
              ...updatedMatches[matchIndex],
              result: { homeScore, awayScore }
            };

            return {
              ...group,
              matches: updatedMatches,
              standings: updateGroupStandings(updatedMatches, group.teams)
            };
          });

          return { ...comp, groups: updatedGroups };
        } else {
          // Update knockout match
          const updatedStages = comp.knockoutStages.map(stage => ({
            ...stage,
            matches: stage.matches.map(match => 
              match.id === matchId
                ? { ...match, result: { homeScore, awayScore } }
                : match
            )
          }));

          return { ...comp, knockoutStages: updatedStages };
        }
      })
    }));
  },

  advanceToKnockoutStage: (competitionId) => {
    set(state => ({
      continentalCompetitions: state.continentalCompetitions.map(comp => {
        if (comp.id !== competitionId) return comp;

        // Get qualified teams from groups
        const qualifiedTeams = comp.groups.flatMap(group => 
          group.standings
            .slice(0, 2) // Top 2 from each group
            .map(standing => standing.teamId)
        );

        // Create knockout stages
        const knockoutStages: KnockoutStage[] = [
          {
            id: crypto.randomUUID(),
            name: 'Oitavas de Final',
            matches: [],
            teams: qualifiedTeams,
            round: 1,
            completed: false,
          },
          {
            id: crypto.randomUUID(),
            name: 'Quartas de Final',
            matches: [],
            teams: [],
            round: 2,
            completed: false,
          },
          {
            id: crypto.randomUUID(),
            name: 'Semifinal',
            matches: [],
            teams: [],
            round: 3,
            completed: false,
          },
          {
            id: crypto.randomUUID(),
            name: 'Final',
            matches: [],
            teams: [],
            round: 4,
            completed: false,
          },
        ];

        return {
          ...comp,
          currentStage: 'round_of_16',
          knockoutStages,
        };
      })
    }));
  },

  getTeamCompetitions: (teamId) => {
    return get().continentalCompetitions.filter(comp =>
      comp.teams.includes(teamId)
    );
  },
}));
```