import { create } from 'zustand';
import { FanBase, FanMood, FanEvent, FanGrowthFactors } from '../types/fans';
import { distributeNewFans } from '../utils/fans/ageing';

interface FanState {
  fanBase: FanBase;
  mood: FanMood;
  events: FanEvent[];
  updateFanBase: (factors: Partial<FanGrowthFactors>) => void;
  updateMood: (factors: Partial<Record<keyof FanMood, number>>) => void;
  addEvent: (event: Omit<FanEvent, 'id' | 'date'>) => void;
  calculateMatchdayAttendance: (ticketPrice: number, matchImportance: number) => number;
}

const initialDemographics = distributeNewFans(1000); // Start with 1000 fans

const initialFanBase: FanBase = {
  total: 1000,
  loyalty: 50,
  satisfaction: 50,
  matchdayAttendance: 0,
  growth: {
    weekly: 0,
    monthly: 0,
    yearly: 0
  },
  categories: {
    casual: 500, // 50%
    regular: 300, // 30%
    fanatic: 200  // 20%
  },
  demographics: {
    young: initialDemographics.young,
    adult: initialDemographics.adult,
    senior: initialDemographics.senior
  },
  losses: {
    natural: 0,
    inactive: 0,
    total: 0
  }
};

const initialMood: FanMood = {
  overall: 'neutral',
  matchday: 50,
  season: 50,
  management: 50
};

export const useFanStore = create<FanState>((set, get) => ({
  fanBase: initialFanBase,
  mood: initialMood,
  events: [],

  updateFanBase: (factors) => {
    set((state) => {
      const growth = calculateFanGrowth(factors);
      const newTotal = state.fanBase.total + growth;
      const newDemographics = distributeNewFans(newTotal);

      return {
        fanBase: {
          ...state.fanBase,
          total: newTotal,
          categories: distributeNewFans(newTotal),
          demographics: newDemographics,
          growth: {
            weekly: growth,
            monthly: state.fanBase.growth.monthly + growth,
            yearly: state.fanBase.growth.yearly + growth
          }
        }
      };
    });
  },

  updateMood: (factors) => {
    set((state) => {
      const newMood = { ...state.mood };
      
      Object.entries(factors).forEach(([key, value]) => {
        if (key !== 'overall') {
          newMood[key] = Math.max(0, Math.min(100, value));
        }
      });

      // Calculate overall mood based on all factors
      const moodAverage = (newMood.matchday + newMood.season + newMood.management) / 3;
      newMood.overall = getMoodLevel(moodAverage);

      return { mood: newMood };
    });
  },

  addEvent: (event) => {
    set((state) => ({
      events: [
        {
          ...event,
          id: crypto.randomUUID(),
          date: new Date()
        },
        ...state.events
      ]
    }));
  },

  calculateMatchdayAttendance: (ticketPrice: number, matchImportance: number) => {
    const state = get();
    const baseAttendance = state.fanBase.total * 0.3; // Base 30% attendance
    const moodFactor = state.mood.matchday / 100;
    const priceFactor = Math.max(0, 1 - (ticketPrice / 100)); // Higher prices reduce attendance
    const importanceFactor = (matchImportance + 100) / 200; // 0-100 scale to 0.5-1 factor

    const attendance = Math.floor(
      baseAttendance * moodFactor * priceFactor * importanceFactor
    );

    set((state) => ({
      fanBase: {
        ...state.fanBase,
        matchdayAttendance: attendance
      }
    }));

    return attendance;
  }
}));

function calculateFanGrowth(factors: Partial<FanGrowthFactors>): number {
  let growth = 0;

  if (factors.victories) growth += factors.victories * 100;
  if (factors.trophies) growth += factors.trophies * 1000;
  if (factors.starPlayers) growth += factors.starPlayers * 200;
  if (factors.marketingLevel) growth += factors.marketingLevel * 50;
  if (factors.stadiumQuality) growth += Math.floor(factors.stadiumQuality * 20);
  if (factors.leaguePosition) {
    // Higher positions give more growth
    growth += Math.max(0, (20 - factors.leaguePosition) * 100);
  }

  // Ticket prices can reduce growth if too high
  if (factors.ticketPrices) {
    const priceImpact = Math.max(0, 1 - (factors.ticketPrices / 100));
    growth *= priceImpact;
  }

  return Math.floor(growth);
}

function getMoodLevel(average: number): FanMood['overall'] {
  if (average >= 80) return 'ecstatic';
  if (average >= 60) return 'happy';
  if (average >= 40) return 'neutral';
  if (average >= 20) return 'unhappy';
  return 'hostile';
}