import { create } from 'zustand';
import { addDays } from 'date-fns';

interface FinanceState {
  balance: number;
  income: {
    matchday: number;
    commercial: number;
    broadcasting: number;
    prizes: number;
  };
  expenses: {
    wages: number;
    facilities: number;
    transfers: number;
    other: number;
  };
  transactions: Transaction[];
  addTransaction: (transaction: Transaction) => void;
  updateBalance: (amount: number) => void;
  updateIncome: (category: keyof FinanceState['income'], amount: number) => void;
  updateExpenses: (category: keyof FinanceState['expenses'], amount: number) => void;
}

interface Transaction {
  id: string;
  date: Date;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
}

export const useFinanceStore = create<FinanceState>((set) => ({
  balance: 1000000, // Initial balance
  income: {
    matchday: 0,
    commercial: 0,
    broadcasting: 0,
    prizes: 0,
  },
  expenses: {
    wages: 0,
    facilities: 0,
    transfers: 0,
    other: 0,
  },
  transactions: [],

  addTransaction: (transaction) => 
    set((state) => ({
      transactions: [transaction, ...state.transactions],
      balance: state.balance + (transaction.type === 'income' ? transaction.amount : -transaction.amount),
    })),

  updateBalance: (amount) => 
    set((state) => ({ balance: state.balance + amount })),

  updateIncome: (category, amount) =>
    set((state) => ({
      income: {
        ...state.income,
        [category]: state.income[category] + amount,
      },
    })),

  updateExpenses: (category, amount) =>
    set((state) => ({
      expenses: {
        ...state.expenses,
        [category]: state.expenses[category] + amount,
      },
    })),
}));