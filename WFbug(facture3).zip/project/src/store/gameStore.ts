import { create } from 'zustand';
import { GameState, Team } from '../types/game';
import { generateDefaultPlayers } from '../utils/player/generation';

export const useGameStore = create<GameState>((set, get) => ({
  currentTeam: null,
  currentDate: new Date(2024, 0, 1),
  matches: [],
  season: {
    leaguePosition: 0,
    points: 0,
    gamesPlayed: 0,
  },

  setTeam: (team) => {
    const players = generateDefaultPlayers(team.id);
    const enrichedTeam = { ...team, players };
    set({ currentTeam: enrichedTeam });
  },

  // ... rest of the store implementation
}));