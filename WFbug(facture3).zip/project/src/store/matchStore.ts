```typescript
import { create } from 'zustand';
import { Match, MatchResult } from '../types/match';
import { simulateMatch } from '../utils/match/simulation';
import { generateMatchEvents } from '../utils/match/events';
import { calculateMatchStats } from '../utils/match/stats';

interface MatchState {
  matches: Match[];
  currentMatch: Match | null;
  addMatch: (match: Match) => void;
  playMatch: (matchId: string) => void;
  getTeamMatches: (teamId: string) => Match[];
  getMatchDetails: (matchId: string) => Match | null;
}

export const useMatchStore = create<MatchState>((set, get) => ({
  matches: [],
  currentMatch: null,

  addMatch: (match) => {
    set(state => ({
      matches: [...state.matches, match]
    }));
  },

  playMatch: (matchId) => {
    const { matches } = get();
    const match = matches.find(m => m.id === matchId);
    if (!match || match.isPlayed) return;

    const result = simulateMatch(match);
    const events = generateMatchEvents(match, result);
    const stats = calculateMatchStats(events);

    set(state => ({
      matches: state.matches.map(m => 
        m.id === matchId
          ? {
              ...m,
              result,
              events,
              stats,
              isPlayed: true,
            }
          : m
      ),
      currentMatch: match,
    }));
  },

  getTeamMatches: (teamId) => {
    return get().matches.filter(m => 
      m.homeTeam === teamId || m.awayTeam === teamId
    );
  },

  getMatchDetails: (matchId) => {
    return get().matches.find(m => m.id === matchId) || null;
  },
}));
```