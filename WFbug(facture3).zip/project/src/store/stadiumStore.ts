```typescript
import { create } from 'zustand';
import { Stadium, StadiumFacilities } from '../types/stadium';
import { STADIUM_CONFIG } from '../constants/stadium';
import { calculateExpansionCost, calculateMaintenanceCost } from '../utils/stadium/calculations';

interface StadiumState {
  stadium: Stadium | null;
  initializeStadium: (teamId: string, teamName: string) => void;
  expandStadium: () => boolean;
  setTicketPrice: (price: number) => void;
  updateAttendance: (attendance: number) => void;
  performMaintenance: (type: 'routine' | 'major' | 'emergency') => boolean;
  upgradeFacility: (facilityId: keyof StadiumFacilities) => boolean;
}

export const useStadiumStore = create<StadiumState>((set, get) => ({
  stadium: null,

  initializeStadium: (teamId: string, teamName: string) => {
    const initialCapacity = STADIUM_CONFIG.INITIAL_CAPACITY;
    const newStadium: Stadium = {
      id: `stadium_${teamId}`,
      name: `${teamName} Stadium`,
      capacity: initialCapacity,
      currentAttendance: 0,
      ticketPrice: 20,
      maintenanceCost: calculateMaintenanceCost(initialCapacity),
      expansionCost: calculateExpansionCost(initialCapacity),
      comfort: 1,
      maintenanceLevel: 100,
      averageAttendance: 0,
      seasonRevenue: 0,
      maintenanceCosts: 0,
      facilities: {
        parking: 1,
        shops: 1,
        food: 1,
        vip: 1,
        screens: 1,
        wifi: 1,
        accessibility: 1,
        medical: 1
      },
      stats: {
        totalAttendance: 0,
        totalRevenue: 0,
        matchesPlayed: 0,
        sellouts: 0,
        averageAttendance: 0,
        highestAttendance: 0,
        lowestAttendance: initialCapacity,
        maintenanceHistory: []
      }
    };

    set({ stadium: newStadium });
  },

  expandStadium: () => {
    const stadium = get().stadium;
    if (!stadium) return false;

    if (stadium.capacity >= STADIUM_CONFIG.MAX_CAPACITY) {
      return false;
    }

    const newCapacity = stadium.capacity + STADIUM_CONFIG.EXPANSION_STEP;
    const newExpansionCost = calculateExpansionCost(newCapacity);

    set({
      stadium: {
        ...stadium,
        capacity: newCapacity,
        expansionCost: newExpansionCost,
        maintenanceCost: calculateMaintenanceCost(newCapacity)
      }
    });

    return true;
  },

  setTicketPrice: (price: number) => {
    const stadium = get().stadium;
    if (!stadium) return;

    set({
      stadium: {
        ...stadium,
        ticketPrice: Math.max(0, price)
      }
    });
  },

  updateAttendance: (attendance: number) => {
    const stadium = get().stadium;
    if (!stadium) return;

    const newAttendance = Math.min(attendance, stadium.capacity);
    const matchRevenue = newAttendance * stadium.ticketPrice;

    set({
      stadium: {
        ...stadium,
        currentAttendance: newAttendance,
        stats: {
          ...stadium.stats,
          totalAttendance: stadium.stats.totalAttendance + newAttendance,
          totalRevenue: stadium.stats.totalRevenue + matchRevenue,
          matchesPlayed: stadium.stats.matchesPlayed + 1,
          sellouts: newAttendance === stadium.capacity ? stadium.stats.sellouts + 1 : stadium.stats.sellouts,
          averageAttendance: Math.round((stadium.stats.totalAttendance + newAttendance) / (stadium.stats.matchesPlayed + 1)),
          highestAttendance: Math.max(stadium.stats.highestAttendance, newAttendance),
          lowestAttendance: Math.min(stadium.stats.lowestAttendance, newAttendance)
        }
      }
    });
  },

  performMaintenance: (type: 'routine' | 'major' | 'emergency') => {
    const stadium = get().stadium;
    if (!stadium) return false;

    const maintenanceConfig = STADIUM_CONFIG.MAINTENANCE.TYPES[type];
    const maintenanceRecord = {
      id: crypto.randomUUID(),
      date: new Date(),
      type,
      cost: maintenanceConfig.cost,
      improvement: maintenanceConfig.improvement
    };

    const newMaintenanceLevel = Math.min(
      STADIUM_CONFIG.MAINTENANCE.MAX_LEVEL,
      stadium.maintenanceLevel + maintenanceConfig.improvement
    );

    set({
      stadium: {
        ...stadium,
        maintenanceLevel: newMaintenanceLevel,
        stats: {
          ...stadium.stats,
          maintenanceHistory: [...stadium.stats.maintenanceHistory, maintenanceRecord]
        }
      }
    });

    return true;
  },

  upgradeFacility: (facilityId: keyof StadiumFacilities) => {
    const stadium = get().stadium;
    if (!stadium) return false;

    const currentLevel = stadium.facilities[facilityId];
    if (currentLevel >= STADIUM_CONFIG.FACILITY_MAX_LEVEL) return false;

    set({
      stadium: {
        ...stadium,
        facilities: {
          ...stadium.facilities,
          [facilityId]: currentLevel + 1
        }
      }
    });

    return true;
  }
}));
```