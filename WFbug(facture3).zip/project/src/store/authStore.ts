import { create } from 'zustand';
import { AuthState, LoginCredentials, RegisterCredentials, User } from '../types/auth';

interface AuthStore extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (credentials: RegisterCredentials) => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  isAuthenticated: false,

  login: async (credentials) => {
    // Simulate API call
    const user: User = {
      id: '1',
      email: credentials.email,
      username: credentials.email.split('@')[0],
      createdAt: new Date(),
    };

    set({ user, isAuthenticated: true });
  },

  register: async (credentials) => {
    // Simulate API call
    const user: User = {
      id: '1',
      email: credentials.email,
      username: credentials.username,
      createdAt: new Date(),
    };

    set({ user, isAuthenticated: true });
  },

  logout: () => {
    set({ user: null, isAuthenticated: false });
  },
}));