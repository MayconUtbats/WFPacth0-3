import { create } from 'zustand';
import { Scout, ScoutReport, ScoutingDepartment } from '../types/scouting';
import { generatePlayerName } from '../utils/nameGenerator';

interface ScoutingState {
  department: ScoutingDepartment;
  initializeDepartment: () => void;
  hireScout: (scout: Scout) => boolean;
  fireScout: (scoutId: string) => void;
  scoutPlayer: (playerId: string, scoutId: string) => ScoutReport;
  getScoutReport: (playerId: string) => ScoutReport | undefined;
  upgradeScout: (scoutId: string) => boolean;
}

const INITIAL_SCOUTS: Scout[] = [
  {
    id: '1',
    name: generatePlayerName(),
    level: 1,
    accuracy: 70,
    cost: 5000,
    specialization: 'professional'
  }
];

export const useScoutingStore = create<ScoutingState>((set, get) => ({
  department: {
    scouts: [],
    reports: [],
    budget: 100000,
    maxScouts: 3
  },

  initializeDepartment: () => {
    set({
      department: {
        scouts: INITIAL_SCOUTS,
        reports: [],
        budget: 100000,
        maxScouts: 3
      }
    });
  },

  hireScout: (scout) => {
    const { department } = get();
    if (department.scouts.length >= department.maxScouts) return false;
    if (department.budget < scout.cost) return false;

    set({
      department: {
        ...department,
        scouts: [...department.scouts, scout],
        budget: department.budget - scout.cost
      }
    });
    return true;
  },

  fireScout: (scoutId) => {
    const { department } = get();
    set({
      department: {
        ...department,
        scouts: department.scouts.filter(s => s.id !== scoutId)
      }
    });
  },

  scoutPlayer: (playerId, scoutId) => {
    const { department } = get();
    const scout = department.scouts.find(s => s.id === scoutId);
    if (!scout) throw new Error('Scout not found');

    const report: ScoutReport = {
      id: crypto.randomUUID(),
      playerId,
      scoutId,
      date: new Date(),
      accuracy: Math.min(100, scout.accuracy + Math.random() * 10),
      attributes: {
        technical: Math.floor(Math.random() * 100),
        physical: Math.floor(Math.random() * 100),
        mental: Math.floor(Math.random() * 100)
      },
      potential: scout.level >= 3 ? Math.floor(Math.random() * 100) : undefined,
      confidence: scout.level >= 4 ? 'high' : scout.level >= 2 ? 'medium' : 'low'
    };

    set({
      department: {
        ...department,
        reports: [...department.reports, report]
      }
    });

    return report;
  },

  getScoutReport: (playerId) => {
    const { department } = get();
    return department.reports.find(r => r.playerId === playerId);
  },

  upgradeScout: (scoutId) => {
    const { department } = get();
    const scout = department.scouts.find(s => s.id === scoutId);
    if (!scout || scout.level >= 5) return false;

    const upgradeCost = 10000 * scout.level;
    if (department.budget < upgradeCost) return false;

    set({
      department: {
        ...department,
        scouts: department.scouts.map(s => 
          s.id === scoutId 
            ? { 
                ...s, 
                level: s.level + 1,
                accuracy: Math.min(100, s.accuracy + 5)
              }
            : s
        ),
        budget: department.budget - upgradeCost
      }
    });
    return true;
  }
}));