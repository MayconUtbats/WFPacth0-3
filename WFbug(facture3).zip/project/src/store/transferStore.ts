import { create } from 'zustand';
import { TransferListing, TransferOffer, TransferRules } from '../types/transfer';
import { Player } from '../types/game';
import { validateTransferOffer } from '../utils/transfer/validation';
import { calculateMarketValue } from '../utils/transfer/marketValue';
import { useGameStore } from './gameStore';

interface TransferState {
  listings: TransferListing[];
  offers: TransferOffer[];
  freeAgents: Player[];
  rules: TransferRules;
  createListing: (playerId: string, askingPrice: number) => TransferListing | null;
  makeOffer: (listingId: string, amount: number) => TransferOffer | null;
  acceptOffer: (offerId: string) => boolean;
  rejectOffer: (offerId: string) => void;
  cancelListing: (listingId: string) => void;
  getPlayerOffers: (playerId: string) => TransferOffer[];
  getPlayerListing: (playerId: string) => TransferListing | null;
  makeContractOffer: (playerId: string) => void;
  addFreeAgent: (player: Player) => void;
  removeFreeAgent: (playerId: string) => void;
}

const DEFAULT_RULES: TransferRules = {
  minValueMultiplier: 0.5,
  maxValueMultiplier: 2.0,
  transferTaxRate: 0.05,
  minDaysBetweenTransfers: 30,
  transferWindowOpen: true,
};

// Sample free agents for testing
const initialFreeAgents: Player[] = [
  {
    id: 'fa1',
    name: 'João Silva',
    position: 'FWD',
    age: 28,
    rating: 75,
    stamina: 85,
    salary: 15000,
    lastClub: 'FC Porto'
  },
  {
    id: 'fa2',
    name: 'Pedro Santos',
    position: 'MID',
    age: 24,
    rating: 72,
    stamina: 88,
    salary: 12000,
    lastClub: 'Sporting CP'
  },
  {
    id: 'fa3',
    name: 'Carlos Oliveira',
    position: 'DEF',
    age: 31,
    rating: 77,
    stamina: 82,
    salary: 18000,
    lastClub: 'Benfica'
  }
];

export const useTransferStore = create<TransferState>((set, get) => ({
  listings: [],
  offers: [],
  freeAgents: initialFreeAgents,
  rules: DEFAULT_RULES,

  createListing: (playerId, askingPrice) => {
    const gameStore = useGameStore.getState();
    const player = gameStore.currentTeam?.players.find(p => p.id === playerId);
    
    if (!player) return null;

    const marketValue = calculateMarketValue(player);
    
    if (askingPrice < marketValue.finalValue * get().rules.minValueMultiplier ||
        askingPrice > marketValue.finalValue * get().rules.maxValueMultiplier) {
      return null;
    }

    const listing: TransferListing = {
      id: crypto.randomUUID(),
      playerId,
      sellingTeamId: gameStore.currentTeam!.id,
      askingPrice,
      minimumPrice: marketValue.finalValue * get().rules.minValueMultiplier,
      listedDate: new Date(),
      expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      status: 'active',
    };

    set(state => ({
      listings: [...state.listings, listing]
    }));

    return listing;
  },

  makeOffer: (listingId, amount) => {
    const listing = get().listings.find(l => l.id === listingId);
    if (!listing || listing.status !== 'active') return null;

    const gameStore = useGameStore.getState();
    const buyingTeam = gameStore.currentTeam;
    if (!buyingTeam) return null;

    const offer: TransferOffer = {
      id: crypto.randomUUID(),
      listingId,
      buyingTeamId: buyingTeam.id,
      offeredAmount: amount,
      offerDate: new Date(),
      status: 'pending',
    };

    set(state => ({
      offers: [...state.offers, offer]
    }));

    return offer;
  },

  acceptOffer: (offerId) => {
    const offer = get().offers.find(o => o.id === offerId);
    if (!offer || offer.status !== 'pending') return false;

    set(state => ({
      offers: state.offers.map(o =>
        o.id === offerId ? { ...o, status: 'accepted' } : o
      ),
      listings: state.listings.map(l =>
        l.id === offer.listingId ? { ...l, status: 'completed' } : l
      )
    }));

    return true;
  },

  rejectOffer: (offerId) => {
    set(state => ({
      offers: state.offers.map(o =>
        o.id === offerId ? { ...o, status: 'rejected' } : o
      )
    }));
  },

  cancelListing: (listingId) => {
    set(state => ({
      listings: state.listings.map(l =>
        l.id === listingId ? { ...l, status: 'cancelled' } : l
      ),
      offers: state.offers.map(o =>
        o.listingId === listingId ? { ...o, status: 'expired' } : o
      )
    }));
  },

  getPlayerOffers: (playerId) => {
    const listing = get().listings.find(l => 
      l.playerId === playerId && l.status === 'active'
    );
    if (!listing) return [];

    return get().offers.filter(o => 
      o.listingId === listing.id && o.status === 'pending'
    );
  },

  getPlayerListing: (playerId) => {
    return get().listings.find(l => 
      l.playerId === playerId && l.status === 'active'
    ) || null;
  },

  makeContractOffer: (playerId) => {
    const player = get().freeAgents.find(p => p.id === playerId);
    if (!player) return;

    // TODO: Implement contract negotiation logic
    console.log(`Making contract offer to player ${player.name}`);
  },

  addFreeAgent: (player) => {
    set(state => ({
      freeAgents: [...state.freeAgents, player]
    }));
  },

  removeFreeAgent: (playerId) => {
    set(state => ({
      freeAgents: state.freeAgents.filter(p => p.id !== playerId)
    }));
  }
}));