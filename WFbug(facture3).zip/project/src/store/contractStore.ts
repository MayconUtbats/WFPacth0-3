import { create } from 'zustand';
import { ContractOffer, NegotiationCard, NegotiationState, PlayerReputation } from '../types/contracts';
import { Player } from '../types/game';

interface ContractStore {
  activeNegotiations: Map<string, NegotiationState>;
  contractOffers: ContractOffer[];
  negotiationCards: NegotiationCard[];
  startNegotiation: (player: Player) => void;
  makeOffer: (playerId: string, offer: Partial<ContractOffer>) => void;
  useCard: (negotiationId: string, cardId: string) => void;
  acceptOffer: (offerId: string) => void;
  rejectOffer: (offerId: string) => void;
  calculateInitialDemands: (player: Player) => Partial<ContractOffer>;
}

export const useContractStore = create<ContractStore>((set, get) => ({
  activeNegotiations: new Map(),
  contractOffers: [],
  negotiationCards: [],

  startNegotiation: (player) => {
    const negotiationId = crypto.randomUUID();
    const initialDemands = get().calculateInitialDemands(player);
    
    const initialState: NegotiationState = {
      currentOffer: {
        id: crypto.randomUUID(),
        playerId: player.id,
        teamId: '',
        baseSalary: 0,
        duration: 0,
        bonuses: {
          goalBonus: 0,
          assistBonus: 0,
          cleanSheetBonus: 0,
          winBonus: 0,
          titleBonus: 0,
          appearanceBonus: 0
        },
        clauses: {},
        status: 'pending',
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      },
      playerDemands: initialDemands,
      availableCards: [],
      usedCards: [],
      round: 1,
      maxRounds: 5,
      playerMood: 'neutral',
      lastAction: 'Negotiation started'
    };

    set(state => ({
      activeNegotiations: new Map(state.activeNegotiations).set(negotiationId, initialState)
    }));
  },

  makeOffer: (playerId, offer) => {
    set(state => ({
      contractOffers: [
        ...state.contractOffers,
        {
          ...offer,
          id: crypto.randomUUID(),
          playerId,
          status: 'pending',
          createdAt: new Date(),
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
        }
      ]
    }));
  },

  useCard: (negotiationId, cardId) => {
    const negotiation = get().activeNegotiations.get(negotiationId);
    if (!negotiation) return;

    const card = negotiation.availableCards.find(c => c.id === cardId);
    if (!card) return;

    // Apply card effect
    const updatedOffer = applyCardEffect(negotiation.currentOffer, card);
    const updatedCards = negotiation.availableCards.filter(c => c.id !== cardId);

    set(state => ({
      activeNegotiations: new Map(state.activeNegotiations).set(negotiationId, {
        ...negotiation,
        currentOffer: updatedOffer,
        availableCards: updatedCards,
        usedCards: [...negotiation.usedCards, card],
        lastAction: `Used card: ${card.name}`
      })
    }));
  },

  acceptOffer: (offerId) => {
    set(state => ({
      contractOffers: state.contractOffers.map(offer =>
        offer.id === offerId ? { ...offer, status: 'accepted' } : offer
      )
    }));
  },

  rejectOffer: (offerId) => {
    set(state => ({
      contractOffers: state.contractOffers.map(offer =>
        offer.id === offerId ? { ...offer, status: 'rejected' } : offer
      )
    }));
  },

  calculateInitialDemands: (player) => {
    const baseSalary = calculateBaseSalary(player);
    const duration = calculateContractDuration(player);
    
    return {
      baseSalary,
      duration,
      bonuses: {
        goalBonus: Math.round(baseSalary * 0.1),
        assistBonus: Math.round(baseSalary * 0.05),
        cleanSheetBonus: Math.round(baseSalary * 0.1),
        winBonus: Math.round(baseSalary * 0.02),
        titleBonus: Math.round(baseSalary * 0.5),
        appearanceBonus: Math.round(baseSalary * 0.01)
      },
      clauses: {
        releaseClause: baseSalary * 24 * duration
      }
    };
  }
}));

function calculateBaseSalary(player: Player): number {
  const baseValue = player.rating * 1000;
  const ageMultiplier = player.age < 23 ? 1.2 : player.age > 30 ? 0.8 : 1;
  const potentialMultiplier = player.potential ? (player.potential / player.rating) : 1;
  
  return Math.round(baseValue * ageMultiplier * potentialMultiplier);
}

function calculateContractDuration(player: Player): number {
  if (player.age < 23) return 5;
  if (player.age < 28) return 4;
  if (player.age < 32) return 3;
  return 1;
}

function applyCardEffect(offer: ContractOffer, card: NegotiationCard): ContractOffer {
  const updatedOffer = { ...offer };
  const { target, modifier } = card.effect;

  if (target in updatedOffer) {
    (updatedOffer[target] as number) *= modifier;
  } else if (target in updatedOffer.bonuses) {
    updatedOffer.bonuses[target as keyof typeof updatedOffer.bonuses] *= modifier;
  } else if (target in updatedOffer.clauses) {
    const clauseValue = updatedOffer.clauses[target as keyof typeof updatedOffer.clauses];
    if (typeof clauseValue === 'number') {
      updatedOffer.clauses[target as keyof typeof updatedOffer.clauses] = clauseValue * modifier;
    }
  }

  return updatedOffer;
}