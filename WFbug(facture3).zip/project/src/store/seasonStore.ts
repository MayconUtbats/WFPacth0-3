```typescript
import { create } from 'zustand';
import { SEASON_CONFIG } from '../constants/season';
import { addMonths, isWithinInterval, startOfMonth, endOfMonth } from 'date-fns';

interface SeasonState {
  currentDate: Date;
  seasonStartDate: Date;
  seasonEndDate: Date;
  isSeasonActive: boolean;
  monthlySchedule: any[];
  advanceDay: () => void;
  startNewSeason: () => void;
  getCurrentMonthMatches: () => any[];
}

export const useSeasonStore = create<SeasonState>((set, get) => ({
  currentDate: new Date(2024, SEASON_CONFIG.SEASON_START_MONTH - 1, 1),
  seasonStartDate: new Date(2024, SEASON_CONFIG.SEASON_START_MONTH - 1, 1),
  seasonEndDate: new Date(2025, SEASON_CONFIG.SEASON_END_MONTH - 1, 31),
  isSeasonActive: true,
  monthlySchedule: [],

  advanceDay: () => {
    set(state => {
      const nextDate = addDays(state.currentDate, 1);
      const isEndOfSeason = nextDate > state.seasonEndDate;

      if (isEndOfSeason) {
        return {
          ...state,
          isSeasonActive: false,
        };
      }

      return {
        ...state,
        currentDate: nextDate,
      };
    });
  },

  startNewSeason: () => {
    const currentYear = new Date().getFullYear();
    set({
      currentDate: new Date(currentYear, SEASON_CONFIG.SEASON_START_MONTH - 1, 1),
      seasonStartDate: new Date(currentYear, SEASON_CONFIG.SEASON_START_MONTH - 1, 1),
      seasonEndDate: new Date(currentYear + 1, SEASON_CONFIG.SEASON_END_MONTH - 1, 31),
      isSeasonActive: true,
      monthlySchedule: [],
    });
  },

  getCurrentMonthMatches: () => {
    const { currentDate } = get();
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);

    return get().monthlySchedule.filter(match =>
      isWithinInterval(match.date, { start: monthStart, end: monthEnd })
    );
  },
}));
```