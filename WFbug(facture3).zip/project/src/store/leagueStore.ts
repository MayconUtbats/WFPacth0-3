```typescript
import { create } from 'zustand';
import { League, LeagueStanding, LeagueFixture } from '../types/league';
import { LEAGUE_CONFIG } from '../constants/leagues';
import { generateLeagueSchedule } from '../utils/league/scheduler';
import { updateLeagueStandings } from '../utils/league/standings';

interface LeagueState {
  leagues: League[];
  initializeLeagues: () => void;
  addTeamToLeague: (teamId: string, countryCode: string, division: number) => boolean;
  updateMatchResult: (fixtureId: string, homeScore: number, awayScore: number) => void;
  getLeagueStandings: (leagueId: string) => LeagueStanding[];
  getTeamFixtures: (teamId: string) => LeagueFixture[];
  getContinentalQualifiers: (countryCode: string) => string[];
}

export const useLeagueStore = create<LeagueState>((set, get) => ({
  leagues: [],

  initializeLeagues: () => {
    const leagues: League[] = [];
    
    Object.entries(LEAGUE_CONFIG.COUNTRIES).forEach(([countryCode, country]) => {
      country.divisions.forEach((divisionName, index) => {
        const division = index + 1;
        leagues.push({
          id: `${countryCode}_${division}`,
          name: divisionName,
          country: countryCode,
          division,
          teams: [],
          maxTeams: LEAGUE_CONFIG.TEAMS_PER_LEAGUE,
          season: new Date().getFullYear(),
          matches: [],
          standings: [],
          schedule: {
            currentMatchday: 1,
            totalMatchdays: LEAGUE_CONFIG.MATCHES_PER_TEAM,
            fixtures: [],
          },
          promotionSpots: 0,
          relegationSpots: LEAGUE_CONFIG.RELEGATION_SPOTS,
        });
      });
    });

    set({ leagues });
  },

  addTeamToLeague: (teamId, countryCode, division) => {
    const { leagues } = get();
    const league = leagues.find(l => l.country === countryCode && l.division === division);
    
    if (!league || league.teams.length >= league.maxTeams) {
      return false;
    }

    set({
      leagues: leagues.map(l => {
        if (l.id === league.id) {
          const updatedTeams = [...l.teams, teamId];
          return {
            ...l,
            teams: updatedTeams,
            schedule: {
              ...l.schedule,
              fixtures: generateLeagueSchedule(updatedTeams, new Date()),
            },
          };
        }
        return l;
      }),
    });

    return true;
  },

  updateMatchResult: (fixtureId, homeScore, awayScore) => {
    const { leagues } = get();
    
    set({
      leagues: leagues.map(league => {
        const fixture = league.schedule.fixtures.find(f => f.id === fixtureId);
        if (!fixture) return league;

        const updatedFixtures = league.schedule.fixtures.map(f => 
          f.id === fixtureId ? { ...f, result: { homeScore, awayScore } } : f
        );

        return {
          ...league,
          schedule: {
            ...league.schedule,
            fixtures: updatedFixtures,
          },
          standings: updateLeagueStandings(updatedFixtures, league.teams),
        };
      }),
    });
  },

  getLeagueStandings: (leagueId) => {
    const league = get().leagues.find(l => l.id === leagueId);
    return league?.standings || [];
  },

  getTeamFixtures: (teamId) => {
    const { leagues } = get();
    const fixtures: LeagueFixture[] = [];

    leagues.forEach(league => {
      league.schedule.fixtures.forEach(fixture => {
        if (fixture.homeTeamId === teamId || fixture.awayTeamId === teamId) {
          fixtures.push(fixture);
        }
      });
    });

    return fixtures.sort((a, b) => a.date.getTime() - b.date.getTime());
  },

  getContinentalQualifiers: (countryCode) => {
    const league = get().leagues.find(
      l => l.country === countryCode && l.division === 1
    );
    if (!league) return [];

    const country = LEAGUE_CONFIG.COUNTRIES[countryCode];
    const spots = LEAGUE_CONFIG.CONTINENTAL.spots;
    
    return league.standings
      .slice(0, spots)
      .map(standing => standing.teamId);
  },
}));
```