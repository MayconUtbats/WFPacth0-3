import { create } from 'zustand';
import { Club, ClubFinances } from '../types/club';
import { calculateClubValue } from '../utils/club/valueCalculator';
import { updateClubFinances } from '../utils/club/financeManager';

interface ClubState {
  clubs: Club[];
  currentClub: Club | null;
  setCurrentClub: (club: Club) => void;
  updateClubFinances: (clubId: string, updates: Partial<ClubFinances>) => void;
  addPlayer: (clubId: string, playerId: string) => void;
  removePlayer: (clubId: string, playerId: string) => void;
  upgradeFacility: (clubId: string, facility: keyof Club['facilities']) => void;
}

export const useClubStore = create<ClubState>((set, get) => ({
  clubs: [],
  currentClub: null,

  setCurrentClub: (club) => {
    set({ currentClub: club });
  },

  updateClubFinances: (clubId, updates) => {
    set((state) => ({
      clubs: state.clubs.map((club) =>
        club.id === clubId
          ? { ...club, finances: { ...club.finances, ...updates } }
          : club
      ),
    }));
  },

  addPlayer: (clubId, playerId) => {
    set((state) => ({
      clubs: state.clubs.map((club) =>
        club.id === clubId
          ? { ...club, players: [...club.players, playerId] }
          : club
      ),
    }));
  },

  removePlayer: (clubId, playerId) => {
    set((state) => ({
      clubs: state.clubs.map((club) =>
        club.id === clubId
          ? { ...club, players: club.players.filter((id) => id !== playerId) }
          : club
      ),
    }));
  },

  upgradeFacility: (clubId, facility) => {
    set((state) => ({
      clubs: state.clubs.map((club) =>
        club.id === clubId
          ? {
              ...club,
              facilities: {
                ...club.facilities,
                [facility]: {
                  ...club.facilities[facility],
                  level: club.facilities[facility].level + 1,
                },
              },
            }
          : club
      ),
    }));
  },
}));