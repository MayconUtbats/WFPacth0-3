```typescript
import { YouthPlayer } from '../../types/academy';
import { generatePlayerName } from '../nameGenerator';

export function generateYouthPlayer(
  academyLevel: number,
  scoutingLevel: number
): YouthPlayer {
  const positions = ['GK', 'DEF', 'MID', 'FWD'] as const;
  const position = positions[Math.floor(Math.random() * positions.length)];
  
  const baseAbility = 40 + Math.floor(Math.random() * 20);
  const potentialBonus = (academyLevel * 5) + (scoutingLevel * 2);
  const potential = Math.min(99, baseAbility + potentialBonus + Math.floor(Math.random() * 20));

  return {
    id: crypto.randomUUID(),
    name: generatePlayerName(),
    age: 15 + Math.floor(Math.random() * 4),
    position,
    potential,
    currentAbility: baseAbility,
    graduationDate: new Date(Date.now() + (90 * 24 * 60 * 60 * 1000)), // 90 days
    monthlySalary: 1000 + (baseAbility * 100),
    attributes: {
      technical: 40 + Math.floor(Math.random() * 20),
      physical: 40 + Math.floor(Math.random() * 20),
      mental: 40 + Math.floor(Math.random() * 20),
    },
    development: {
      progress: 0,
      lastTrainingDate: new Date(),
      monthlyGrowth: 0,
    },
  };
}
```