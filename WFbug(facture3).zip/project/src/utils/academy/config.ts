import { AcademyUpgradeConfig } from '../../types/academy';

export const ACADEMY_CONFIG: AcademyUpgradeConfig = {
  baseUpgradeCost: 1000000,
  baseMonthlyCost: 50000,
  baseMaxPlayers: 5,
  levelMultiplier: 2,
  maxLevel: 5,
  facilityUpgradeCost: 500000,
};

export const PLAYER_DEVELOPMENT_CONFIG = {
  minStartingAbility: 40,
  maxStartingAbility: 60,
  minPotential: 60,
  maxPotential: 99,
  baseMonthlyGrowth: 2,
  trainingMultiplier: 1.5,
  educationMultiplier: 1.3,
  medicalMultiplier: 1.2,
};

export const SALARY_CONFIG = {
  baseYouthSalary: 1000,
  potentialMultiplier: 100,
  levelMultiplier: 1.5,
};