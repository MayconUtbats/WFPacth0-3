import { YouthPlayer } from '../../types/academy';
import { PLAYER_DEVELOPMENT_CONFIG, SALARY_CONFIG } from './config';
import { generatePlayerName } from '../nameGenerator';
import { addMonths } from 'date-fns';

export function generateYouthPlayer(
  academyLevel: number,
  scoutingLevel: number,
  countryCode: string
): YouthPlayer {
  const positions: Array<'GK' | 'DEF' | 'MID' | 'FWD'> = ['GK', 'DEF', 'MID', 'FWD'];
  const position = positions[Math.floor(Math.random() * positions.length)];
  
  const baseAbility = PLAYER_DEVELOPMENT_CONFIG.minStartingAbility + 
    Math.floor(Math.random() * (PLAYER_DEVELOPMENT_CONFIG.maxStartingAbility - PLAYER_DEVELOPMENT_CONFIG.minStartingAbility));
  
  const potentialBonus = (academyLevel * 5) + (scoutingLevel * 2);
  const potential = Math.min(
    baseAbility + potentialBonus + Math.floor(Math.random() * 30),
    PLAYER_DEVELOPMENT_CONFIG.maxPotential
  );

  const monthlySalary = SALARY_CONFIG.baseYouthSalary * 
    academyLevel * 
    (1 + (potential - PLAYER_DEVELOPMENT_CONFIG.minPotential) / 100);

  return {
    id: crypto.randomUUID(),
    name: generatePlayerName(countryCode),
    age: 15 + Math.floor(Math.random() * 4),
    position,
    potential,
    currentAbility: baseAbility,
    graduationDate: addMonths(new Date(), 3),
    monthlySalary: Math.round(monthlySalary),
    attributes: {
      technical: 40 + Math.floor(Math.random() * 20),
      physical: 40 + Math.floor(Math.random() * 20),
      mental: 40 + Math.floor(Math.random() * 20),
    },
    development: {
      progress: 0,
      lastTrainingDate: new Date(),
      monthlyGrowth: PLAYER_DEVELOPMENT_CONFIG.baseMonthlyGrowth,
    },
  };
}