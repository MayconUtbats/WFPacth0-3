```typescript
import { YouthPlayer, PlayerAttributes } from '../../types/academy';

export function calculatePlayerDevelopment(
  player: YouthPlayer,
  trainingLevel: number,
  educationLevel: number
): PlayerAttributes {
  const baseImprovement = 0.5;
  const trainingMultiplier = 1 + (trainingLevel * 0.1);
  const educationMultiplier = 1 + (educationLevel * 0.05);
  
  const improvement = baseImprovement * trainingMultiplier * educationMultiplier;
  
  return {
    technical: Math.min(99, player.attributes.technical + improvement),
    physical: Math.min(99, player.attributes.physical + improvement),
    mental: Math.min(99, player.attributes.mental + improvement),
  };
}

export function calculatePotentialGrowth(
  currentAbility: number,
  potential: number,
  age: number
): number {
  const maxGrowth = potential - currentAbility;
  const ageModifier = age <= 18 ? 1.2 : age <= 21 ? 1 : 0.8;
  
  return Math.floor(maxGrowth * ageModifier);
}

export function calculateTrainingProgress(
  currentProgress: number,
  trainingLevel: number,
  playerAge: number
): number {
  const baseProgress = 5;
  const trainingBonus = trainingLevel * 2;
  const ageModifier = playerAge <= 18 ? 1.2 : 1;
  
  const progress = (baseProgress + trainingBonus) * ageModifier;
  return Math.min(100, currentProgress + progress);
}
```