```typescript
import { STADIUM_CONFIG } from '../../constants/stadium';

export function calculateExpansionCost(currentCapacity: number): number {
  const baseExpansionCost = STADIUM_CONFIG.COSTS.BASE_EXPANSION;
  const capacityFactor = Math.floor(currentCapacity / 10000);
  return (baseExpansionCost + (capacityFactor * 20)) * STADIUM_CONFIG.EXPANSION_STEP;
}

export function calculateMaintenanceCost(capacity: number): number {
  return Math.floor(capacity * STADIUM_CONFIG.COSTS.MAINTENANCE_PER_SEAT);
}

export function calculateMatchAttendance(
  capacity: number,
  ticketPrice: number,
  teamRating: number,
  isRivalMatch: boolean,
  weatherFactor: number = 1
): number {
  const baseAttendance = capacity * 0.4;
  const maxTicketPrice = 20 + (teamRating * 0.8);
  const priceFactor = 1 - (ticketPrice / maxTicketPrice);
  const ratingFactor = teamRating / 100;
  const rivalBonus = isRivalMatch ? 1.3 : 1;
  
  let calculatedAttendance = Math.floor(
    baseAttendance * 
    priceFactor * 
    ratingFactor * 
    rivalBonus *
    weatherFactor
  );
  
  return Math.min(calculatedAttendance, capacity);
}

export function calculateMatchRevenue(
  attendance: number,
  ticketPrice: number,
  facilities: Record<string, number>
): number {
  const ticketIncome = attendance * ticketPrice;
  
  const facilityIncome = Object.entries(facilities).reduce((total, [facility, level]) => {
    const facilityIncomeMultiplier = {
      shops: 0.1,
      food: 0.15,
      vip: 0.25,
    };
    
    return total + (ticketIncome * (facilityIncomeMultiplier[facility] || 0) * level);
  }, 0);
  
  return Math.floor(ticketIncome + facilityIncome);
}
```