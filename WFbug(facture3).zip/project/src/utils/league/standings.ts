```typescript
import { LeagueStanding, LeagueFixture } from '../../types/league';
import { LEAGUE_CONFIG } from '../../constants/leagues';

export function updateLeagueStandings(
  fixtures: LeagueFixture[],
  teams: string[]
): LeagueStanding[] {
  const standings: Record<string, LeagueStanding> = {};

  // Initialize standings
  teams.forEach(teamId => {
    standings[teamId] = {
      teamId,
      position: 0,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      goalDifference: 0,
      points: 0,
      form: [],
    };
  });

  // Update standings with match results
  fixtures.forEach(fixture => {
    if (!fixture.result) return;

    const home = standings[fixture.homeTeamId];
    const away = standings[fixture.awayTeamId];
    const { homeScore, awayScore } = fixture.result;

    // Update home team
    home.played++;
    home.goalsFor += homeScore;
    home.goalsAgainst += awayScore;
    home.goalDifference = home.goalsFor - home.goalsAgainst;

    // Update away team
    away.played++;
    away.goalsFor += awayScore;
    away.goalsAgainst += homeScore;
    away.goalDifference = away.goalsFor - away.goalsAgainst;

    if (homeScore > awayScore) {
      home.won++;
      home.points += LEAGUE_CONFIG.POINTS.WIN;
      home.form.push('W');
      away.lost++;
      away.form.push('L');
    } else if (awayScore > homeScore) {
      away.won++;
      away.points += LEAGUE_CONFIG.POINTS.WIN;
      away.form.push('W');
      home.lost++;
      home.form.push('L');
    } else {
      home.drawn++;
      away.drawn++;
      home.points += LEAGUE_CONFIG.POINTS.DRAW;
      away.points += LEAGUE_CONFIG.POINTS.DRAW;
      home.form.push('D');
      away.form.push('D');
    }

    // Keep only last 5 matches in form
    if (home.form.length > 5) home.form = home.form.slice(-5);
    if (away.form.length > 5) away.form = away.form.slice(-5);
  });

  // Sort standings
  return Object.values(standings)
    .sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
      return b.goalsFor - a.goalsFor;
    })
    .map((standing, index) => ({
      ...standing,
      position: index + 1,
    }));
}
```