```typescript
import { LeagueStanding } from '../../types/league';
import { LEAGUE_CONFIG } from '../../constants/leagues';

export function getQualifiedTeams(
  standings: LeagueStanding[],
  countryCode: string
): {
  continental: string[];
  relegated: string[];
} {
  const country = LEAGUE_CONFIG.COUNTRIES[countryCode];
  if (!country) return { continental: [], relegated: [] };

  const continental = standings
    .slice(0, LEAGUE_CONFIG.CONTINENTAL_SPOTS)
    .map(s => s.teamId);

  const relegated = standings
    .slice(-LEAGUE_CONFIG.RELEGATION_SPOTS)
    .map(s => s.teamId);

  return {
    continental,
    relegated,
  };
}

export function isTeamQualified(
  teamId: string,
  standings: LeagueStanding[],
  countryCode: string
): {
  continental: boolean;
  relegated: boolean;
} {
  const { continental, relegated } = getQualifiedTeams(standings, countryCode);

  return {
    continental: continental.includes(teamId),
    relegated: relegated.includes(teamId),
  };
}
```