```typescript
import { Match, MatchResult, MatchEvent } from '../../types/match';
import { Team } from '../../types/game';
import { SIMULATION_CONFIG } from '../../constants/simulation';

export function simulateMatch(match: Match): MatchResult {
  const events: MatchEvent[] = [];
  let homeScore = 0;
  let awayScore = 0;
  let minute = 1;

  while (minute <= 90) {
    const event = simulateMinute(match, minute, homeScore, awayScore);
    if (event) {
      events.push(event);
      if (event.type === 'goal') {
        if (event.team === match.homeTeam) homeScore++;
        else awayScore++;
      }
    }
    minute++;
  }

  // Check if extra time is needed for knockout games
  if (isKnockoutMatch(match) && homeScore === awayScore) {
    const extraTime = simulateExtraTime(match);
    const penalties = homeScore === awayScore ? simulatePenalties() : undefined;

    return {
      homeScore,
      awayScore,
      extraTime,
      penalties,
      events,
    };
  }

  return { homeScore, awayScore, events };
}

function simulateMinute(
  match: Match,
  minute: number,
  homeScore: number,
  awayScore: number
): MatchEvent | null {
  const random = Math.random();
  
  // Goal chance
  if (random < SIMULATION_CONFIG.GOAL_CHANCE) {
    return generateGoalEvent(match, minute);
  }
  
  // Card chance
  if (random < SIMULATION_CONFIG.CARD_CHANCE) {
    return generateCardEvent(match, minute);
  }
  
  // Injury chance
  if (random < SIMULATION_CONFIG.INJURY_CHANCE) {
    return generateInjuryEvent(match, minute);
  }

  return null;
}

function generateGoalEvent(match: Match, minute: number): MatchEvent {
  const isHomeTeam = Math.random() > 0.5;
  const team = isHomeTeam ? match.homeTeam : match.awayTeam;
  
  return {
    minute,
    type: 'goal',
    team,
    player: selectRandomPlayer(team),
    description: `GOOOOL! ${team} marca aos ${minute} minutos!`,
  };
}

function generateCardEvent(match: Match, minute: number): MatchEvent {
  const isHomeTeam = Math.random() > 0.5;
  const team = isHomeTeam ? match.homeTeam : match.awayTeam;
  const isRed = Math.random() < 0.2;
  
  return {
    minute,
    type: 'card',
    team,
    player: selectRandomPlayer(team),
    description: `${isRed ? 'Cartão vermelho' : 'Cartão amarelo'} para ${team} aos ${minute} minutos`,
  };
}

function generateInjuryEvent(match: Match, minute: number): MatchEvent {
  const isHomeTeam = Math.random() > 0.5;
  const team = isHomeTeam ? match.homeTeam : match.awayTeam;
  
  return {
    minute,
    type: 'injury',
    team,
    player: selectRandomPlayer(team),
    description: `Jogador do ${team} lesionado aos ${minute} minutos`,
  };
}

function isKnockoutMatch(match: Match): boolean {
  return match.competition !== 'league';
}

function simulateExtraTime(match: Match): { homeScore: number; awayScore: number } {
  return {
    homeScore: Math.floor(Math.random() * 2),
    awayScore: Math.floor(Math.random() * 2),
  };
}

function simulatePenalties(): { homeScore: number; awayScore: number } {
  let homeScore = 0;
  let awayScore = 0;
  
  // 5 penalties each
  for (let i = 0; i < 5; i++) {
    if (Math.random() > 0.25) homeScore++;
    if (Math.random() > 0.25) awayScore++;
  }
  
  // Sudden death if tied
  while (homeScore === awayScore) {
    if (Math.random() > 0.25) homeScore++;
    if (homeScore === awayScore && Math.random() > 0.25) awayScore++;
  }
  
  return { homeScore, awayScore };
}

function selectRandomPlayer(team: string): string {
  return `Player ${Math.floor(Math.random() * 11) + 1}`;
}
```