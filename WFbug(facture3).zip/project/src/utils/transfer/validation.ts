import { TransferOffer, TransferListing, TransferRules } from '../../types/transfer';
import { calculateMarketValue } from './marketValue';
import { Player, Team } from '../../types/game';

export function validateTransferOffer(
  offer: TransferOffer,
  listing: TransferListing,
  player: Player,
  buyingTeam: Team,
  rules: TransferRules
): { valid: boolean; reason?: string } {
  // Check if transfer window is open
  if (!rules.transferWindowOpen) {
    return { valid: false, reason: 'Transfer window is closed' };
  }

  // Calculate market value
  const marketValue = calculateMarketValue(player);

  // Check minimum value
  const minAllowedValue = marketValue.finalValue * rules.minValueMultiplier;
  if (offer.offeredAmount < minAllowedValue) {
    return { 
      valid: false, 
      reason: `Offer below minimum allowed value of ${minAllowedValue}` 
    };
  }

  // Check maximum value
  const maxAllowedValue = marketValue.finalValue * rules.maxValueMultiplier;
  if (offer.offeredAmount > maxAllowedValue) {
    return { 
      valid: false, 
      reason: `Offer above maximum allowed value of ${maxAllowedValue}` 
    };
  }

  // Check if buying team has enough budget
  const transferTax = offer.offeredAmount * rules.transferTaxRate;
  const totalCost = offer.offeredAmount + transferTax;
  
  if (buyingTeam.budget < totalCost) {
    return { 
      valid: false, 
      reason: 'Insufficient budget including transfer tax' 
    };
  }

  // Check if player was recently transferred
  const lastTransferDate = player.lastTransferDate;
  if (lastTransferDate) {
    const daysSinceLastTransfer = Math.floor(
      (Date.now() - lastTransferDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    
    if (daysSinceLastTransfer < rules.minDaysBetweenTransfers) {
      return { 
        valid: false, 
        reason: 'Player was transferred too recently' 
      };
    }
  }

  return { valid: true };
}

export function calculateTransferTax(amount: number, rules: TransferRules): number {
  return amount * rules.transferTaxRate;
}