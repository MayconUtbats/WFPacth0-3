import { Player } from '../../types/game';
import { MarketValue } from '../../types/transfer';

const AGE_MULTIPLIERS = {
  young: { minAge: 16, maxAge: 23, multiplier: 1.5 }, // Young players worth more
  prime: { minAge: 24, maxAge: 28, multiplier: 1.3 }, // Prime age players
  mature: { minAge: 29, maxAge: 32, multiplier: 1.0 }, // Mature players
  veteran: { minAge: 33, maxAge: 40, multiplier: 0.7 }, // Veterans worth less
};

const PERFORMANCE_WEIGHTS = {
  goals: 2,
  assists: 1.5,
  cleanSheets: 1.8,
  rating: 2.5,
};

export function calculateMarketValue(player: Player): MarketValue {
  // Base value calculation based on rating
  const baseValue = calculateBaseValue(player.rating);

  // Age multiplier
  const ageMultiplier = calculateAgeMultiplier(player.age);

  // Performance multiplier based on recent form
  const performanceMultiplier = calculatePerformanceMultiplier(player);

  // Potential multiplier for young players
  const potentialMultiplier = player.potential ? 
    calculatePotentialMultiplier(player.potential, player.age) : 1;

  // Contract multiplier (shorter contracts = lower value)
  const contractMultiplier = player.contractYears ? 
    calculateContractMultiplier(player.contractYears) : 1;

  // Calculate final value
  const finalValue = Math.round(
    baseValue * 
    ageMultiplier * 
    performanceMultiplier * 
    potentialMultiplier * 
    contractMultiplier
  );

  return {
    baseValue,
    ageMultiplier,
    performanceMultiplier,
    potentialMultiplier,
    contractMultiplier,
    finalValue,
  };
}

function calculateBaseValue(rating: number): number {
  // Exponential growth for higher ratings
  return Math.pow(rating, 2) * 1000;
}

function calculateAgeMultiplier(age: number): number {
  for (const [_, data] of Object.entries(AGE_MULTIPLIERS)) {
    if (age >= data.minAge && age <= data.maxAge) {
      return data.multiplier;
    }
  }
  return 0.5; // Default multiplier for very old players
}

function calculatePerformanceMultiplier(player: Player): number {
  // Start with base multiplier
  let multiplier = 1;

  // Adjust based on recent performance
  if (player.recentPerformance) {
    const { goals, assists, cleanSheets, averageRating } = player.recentPerformance;
    
    multiplier += (goals * PERFORMANCE_WEIGHTS.goals) / 10;
    multiplier += (assists * PERFORMANCE_WEIGHTS.assists) / 10;
    multiplier += (cleanSheets * PERFORMANCE_WEIGHTS.cleanSheets) / 10;
    multiplier += ((averageRating - 6) * PERFORMANCE_WEIGHTS.rating) / 10;
  }

  return Math.max(0.5, Math.min(2, multiplier));
}

function calculatePotentialMultiplier(potential: number, age: number): number {
  if (age > 23) return 1; // Only apply to young players

  const potentialGap = potential - 70; // Base potential threshold
  return 1 + (Math.max(0, potentialGap) / 100);
}

function calculateContractMultiplier(yearsRemaining: number): number {
  // Shorter contracts reduce value
  return Math.min(1, 0.5 + (yearsRemaining * 0.25));
}