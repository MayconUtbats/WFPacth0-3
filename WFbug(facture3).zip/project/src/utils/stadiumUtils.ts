import { StadiumConfig } from '../types/stadium';

export const calculateExpansionCost = (currentCapacity: number): number => {
  const baseExpansionCost = 100;
  const capacityFactor = Math.floor(currentCapacity / 10000);
  return (baseExpansionCost + (capacityFactor * 20)) * 5000;
};

export const calculateMaintenanceCost = (capacity: number): number => {
  return Math.floor(capacity * 2); // $2 per seat per match
};

export const calculateMaxTicketPrice = (teamRating: number): number => {
  // Base ticket price based on team rating (1-100)
  const basePrice = 20;
  const ratingBonus = teamRating * 0.8;
  return Math.floor(basePrice + ratingBonus);
};

export const calculateMatchAttendance = (
  capacity: number,
  ticketPrice: number,
  maxTicketPrice: number,
  teamRating: number,
  isRivalMatch: boolean,
  weatherFactor: number = 1
): number => {
  // Base attendance calculation
  const baseAttendance = capacity * 0.4; // Base 40% attendance
  
  // Price factor (higher prices reduce attendance)
  const priceFactor = 1 - (ticketPrice / maxTicketPrice);
  
  // Team performance factor
  const ratingFactor = teamRating / 100;
  
  // Special match bonus
  const rivalBonus = isRivalMatch ? 1.3 : 1;
  
  // Calculate final attendance
  let calculatedAttendance = Math.floor(
    baseAttendance * 
    priceFactor * 
    ratingFactor * 
    rivalBonus *
    weatherFactor
  );
  
  // Ensure attendance doesn't exceed capacity
  return Math.min(calculatedAttendance, capacity);
};

export const calculateStadiumIncome = (
  attendance: number,
  ticketPrice: number,
  facilities: Record<string, number>
): number => {
  // Base income from tickets
  const ticketIncome = attendance * ticketPrice;
  
  // Additional income from facilities
  const facilityIncome = Object.entries(facilities).reduce((total, [facility, level]) => {
    const facilityIncomeMultiplier = {
      shops: 0.1,
      food: 0.15,
      vip: 0.25,
    };
    
    return total + (ticketIncome * (facilityIncomeMultiplier[facility] || 0) * level);
  }, 0);
  
  return Math.floor(ticketIncome + facilityIncome);
};