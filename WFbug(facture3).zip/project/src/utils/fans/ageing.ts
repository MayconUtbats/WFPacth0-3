import { FanBase, FanAgeingConfig } from '../../types/fans';

export const AGING_CONFIG: FanAgeingConfig = {
  yearlyAgingRate: 0.05, // 5% of fans age each year
  naturalDeathRate: 0.02, // 2% of senior fans pass away each year
  inactivityRate: 0.01, // 1% of fans become inactive each year
  youngReplacementRate: 0.03, // 3% new young fans replace lost fans
};

export function simulateAging(fanBase: FanBase): FanBase {
  const { demographics, losses } = fanBase;
  
  // Calculate aging transitions
  const youngToAdult = Math.floor(demographics.young * AGING_CONFIG.yearlyAgingRate);
  const adultToSenior = Math.floor(demographics.adult * AGING_CONFIG.yearlyAgingRate);
  
  // Calculate natural deaths
  const naturalDeaths = Math.floor(demographics.senior * AGING_CONFIG.naturalDeathRate);
  
  // Calculate inactive fans
  const inactiveFans = Math.floor(
    (demographics.young + demographics.adult + demographics.senior) * 
    AGING_CONFIG.inactivityRate
  );

  // Calculate new young fans (replacement)
  const totalLosses = naturalDeaths + inactiveFans;
  const newYoungFans = Math.floor(totalLosses * AGING_CONFIG.youngReplacementRate);

  // Update demographics
  const newDemographics = {
    young: demographics.young - youngToAdult + newYoungFans,
    adult: demographics.adult + youngToAdult - adultToSenior,
    senior: demographics.senior + adultToSenior - naturalDeaths,
  };

  // Update losses
  const newLosses = {
    natural: losses.natural + naturalDeaths,
    inactive: losses.inactive + inactiveFans,
    total: losses.total + naturalDeaths + inactiveFans,
  };

  // Calculate new total
  const newTotal = newDemographics.young + newDemographics.adult + newDemographics.senior;

  return {
    ...fanBase,
    total: newTotal,
    demographics: newDemographics,
    losses: newLosses,
  };
}

export function distributeNewFans(total: number) {
  return {
    young: Math.floor(total * 0.4), // 40% young fans
    adult: Math.floor(total * 0.4), // 40% adult fans
    senior: Math.floor(total * 0.2), // 20% senior fans
  };
}

export function calculateFanLoyalty(fanBase: FanBase): number {
  // Senior fans contribute more to loyalty
  const seniorWeight = 0.5;
  const adultWeight = 0.3;
  const youngWeight = 0.2;

  const totalFans = fanBase.total;
  if (totalFans === 0) return 0;

  return Math.floor(
    ((fanBase.demographics.senior / totalFans) * seniorWeight +
     (fanBase.demographics.adult / totalFans) * adultWeight +
     (fanBase.demographics.young / totalFans) * youngWeight) * 100
  );
}