import { Player, PlayerStatistics } from '../../../types/player';

export function calculateAverageRating(player: PlayerStatistics): number {
  if (player.jogos === 0) return 0;
  return player.media_notas / player.jogos;
}

export function calculateGoalsPerGame(player: PlayerStatistics): number {
  if (player.jogos === 0) return 0;
  return player.gols / player.jogos;
}

export function calculateAssistsPerGame(player: PlayerStatistics): number {
  if (player.jogos === 0) return 0;
  return player.assistencias / player.jogos;
}

export function calculateMinutesPerGame(player: PlayerStatistics): number {
  if (player.jogos === 0) return 0;
  return player.minutos_jogados / player.jogos;
}

export function calculateCleanSheetsPercentage(player: PlayerStatistics): number {
  if (!player.clean_sheets || player.jogos === 0) return 0;
  return (player.clean_sheets / player.jogos) * 100;
}