import { Player, TransferHistory } from '../../../types/player';
import { formatCurrency } from '../../formatters';

export function addTransferToHistory(
  player: Player,
  originTeamId: string,
  destinationTeamId: string,
  transferValue: number
): TransferHistory[] {
  const newTransfer: TransferHistory = {
    data: new Date(),
    time_origem: originTeamId,
    time_destino: destinationTeamId,
    valor: transferValue,
  };

  return [...player.historico_transferencias, newTransfer];
}

export function getTransferHistory(player: Player): string[] {
  return player.historico_transferencias.map(transfer => {
    const date = transfer.data.toLocaleDateString();
    const value = formatCurrency(transfer.valor);
    return `${date}: ${transfer.time_origem} → ${transfer.time_destino} (${value})`;
  });
}

export function calculateTotalTransferValue(player: Player): number {
  return player.historico_transferencias.reduce(
    (total, transfer) => total + transfer.valor, 
    0
  );
}