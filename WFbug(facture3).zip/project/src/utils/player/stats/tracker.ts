import { Player, PlayerStatistics } from '../../../types/player';

export function updatePlayerStats(
  currentStats: PlayerStatistics,
  matchStats: {
    minutos: number;
    gols: number;
    assistencias: number;
    cartoes_amarelos: number;
    cartoes_vermelhos: number;
    nota: number;
    clean_sheet?: boolean;
  }
): PlayerStatistics {
  return {
    jogos: currentStats.jogos + 1,
    gols: currentStats.gols + matchStats.gols,
    assistencias: currentStats.assistencias + matchStats.assistencias,
    cartoes_amarelos: currentStats.cartoes_amarelos + matchStats.cartoes_amarelos,
    cartoes_vermelhos: currentStats.cartoes_vermelhos + matchStats.cartoes_vermelhos,
    media_notas: (currentStats.media_notas * currentStats.jogos + matchStats.nota) / (currentStats.jogos + 1),
    minutos_jogados: currentStats.minutos_jogados + matchStats.minutos,
    clean_sheets: matchStats.clean_sheet 
      ? (currentStats.clean_sheets || 0) + 1 
      : currentStats.clean_sheets,
  };
}

export function initializePlayerStats(): PlayerStatistics {
  return {
    jogos: 0,
    gols: 0,
    assistencias: 0,
    cartoes_amarelos: 0,
    cartoes_vermelhos: 0,
    media_notas: 0,
    minutos_jogados: 0,
    clean_sheets: 0,
  };
}