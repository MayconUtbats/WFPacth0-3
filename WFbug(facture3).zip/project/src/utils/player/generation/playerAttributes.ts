import { Position } from '../../../types/game';

interface AttributeRanges {
  min: number;
  max: number;
}

const POSITION_ATTRIBUTES: Record<Position, Record<string, AttributeRanges>> = {
  GK: {
    reflexes: { min: 60, max: 75 },
    positioning: { min: 55, max: 70 },
    handling: { min: 55, max: 70 },
    kicking: { min: 50, max: 65 },
    diving: { min: 55, max: 70 }
  },
  DEF: {
    tackling: { min: 60, max: 75 },
    marking: { min: 55, max: 70 },
    heading: { min: 55, max: 70 },
    strength: { min: 55, max: 70 },
    positioning: { min: 55, max: 70 }
  },
  MID: {
    passing: { min: 60, max: 75 },
    technique: { min: 55, max: 70 },
    vision: { min: 55, max: 70 },
    stamina: { min: 60, max: 75 },
    dribbling: { min: 55, max: 70 }
  },
  FWD: {
    finishing: { min: 60, max: 75 },
    dribbling: { min: 55, max: 70 },
    speed: { min: 55, max: 70 },
    shooting: { min: 60, max: 75 },
    heading: { min: 55, max: 70 }
  }
};

export function generatePlayerAttributes(position: Position, baseRating: number) {
  const attributes = { ...POSITION_ATTRIBUTES[position] };
  const result: Record<string, number> = {};

  // Generate random values within ranges, adjusted by base rating
  Object.entries(attributes).forEach(([attr, ranges]) => {
    const ratingAdjustment = (baseRating - 60) * 0.5; // Adjust ranges based on base rating
    const min = ranges.min + ratingAdjustment;
    const max = ranges.max + ratingAdjustment;
    result[attr] = Math.floor(min + Math.random() * (max - min));
  });

  return result;
}

export function calculateOverallRating(attributes: Record<string, number>): number {
  const values = Object.values(attributes);
  const average = values.reduce((sum, val) => sum + val, 0) / values.length;
  return Math.round(average);
}