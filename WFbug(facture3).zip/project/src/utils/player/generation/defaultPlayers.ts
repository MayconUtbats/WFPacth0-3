import { Player } from '../../../types/game';
import { generatePlayerName } from '../../nameGenerator';
import { generatePlayerAttributes } from './playerAttributes';
import { initializePlayerStats } from './playerStats';

export function generateDefaultPlayers(teamId: string): Player[] {
  const positions = {
    GK: 2,  // Goalkeepers
    DEF: 6, // Defenders
    MID: 6, // Midfielders
    FWD: 4  // Forwards
  };

  const players: Player[] = [];

  // Generate players for each position
  Object.entries(positions).forEach(([position, count]) => {
    for (let i = 0; i < count; i++) {
      const baseRating = position === 'GK' ? 65 : 60 + Math.floor(Math.random() * 10);
      
      const player: Player = {
        id: `${teamId}_player_${players.length + 1}`,
        name: generatePlayerName(),
        position: position as 'GK' | 'DEF' | 'MID' | 'FWD',
        rating: baseRating,
        stamina: 90 + Math.floor(Math.random() * 10),
        salary: calculateInitialSalary(baseRating)
      };

      players.push(player);
    }
  });

  return players;
}

function calculateInitialSalary(rating: number): number {
  // Base salary calculation based on rating
  const baseSalary = 1000; // Base salary in currency units
  const ratingMultiplier = Math.pow(1.1, rating - 60); // Exponential growth based on rating
  
  return Math.round(baseSalary * ratingMultiplier);
}