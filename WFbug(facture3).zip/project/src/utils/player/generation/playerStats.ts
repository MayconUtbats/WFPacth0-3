import { PlayerStatistics } from '../../../types/player';

export function initializePlayerStats(): PlayerStatistics {
  return {
    jogos: 0,
    gols: 0,
    assistencias: 0,
    cartoes_amarelos: 0,
    cartoes_vermelhos: 0,
    media_notas: 0,
    minutos_jogados: 0,
    clean_sheets: 0
  };
}

export function calculateAverageRating(stats: PlayerStatistics): number {
  if (stats.jogos === 0) return 0;
  return stats.media_notas / stats.jogos;
}

export function calculateGoalsPerGame(stats: PlayerStatistics): number {
  if (stats.jogos === 0) return 0;
  return stats.gols / stats.jogos;
}

export function calculateAssistsPerGame(stats: PlayerStatistics): number {
  if (stats.jogos === 0) return 0;
  return stats.assistencias / stats.jogos;
}

export function calculateMinutesPerGame(stats: PlayerStatistics): number {
  if (stats.jogos === 0) return 0;
  return stats.minutos_jogados / stats.jogos;
}