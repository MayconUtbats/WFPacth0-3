import { Player } from '../../../types/player';

export function checkForInjury(player: Player): { injured: boolean; duration?: number } {
  const injuryProne = player.atributos.adicionais.lesoes;
  const baseInjuryChance = 0.05; // 5% base chance
  
  // Higher injury rating means more prone to injuries
  const injuryChance = baseInjuryChance * (injuryProne / 50);
  
  if (Math.random() < injuryChance) {
    // Calculate injury duration (1-6 weeks)
    const duration = Math.floor(Math.random() * 6 * 7) + 7;
    return { injured: true, duration };
  }
  
  return { injured: false };
}

export function updateInjuryStatus(player: Player): Player {
  if (!player.lesionado || !player.dias_lesionado) {
    return player;
  }

  const remainingDays = player.dias_lesionado - 1;
  
  if (remainingDays <= 0) {
    return {
      ...player,
      lesionado: false,
      dias_lesionado: undefined,
    };
  }

  return {
    ...player,
    dias_lesionado: remainingDays,
  };
}