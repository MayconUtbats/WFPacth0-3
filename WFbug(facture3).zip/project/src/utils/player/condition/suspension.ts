import { Player } from '../../../types/player';

export function checkForSuspension(player: Player): boolean {
  const yellowCards = player.estatisticas.cartoes_amarelos;
  const redCards = player.estatisticas.cartoes_vermelhos;
  
  // Suspended after 3 yellows or 1 red
  return yellowCards >= 3 || redCards > 0;
}

export function resetCards(player: Player): Player {
  return {
    ...player,
    estatisticas: {
      ...player.estatisticas,
      cartoes_amarelos: 0,
      cartoes_vermelhos: 0,
    },
  };
}