import { Player } from '../../../types/player';

export function updatePlayerFitness(
  player: Player,
  minutesPlayed: number,
  intensity: number
): Player {
  const baseStaminaDrop = (minutesPlayed / 90) * 10; // 10% drop for full game
  const intensityMultiplier = intensity / 100;
  const staminaDrop = baseStaminaDrop * intensityMultiplier;
  
  const newStamina = Math.max(0, player.condicao - staminaDrop);
  
  return {
    ...player,
    condicao: newStamina,
  };
}

export function recoverFitness(player: Player, restDays: number): Player {
  const recoveryPerDay = 5; // 5% recovery per day
  const totalRecovery = Math.min(
    100 - player.condicao,
    recoveryPerDay * restDays
  );
  
  return {
    ...player,
    condicao: player.condicao + totalRecovery,
  };
}