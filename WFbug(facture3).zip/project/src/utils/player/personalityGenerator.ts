import { PlayerPersonality, PERSONALITY_TRAITS } from '../../types/personality';

export function generatePlayerPersonality(): PlayerPersonality {
  // Select 1-3 random traits
  const numTraits = Math.floor(Math.random() * 3) + 1;
  const shuffledTraits = [...PERSONALITY_TRAITS].sort(() => Math.random() - 0.5);
  const selectedTraits = shuffledTraits.slice(0, numTraits);

  // Generate base personality stats
  const personality: PlayerPersonality = {
    traits: selectedTraits,
    ambition: generatePersonalityStat(),
    professionalism: generatePersonalityStat(),
    temperament: generatePersonalityStat(),
    loyalty: generatePersonalityStat(),
  };

  // Adjust stats based on traits
  personality.traits.forEach(trait => {
    if (trait.id === 'ambitious') {
      personality.ambition = Math.min(100, personality.ambition + 20);
    } else if (trait.id === 'professional') {
      personality.professionalism = Math.min(100, personality.professionalism + 20);
    }
  });

  return personality;
}

function generatePersonalityStat(): number {
  // Normal distribution around 50
  const mean = 50;
  const stdDev = 15;
  let value = Math.floor(
    mean + (randNormal() * stdDev)
  );
  
  // Clamp between 1-100
  return Math.max(1, Math.min(100, value));
}

// Box-Muller transform for normal distribution
function randNormal(): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}