import { Player, PlayerAttributes, Position } from '../../types/player';

interface AttributeWeights {
  [key: string]: number;
}

const POSITION_WEIGHTS: Record<Position, AttributeWeights> = {
  GK: {
    reflexos: 20,
    posicionamento_gol: 20,
    dominio_aereo: 15,
    jogo_pes: 10,
    penaltis: 10,
    posicionamento: 15,
    decisao: 10,
  },
  DEF: {
    defesa: 20,
    cabeceio: 15,
    forca: 15,
    posicionamento: 15,
    passe: 10,
    velocidade: 10,
    decisao: 15,
  },
  MID: {
    passe: 20,
    visao_jogo: 15,
    controle_bola: 15,
    drible: 10,
    resistencia: 15,
    decisao: 15,
    trabalho_equipe: 10,
  },
  FWD: {
    finalizacao: 20,
    drible: 15,
    velocidade: 15,
    posicionamento: 15,
    cabeceio: 10,
    aceleracao: 15,
    decisao: 10,
  },
};

export function calculateOverallRating(player: Player): number {
  const { atributos, posicao } = player;
  const weights = POSITION_WEIGHTS[posicao];
  let totalWeight = 0;
  let weightedSum = 0;

  // Calculate weighted sum based on position
  Object.entries(weights).forEach(([attribute, weight]) => {
    const value = getAttributeValue(atributos, attribute);
    if (value !== undefined) {
      weightedSum += value * weight;
      totalWeight += weight;
    }
  });

  return Math.round(weightedSum / totalWeight);
}

function getAttributeValue(attributes: PlayerAttributes, attributeName: string): number | undefined {
  // Search through all attribute categories
  for (const category of Object.values(attributes)) {
    if (category && attributeName in category) {
      return category[attributeName as keyof typeof category] as number;
    }
  }
  return undefined;
}

export function calculatePotentialGrowth(player: Player): number {
  const { idade, atributos } = player;
  const currentOverall = calculateOverallRating(player);
  const potential = atributos.adicionais.potencial;

  if (idade <= 21) {
    return Math.floor((potential - currentOverall) * 0.8);
  } else if (idade <= 23) {
    return Math.floor((potential - currentOverall) * 0.5);
  } else if (idade <= 28) {
    return Math.floor((potential - currentOverall) * 0.2);
  }
  return 0;
}

export function calculateMatchRating(
  player: Player,
  performance: {
    goals: number;
    assists: number;
    passes: number;
    tackles: number;
    saves?: number;
  }
): number {
  const baseRating = 6.0;
  let rating = baseRating;

  // Add performance bonuses
  if (player.posicao === 'GK') {
    rating += performance.saves ? performance.saves * 0.5 : 0;
  } else {
    rating += performance.goals * 1.0;
    rating += performance.assists * 0.5;
    rating += (performance.passes / 30) * 0.5;
    rating += performance.tackles * 0.3;
  }

  // Cap rating between 1 and 10
  return Math.max(1, Math.min(10, rating));
}

export function calculateAttributeDecay(player: Player): Partial<PlayerAttributes> {
  const { idade, atributos } = player;
  const decay: Partial<PlayerAttributes> = {
    fisicos: { ...atributos.fisicos },
  };

  if (idade > 32) {
    const decayRate = (idade - 32) * 0.5;
    Object.keys(decay.fisicos!).forEach(attr => {
      const key = attr as keyof typeof decay.fisicos;
      decay.fisicos![key] = Math.max(
        1,
        Math.floor(atributos.fisicos[key] - decayRate)
      );
    });
  }

  return decay;
}