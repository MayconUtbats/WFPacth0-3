import { Position, Player } from '../../types/game';

const POSITION_WEIGHTS: Record<Position, { primary: string[], secondary: string[] }> = {
  'GOL': {
    primary: ['reflexos', 'posicionamento_gol', 'dominio_aereo'],
    secondary: ['jogo_pes', 'penaltis', 'posicionamento']
  },
  'ZAG': {
    primary: ['defesa', 'cabeceio', 'forca'],
    secondary: ['posicionamento', 'passe', 'velocidade']
  },
  'LD': {
    primary: ['velocidade', 'cruzamento', 'defesa'],
    secondary: ['resistencia', 'passe', 'drible']
  },
  'LE': {
    primary: ['velocidade', 'cruzamento', 'defesa'],
    secondary: ['resistencia', 'passe', 'drible']
  },
  'VOL': {
    primary: ['marcacao', 'passe', 'forca'],
    secondary: ['posicionamento', 'resistencia', 'cabeceio']
  },
  'MC': {
    primary: ['passe', 'visao_jogo', 'controle_bola'],
    secondary: ['resistencia', 'finalizacao', 'drible']
  },
  'MD': {
    primary: ['passe', 'cruzamento', 'drible'],
    secondary: ['velocidade', 'resistencia', 'finalizacao']
  },
  'ME': {
    primary: ['passe', 'cruzamento', 'drible'],
    secondary: ['velocidade', 'resistencia', 'finalizacao']
  },
  'MEI': {
    primary: ['passe', 'finalizacao', 'drible'],
    secondary: ['visao_jogo', 'controle_bola', 'velocidade']
  },
  'PE': {
    primary: ['drible', 'velocidade', 'finalizacao'],
    secondary: ['passe', 'cruzamento', 'controle_bola']
  },
  'PD': {
    primary: ['drible', 'velocidade', 'finalizacao'],
    secondary: ['passe', 'cruzamento', 'controle_bola']
  },
  'SA': {
    primary: ['finalizacao', 'drible', 'passe'],
    secondary: ['velocidade', 'controle_bola', 'cabeceio']
  },
  'ATA': {
    primary: ['finalizacao', 'cabeceio', 'posicionamento'],
    secondary: ['drible', 'velocidade', 'forca']
  }
};

export function getPositionAttributes(position: Position) {
  return POSITION_WEIGHTS[position] || POSITION_WEIGHTS['MC'];
}

export function generatePlayerAttributes(position: Position, baseRating: number) {
  const weights = getPositionAttributes(position);
  const attributes = {
    primary: {},
    secondary: {},
    other: {}
  };

  // Generate primary attributes (higher values)
  weights.primary.forEach(attr => {
    attributes.primary[attr] = Math.min(99, baseRating + Math.floor(Math.random() * 10));
  });

  // Generate secondary attributes (slightly lower)
  weights.secondary.forEach(attr => {
    attributes.secondary[attr] = Math.min(99, baseRating - 5 + Math.floor(Math.random() * 10));
  });

  return attributes;
}