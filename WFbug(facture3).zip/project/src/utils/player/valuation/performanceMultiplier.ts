import { Player } from '../../../types/player';
import { PlayerStatistics } from '../../../types/player';

interface RecentForm {
  goals: number;
  assists: number;
  averageRating: number;
  minutesPlayed: number;
  cleanSheets?: number;
}

const PERFORMANCE_WEIGHTS = {
  goals: 0.15,
  assists: 0.1,
  rating: 0.5,
  minutes: 0.15,
  cleanSheets: 0.1
};

export function calculatePerformanceMultiplier(
  player: Player,
  recentStats: PlayerStatistics,
  lastGames: number = 5
): number {
  const recentForm = extractRecentForm(recentStats, lastGames);
  
  let multiplier = 1.0;

  // Goals impact
  if (player.posicao === 'FWD') {
    multiplier += (recentForm.goals * PERFORMANCE_WEIGHTS.goals);
  }

  // Assists impact
  if (['MID', 'FWD'].includes(player.posicao)) {
    multiplier += (recentForm.assists * PERFORMANCE_WEIGHTS.assists);
  }

  // Clean sheets impact (for goalkeepers and defenders)
  if (['GK', 'DEF'].includes(player.posicao) && recentForm.cleanSheets) {
    multiplier += (recentForm.cleanSheets * PERFORMANCE_WEIGHTS.cleanSheets);
  }

  // Average rating impact
  const ratingImpact = (recentForm.averageRating - 6.5) * PERFORMANCE_WEIGHTS.rating;
  multiplier += ratingImpact;

  // Playing time impact
  const minutesImpact = (recentForm.minutesPlayed / (90 * lastGames)) * PERFORMANCE_WEIGHTS.minutes;
  multiplier += minutesImpact;

  // Ensure multiplier stays within reasonable bounds
  return Math.max(0.5, Math.min(2.0, multiplier));
}

function extractRecentForm(stats: PlayerStatistics, lastGames: number): RecentForm {
  const gamesPlayed = Math.min(lastGames, stats.jogos);
  
  if (gamesPlayed === 0) {
    return {
      goals: 0,
      assists: 0,
      averageRating: 6.5,
      minutesPlayed: 0,
      cleanSheets: 0
    };
  }

  return {
    goals: stats.gols / gamesPlayed,
    assists: stats.assistencias / gamesPlayed,
    averageRating: stats.media_notas,
    minutesPlayed: stats.minutos_jogados / gamesPlayed,
    cleanSheets: stats.clean_sheets ? stats.clean_sheets / gamesPlayed : undefined
  };
}