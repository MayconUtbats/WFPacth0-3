import { Player } from '../../../types/player';
import { Team } from '../../../types/game';
import { calculateBaseValue } from './baseValue';
import { calculatePerformanceMultiplier } from './performanceMultiplier';
import { calculateMarketMultiplier } from './marketConditions';

export interface PlayerValuation {
  baseValue: number;
  performanceMultiplier: number;
  marketMultiplier: number;
  finalValue: number;
  breakdown: {
    attributes: number;
    recentForm: number;
    marketConditions: number;
  };
}

export function calculatePlayerValue(
  player: Player,
  sellingTeam: Team,
  buyingTeam: Team,
  currentDate: Date
): PlayerValuation {
  // Calculate base value from attributes
  const baseValue = calculateBaseValue(player);

  // Calculate performance multiplier
  const performanceMultiplier = calculatePerformanceMultiplier(
    player,
    player.estatisticas
  );

  // Calculate market conditions multiplier
  const marketMultiplier = calculateMarketMultiplier(
    sellingTeam,
    buyingTeam,
    currentDate
  );

  // Calculate final value
  const finalValue = Math.round(
    baseValue * performanceMultiplier * marketMultiplier
  );

  return {
    baseValue,
    performanceMultiplier,
    marketMultiplier,
    finalValue,
    breakdown: {
      attributes: baseValue,
      recentForm: baseValue * (performanceMultiplier - 1),
      marketConditions: baseValue * (marketMultiplier - 1)
    }
  };
}