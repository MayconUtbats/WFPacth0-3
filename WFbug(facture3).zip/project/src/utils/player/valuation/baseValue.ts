import { Player } from '../../../types/player';

export function calculateBaseValue(player: Player): number {
  // Calculate weighted average of attributes based on position
  const weightedAttributes = getPositionWeights(player.posicao);
  let totalValue = 0;
  let totalWeight = 0;

  // Calculate technical attributes value
  Object.entries(player.atributos.tecnicos).forEach(([attr, value]) => {
    const weight = weightedAttributes.tecnicos[attr] || 1;
    totalValue += value * weight;
    totalWeight += weight;
  });

  // Calculate physical attributes value
  Object.entries(player.atributos.fisicos).forEach(([attr, value]) => {
    const weight = weightedAttributes.fisicos[attr] || 1;
    totalValue += value * weight;
    totalWeight += weight;
  });

  // Calculate mental attributes value
  Object.entries(player.atributos.mentais).forEach(([attr, value]) => {
    const weight = weightedAttributes.mentais[attr] || 1;
    totalValue += value * weight;
    totalWeight += weight;
  });

  // Calculate base value using weighted average
  const averageRating = totalValue / totalWeight;
  
  // Exponential growth for higher-rated players
  return Math.pow(averageRating, 2) * 10000;
}

function getPositionWeights(position: string): any {
  const weights = {
    GK: {
      tecnicos: {
        reflexos: 2.5,
        posicionamento_gol: 2.0,
        jogo_pes: 1.5,
        lancamento: 1.2
      },
      fisicos: {
        salto: 2.0,
        agilidade: 1.8,
        velocidade: 1.0
      },
      mentais: {
        decisao: 2.0,
        compostura: 1.8,
        posicionamento: 1.5
      }
    },
    DEF: {
      tecnicos: {
        defesa: 2.5,
        cabeceio: 1.8,
        passe: 1.2
      },
      fisicos: {
        forca: 2.0,
        velocidade: 1.5,
        resistencia: 1.3
      },
      mentais: {
        posicionamento: 2.0,
        decisao: 1.5,
        trabalho_equipe: 1.3
      }
    },
    MID: {
      tecnicos: {
        passe: 2.5,
        controle_bola: 2.0,
        drible: 1.5
      },
      fisicos: {
        resistencia: 2.0,
        agilidade: 1.5,
        velocidade: 1.3
      },
      mentais: {
        visao_jogo: 2.5,
        decisao: 2.0,
        trabalho_equipe: 1.8
      }
    },
    FWD: {
      tecnicos: {
        finalizacao: 2.5,
        drible: 2.0,
        cabeceio: 1.5
      },
      fisicos: {
        velocidade: 2.0,
        aceleracao: 1.8,
        forca: 1.3
      },
      mentais: {
        posicionamento: 2.0,
        decisao: 1.8,
        compostura: 1.5
      }
    }
  };

  return weights[position] || weights.MID;
}