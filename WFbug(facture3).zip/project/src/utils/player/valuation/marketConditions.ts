import { Team } from '../../../types/game';

interface MarketConditions {
  leagueLevel: number;
  clubReputation: number;
  seasonPhase: 'pre' | 'mid' | 'end';
  transferBudgets: number;
}

const MARKET_WEIGHTS = {
  leagueLevel: 0.3,
  clubReputation: 0.3,
  seasonPhase: 0.2,
  transferBudgets: 0.2
};

export function calculateMarketMultiplier(
  sellingTeam: Team,
  buyingTeam: Team,
  currentDate: Date
): number {
  const conditions = analyzeMarketConditions(sellingTeam, buyingTeam, currentDate);
  
  let multiplier = 1.0;

  // League level impact
  multiplier += (conditions.leagueLevel - 1) * MARKET_WEIGHTS.leagueLevel;

  // Club reputation impact
  multiplier += (conditions.clubReputation - 1) * MARKET_WEIGHTS.clubReputation;

  // Season phase impact
  const seasonPhaseMultiplier = getSeasonPhaseMultiplier(conditions.seasonPhase);
  multiplier += (seasonPhaseMultiplier - 1) * MARKET_WEIGHTS.seasonPhase;

  // Transfer budgets impact
  multiplier += (conditions.transferBudgets - 1) * MARKET_WEIGHTS.transferBudgets;

  // Ensure multiplier stays within reasonable bounds
  return Math.max(0.7, Math.min(1.5, multiplier));
}

function analyzeMarketConditions(
  sellingTeam: Team,
  buyingTeam: Team,
  currentDate: Date
): MarketConditions {
  return {
    leagueLevel: calculateLeagueLevel(sellingTeam, buyingTeam),
    clubReputation: calculateClubReputation(sellingTeam, buyingTeam),
    seasonPhase: determineSeasonPhase(currentDate),
    transferBudgets: analyzeTransferBudgets(buyingTeam)
  };
}

function calculateLeagueLevel(sellingTeam: Team, buyingTeam: Team): number {
  // Higher multiplier for transfers to better leagues
  const sellingLeagueLevel = 4 - sellingTeam.division;
  const buyingLeagueLevel = 4 - buyingTeam.division;
  
  return 1 + (buyingLeagueLevel - sellingLeagueLevel) * 0.1;
}

function calculateClubReputation(sellingTeam: Team, buyingTeam: Team): number {
  // Implement club reputation calculation based on history, achievements, etc.
  return 1.0;
}

function determineSeasonPhase(currentDate: Date): 'pre' | 'mid' | 'end' {
  // Determine current phase of the season
  const month = currentDate.getMonth();
  
  if (month >= 6 && month <= 7) return 'pre';
  if (month >= 4 && month <= 5) return 'end';
  return 'mid';
}

function getSeasonPhaseMultiplier(phase: 'pre' | 'mid' | 'end'): number {
  switch (phase) {
    case 'pre':
      return 1.2; // Higher prices in pre-season
    case 'end':
      return 0.9; // Lower prices at season end
    default:
      return 1.0;
  }
}

function analyzeTransferBudgets(buyingTeam: Team): number {
  // Higher multiplier if buying team has large budget
  const averageBudget = 10000000; // Example average budget
  return 1 + Math.log10(buyingTeam.budget / averageBudget) * 0.1;
}