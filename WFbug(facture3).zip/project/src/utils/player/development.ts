import { Player } from '../../types/player';
import { PlayerPersonality } from '../../types/personality';
import { calculateOverallRating, calculatePotentialGrowth } from './attributeCalculator';

interface DevelopmentFactors {
  trainingQuality: number; // 1-100
  playingTime: number; // Minutes played in last month
  morale: number; // 1-100
  coachingQuality: number; // 1-100
  trainingFocus?: keyof Player['atributos']; // Optional focused training
}

export function simulatePlayerDevelopment(
  player: Player,
  factors: DevelopmentFactors,
  personality: PlayerPersonality
): Player {
  const { idade, atributos } = player;
  const potentialGrowth = calculatePotentialGrowth(player);

  if (potentialGrowth <= 0) return player;

  const developmentRate = calculateDevelopmentRate(player, factors, personality);
  const updatedAttributes = applyDevelopment(
    atributos, 
    developmentRate, 
    factors.trainingFocus
  );

  return {
    ...player,
    atributos: updatedAttributes,
  };
}

function calculateDevelopmentRate(
  player: Player,
  factors: DevelopmentFactors,
  personality: PlayerPersonality
): number {
  const { idade } = player;
  let baseRate = 1.0;

  // Age factor - younger players develop faster
  if (idade <= 18) baseRate *= 1.5;
  else if (idade <= 21) baseRate *= 1.3;
  else if (idade <= 23) baseRate *= 1.1;
  else if (idade > 28) baseRate *= 0.5;

  // Training quality impact
  baseRate *= (factors.trainingQuality / 100) * 1.2;

  // Playing time impact
  const playingTimeImpact = Math.min(1, factors.playingTime / 450);
  baseRate *= (0.5 + playingTimeImpact * 0.5);

  // Morale impact
  baseRate *= (0.8 + (factors.morale / 100) * 0.4);

  // Coaching quality impact
  baseRate *= (0.7 + (factors.coachingQuality / 100) * 0.6);

  // Personality traits impact
  personality.traits.forEach(trait => {
    if (trait.effects.developmentRate) {
      baseRate *= trait.effects.developmentRate;
    }
  });

  // Ambition and professionalism impact
  baseRate *= (0.8 + (personality.ambition / 100) * 0.4);
  baseRate *= (0.8 + (personality.professionalism / 100) * 0.4);

  return baseRate;
}

function applyDevelopment(
  attributes: Player['atributos'],
  developmentRate: number,
  trainingFocus?: keyof Player['atributos']
): Player['atributos'] {
  const updated = JSON.parse(JSON.stringify(attributes));
  const categories = ['tecnicos', 'fisicos', 'mentais'];

  categories.forEach(category => {
    Object.keys(updated[category]).forEach(attr => {
      let improvement = Math.random() * developmentRate;
      
      // Boost focused training attributes
      if (trainingFocus === category) {
        improvement *= 1.5;
      }
      
      const currentValue = updated[category][attr];
      updated[category][attr] = Math.min(100, currentValue + improvement);
    });
  });

  if (updated.goleiro) {
    Object.keys(updated.goleiro).forEach(attr => {
      let improvement = Math.random() * developmentRate;
      
      if (trainingFocus === 'goleiro') {
        improvement *= 1.5;
      }
      
      const currentValue = updated.goleiro[attr];
      updated.goleiro[attr] = Math.min(100, currentValue + improvement);
    });
  }

  return updated;
}

// Add random events that can affect development
export function simulateRandomEvents(player: Player): {
  event: string;
  impact: 'positive' | 'negative';
  description: string;
} | null {
  if (Math.random() > 0.95) { // 5% chance of random event
    const events = [
      {
        event: 'breakthrough',
        impact: 'positive' as const,
        description: 'O jogador teve um momento de evolução excepcional nos treinos!',
        effect: () => ({ developmentBoost: 1.5 })
      },
      {
        event: 'setback',
        impact: 'negative' as const,
        description: 'O jogador está enfrentando dificuldades para evoluir.',
        effect: () => ({ developmentPenalty: 0.5 })
      },
      {
        event: 'motivation',
        impact: 'positive' as const,
        description: 'O jogador está extremamente motivado após feedback positivo.',
        effect: () => ({ moraleBoost: 10 })
      }
    ];

    const randomEvent = events[Math.floor(Math.random() * events.length)];
    randomEvent.effect();
    return randomEvent;
  }

  return null;
}