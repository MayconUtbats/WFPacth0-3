import { countries } from '../data/countries';

const namesByCountry = {
  BRA: {
    firstNames: [
      'Arthur', 'Gabriel', 'Pedro', 'Lucas', 'Matheus',
      'João', 'Thiago', 'Rafael', 'Carlos', 'Victor',
      'Leonardo', 'Felipe', 'Bruno', 'Diego', 'André',
      'Vinicius', 'Rodrigo', 'Marcelo', 'Roberto', 'Paulo',
      'Ronaldo', 'Adriano', 'Neymar', 'Richarlison', 'Casemiro'
    ],
    lastNames: [
      'Silva', 'Santos', 'Oliveira', 'Souza', 'Rodrigues',
      'Ferreira', 'Alves', 'Pereira', 'Lima', 'Costa',
      'Carvalho', 'Gomes', 'Martins', 'Araújo', 'Ribeiro',
      'Nascimento', 'Barbosa', 'Moreira', 'Rocha', 'Cardoso',
      'Junior', 'Filho', 'Peixoto', 'Cavalcanti', 'Monteiro'
    ]
  },
  ENG: {
    firstNames: [
      'James', 'Harry', 'Jack', 'Oliver', 'George',
      'William', 'Thomas', 'John', 'David', 'Michael',
      'Charlie', 'Daniel', 'Joseph', 'Henry', 'Robert',
      'Marcus', 'Phil', 'Mason', 'Declan', 'Jude',
      'Raheem', 'Jordan', 'Trent', 'Kyle', 'Luke'
    ],
    lastNames: [
      'Smith', 'Jones', 'Williams', 'Brown', 'Taylor',
      'Davies', 'Wilson', 'Evans', 'Thomas', 'Johnson',
      'Roberts', 'Walker', 'Wright', 'Thompson', 'White',
      'Hughes', 'Edwards', 'Green', 'Wood', 'Clarke',
      'Kane', 'Sterling', 'Foden', 'Rice', 'Bellingham'
    ]
  },
  ESP: {
    firstNames: [
      'Alejandro', 'David', 'Carlos', 'Javier', 'Miguel',
      'Antonio', 'José', 'Francisco', 'Manuel', 'Diego',
      'Pablo', 'Daniel', 'Sergio', 'Fernando', 'Juan',
      'Pedri', 'Gavi', 'Rodri', 'Dani', 'Alvaro',
      'Iker', 'Xavi', 'Andrés', 'Sergio', 'Gerard'
    ],
    lastNames: [
      'García', 'Rodríguez', 'González', 'Fernández', 'López',
      'Martínez', 'Sánchez', 'Pérez', 'Gómez', 'Martin',
      'Jiménez', 'Ruiz', 'Hernández', 'Díaz', 'Moreno',
      'Torres', 'Ramos', 'Busquets', 'Alba', 'Olmo',
      'Casillas', 'Hernández', 'Iniesta', 'Piqué', 'Silva'
    ]
  }
} as const;

function getRandomElement<T>(array: readonly T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

export function generatePlayerName(countryCode: string = 'BRA'): string {
  const names = namesByCountry[countryCode as keyof typeof namesByCountry];
  if (!names) return generateDefaultName();

  // 20% chance of compound first name for Brazilian players
  if (countryCode === 'BRA' && Math.random() < 0.2) {
    const firstName1 = getRandomElement(names.firstNames);
    const firstName2 = getRandomElement(names.firstNames);
    const lastName = getRandomElement(names.lastNames);
    return `${firstName1} ${firstName2} ${lastName}`;
  }

  // 15% chance of compound last name for Spanish players
  if (countryCode === 'ESP' && Math.random() < 0.15) {
    const firstName = getRandomElement(names.firstNames);
    const lastName1 = getRandomElement(names.lastNames);
    const lastName2 = getRandomElement(names.lastNames);
    return `${firstName} ${lastName1} ${lastName2}`;
  }

  const firstName = getRandomElement(names.firstNames);
  const lastName = getRandomElement(names.lastNames);
  return `${firstName} ${lastName}`;
}

function generateDefaultName(): string {
  return generatePlayerName('BRA');
}

export function getPositionName(position: string): string {
  const positionNames = {
    'GOL': 'Goleiro',
    'ZAG': 'Zagueiro',
    'LD': 'Lateral Direito',
    'LE': 'Lateral Esquerdo',
    'VOL': 'Volante',
    'MC': 'Meio Campista',
    'MD': 'Meia Direita',
    'ME': 'Meia Esquerda',
    'MEI': 'Meia Ofensivo',
    'PE': 'Ponta Esquerda',
    'PD': 'Ponta Direita',
    'SA': 'Segundo Atacante',
    'ATA': 'Atacante'
  };

  return positionNames[position] || position;
}

export function getPositionColor(position: string): string {
  switch (position) {
    case 'GOL':
      return 'bg-yellow-600 text-white';
    case 'ZAG':
    case 'LD':
    case 'LE':
      return 'bg-blue-600 text-white';
    case 'VOL':
    case 'MC':
    case 'MD':
    case 'ME':
    case 'MEI':
      return 'bg-green-600 text-white';
    case 'PE':
    case 'PD':
    case 'SA':
    case 'ATA':
      return 'bg-red-600 text-white';
    default:
      return 'bg-gray-600 text-white';
  }
}