import { Club, ClubFinances } from '../../types/club';

export function updateClubFinances(
  finances: ClubFinances,
  updates: {
    income?: Partial<ClubFinances['income']>;
    expenses?: Partial<ClubFinances['expenses']>;
    transferBudget?: number;
    wageBudget?: number;
  }
): ClubFinances {
  const newFinances = { ...finances };

  // Update income
  if (updates.income) {
    newFinances.income = {
      ...newFinances.income,
      ...updates.income,
    };
  }

  // Update expenses
  if (updates.expenses) {
    newFinances.expenses = {
      ...newFinances.expenses,
      ...updates.expenses,
    };
  }

  // Update budgets
  if (updates.transferBudget !== undefined) {
    newFinances.transferBudget = updates.transferBudget;
  }
  if (updates.wageBudget !== undefined) {
    newFinances.wageBudget = updates.wageBudget;
  }

  // Calculate new balance
  const totalIncome = Object.values(newFinances.income).reduce((a, b) => a + b, 0);
  const totalExpenses = Object.values(newFinances.expenses).reduce((a, b) => a + b, 0);
  newFinances.balance += totalIncome - totalExpenses;

  return newFinances;
}

export function calculateFinancialHealth(finances: ClubFinances): {
  status: 'healthy' | 'stable' | 'concerning' | 'critical';
  score: number;
  recommendations: string[];
} {
  const totalIncome = Object.values(finances.income).reduce((a, b) => a + b, 0);
  const totalExpenses = Object.values(finances.expenses).reduce((a, b) => a + b, 0);
  const monthlyBalance = totalIncome - totalExpenses;
  const wageToIncomeRatio = finances.expenses.wages / totalIncome;

  let score = 100;
  const recommendations: string[] = [];

  // Balance health
  if (finances.balance < 0) {
    score -= 30;
    recommendations.push('Urgent: Negative balance requires immediate attention');
  } else if (finances.balance < totalExpenses * 3) {
    score -= 15;
    recommendations.push('Build up cash reserves to cover at least 3 months of expenses');
  }

  // Monthly cash flow
  if (monthlyBalance < 0) {
    score -= 25;
    recommendations.push('Reduce expenses or increase income to achieve positive cash flow');
  }

  // Wage structure
  if (wageToIncomeRatio > 0.7) {
    score -= 20;
    recommendations.push('Wage expenses are too high relative to income');
  }

  // Determine status
  let status: 'healthy' | 'stable' | 'concerning' | 'critical';
  if (score >= 80) status = 'healthy';
  else if (score >= 60) status = 'stable';
  else if (score >= 40) status = 'concerning';
  else status = 'critical';

  return { status, score, recommendations };
}