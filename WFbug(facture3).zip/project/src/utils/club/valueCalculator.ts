import { Club } from '../../types/club';

export function calculateClubValue(club: Club): number {
  const facilityValue = calculateFacilityValue(club);
  const playerValue = calculateSquadValue(club);
  const reputationValue = calculateReputationValue(club);
  const financialValue = calculateFinancialValue(club);

  return facilityValue + playerValue + reputationValue + financialValue;
}

function calculateFacilityValue(club: Club): number {
  const { stadium, training, youth } = club.facilities;
  
  const stadiumValue = stadium.capacity * 1000 * stadium.condition;
  const trainingValue = training.level * 1000000 * training.condition;
  const youthValue = youth.level * 500000 * youth.facilities;

  return stadiumValue + trainingValue + youthValue;
}

function calculateSquadValue(club: Club): number {
  // This would need to be implemented based on your player value calculation logic
  return club.players.length * 1000000; // Placeholder implementation
}

function calculateReputationValue(club: Club): number {
  const { domestic, continental, global, prestige, fanbase } = club.reputation;
  
  return (
    domestic * 100000 +
    continental * 200000 +
    global * 500000 +
    prestige * 1000000 +
    fanbase * 10000
  );
}

function calculateFinancialValue(club: Club): number {
  const { balance, income } = club.finances;
  
  const yearlyIncome = 
    income.matchday +
    income.commercial +
    income.broadcasting +
    income.prizes;

  return balance + (yearlyIncome * 2);
}