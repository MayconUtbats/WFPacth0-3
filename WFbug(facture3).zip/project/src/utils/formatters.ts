export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`;
  }
  return num.toString();
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    currencyDisplay: 'narrowSymbol'
  }).format(amount).replace('R$', 'Ð');
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(date);
}

export function formatShortDate(date: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: 'numeric',
    month: 'short'
  }).format(date);
}

export function formatTime(minute: number): string {
  const minutes = Math.floor(minute);
  return `${minutes.toString().padStart(2, '0')}:00`;
}

export function formatMatchTime(minute: number): string {
  if (minute <= 45) {
    return `${minute}'`;
  } else if (minute === 45) {
    return "45' (INT)";
  } else if (minute <= 90) {
    return `${minute}'`;
  } else {
    const extraTime = minute - 90;
    return `90+${extraTime}'`;
  }
}