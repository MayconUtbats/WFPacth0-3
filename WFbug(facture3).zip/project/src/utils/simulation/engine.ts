import { Team } from '../../types/game';
import { MatchState, MatchEvent, TeamMatchStats } from '../../types/match';
import { SIMULATION_CONFIG } from './config';
import { generateMatchStartNarrative, generateHalfTimeNarrative, generateHalfTimeStartNarrative } from './narratives/matchStart';
import { generateBuildUpNarrative } from './narratives/buildup';
import { generateTransitionNarrative } from './narratives/transitions';
import { generateGeneralPlayNarrative } from './narratives/generalPlay';

export function simulateMatch(homeTeam: Team, awayTeam: Team): MatchState {
  const initialState = initializeMatchState();
  
  // Add match start event
  initialState.events.push({
    minute: 0,
    type: 'general',
    team: 'none',
    player: homeTeam.players[0], // Captain or first player
    description: generateMatchStartNarrative(),
  });

  return initialState;
}

export function simulateMinute(
  state: MatchState,
  homeTeam: Team,
  awayTeam: Team,
  minute: number
): MatchState {
  const newState = { ...state, minute };

  // Handle half time
  if (minute === 45) {
    newState.events.push({
      minute: 45,
      type: 'general',
      team: 'none',
      player: homeTeam.players[0],
      description: generateHalfTimeNarrative(newState.homeScore, newState.awayScore),
    });
    newState.isHalfTime = true;
    return newState;
  }

  // Handle second half start
  if (minute === 46) {
    newState.events.push({
      minute: 46,
      type: 'general',
      team: 'none',
      player: homeTeam.players[0],
      description: generateHalfTimeStartNarrative(),
    });
  }

  // Simulate multiple events per minute
  for (let i = 0; i < SIMULATION_CONFIG.eventsPerMinute; i++) {
    const eventType = determineEventType();
    const attackingTeam = state.possession === 'home' ? homeTeam : awayTeam;
    const defendingTeam = state.possession === 'home' ? awayTeam : homeTeam;

    let event: MatchEvent | null = null;

    switch (eventType) {
      case 'buildup':
        event = simulateBuildUp(attackingTeam, minute);
        break;
      case 'transition':
        event = simulateTransition(attackingTeam, defendingTeam, minute);
        break;
      case 'general':
        event = simulateGeneralPlay(attackingTeam, defendingTeam, minute);
        break;
    }

    if (event) {
      newState.events.push(event);
      updateMatchStats(newState, event);
    }

    // Update possession
    if (Math.random() < SIMULATION_CONFIG.possessionChangeProbability) {
      newState.possession = newState.possession === 'home' ? 'away' : 'home';
    }
  }

  return newState;
}

function initializeMatchState(): MatchState {
  const initialStats: TeamMatchStats = {
    shots: 0,
    shotsOnTarget: 0,
    possession: 50,
    passes: 0,
    passAccuracy: 0,
    fouls: 0,
    yellowCards: 0,
    redCards: 0,
    corners: 0,
    offsides: 0,
  };

  return {
    minute: 0,
    homeScore: 0,
    awayScore: 0,
    possession: Math.random() > 0.5 ? 'home' : 'away',
    homePossession: 0,
    awayPossession: 0,
    events: [],
    homeStats: { ...initialStats },
    awayStats: { ...initialStats },
    isHalfTime: false,
  };
}

function determineEventType(): 'buildup' | 'transition' | 'general' {
  const random = Math.random();
  
  if (random < SIMULATION_CONFIG.buildupProbability) {
    return 'buildup';
  } else if (random < SIMULATION_CONFIG.buildupProbability + SIMULATION_CONFIG.transitionProbability) {
    return 'transition';
  } else {
    return 'general';
  }
}

function simulateBuildUp(team: Team, minute: number): MatchEvent {
  const player = selectRandomPlayer(team);
  return {
    minute,
    type: 'buildup',
    team: team.id,
    player,
    description: generateBuildUpNarrative(player, team, 'middle'),
  };
}

function simulateTransition(attackingTeam: Team, defendingTeam: Team, minute: number): MatchEvent {
  const player = selectRandomPlayer(attackingTeam);
  return {
    minute,
    type: 'transition',
    team: attackingTeam.id,
    player,
    description: generateTransitionNarrative(player, attackingTeam, 'defense-to-attack'),
  };
}

function simulateGeneralPlay(attackingTeam: Team, defendingTeam: Team, minute: number): MatchEvent {
  const player = selectRandomPlayer(attackingTeam);
  return {
    minute,
    type: 'general',
    team: attackingTeam.id,
    player,
    description: generateGeneralPlayNarrative(player, attackingTeam, 'midfield'),
  };
}

function selectRandomPlayer(team: Team): Player {
  return team.players[Math.floor(Math.random() * team.players.length)];
}

function updateMatchStats(state: MatchState, event: MatchEvent): void {
  const stats = event.team === 'home' ? state.homeStats : state.awayStats;
  
  switch (event.type) {
    case 'goal':
      stats.shots++;
      stats.shotsOnTarget++;
      if (event.team === 'home') {
        state.homeScore++;
      } else {
        state.awayScore++;
      }
      break;
    case 'buildup':
      stats.passes += Math.floor(Math.random() * 3) + 1;
      stats.passAccuracy = Math.min(100, stats.passAccuracy + Math.random() * 2);
      break;
    case 'transition':
      stats.passes++;
      if (Math.random() > 0.3) {
        stats.passAccuracy = Math.min(100, stats.passAccuracy + 1);
      }
      break;
  }

  // Update possession stats
  if (state.possession === 'home') {
    state.homePossession++;
    state.homeStats.possession = (state.homePossession / state.minute) * 100;
  } else {
    state.awayPossession++;
    state.awayStats.possession = (state.awayPossession / state.minute) * 100;
  }
}