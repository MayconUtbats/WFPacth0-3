export const SIMULATION_CONFIG = {
  // Match timing
  matchDuration: 90,
  eventsPerMinute: 3,
  simulationSpeed: 1000, // 1 second per minute
  halfTimeBreak: 5000, // 5 seconds break
  
  // Event probabilities per minute
  baseGoalChance: 0.05,
  chanceCreationProbability: 0.3,
  possessionChangeProbability: 0.2,
  tackleProbability: 0.15,
  cardProbability: 0.03,
  injuryProbability: 0.01,
  
  // General play probabilities
  buildupProbability: 0.4,
  transitionProbability: 0.2,
  generalPlayProbability: 0.4,
  
  // Match factors
  homeAdvantage: 1.2,
  momentumFactor: 1.15,
  fatigueFactor: 0.9,
};