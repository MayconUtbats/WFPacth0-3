import { Player } from '../../types/game';

export interface MatchState {
  minute: number;
  homeScore: number;
  awayScore: number;
  possession: 'home' | 'away';
  homePossession: number;
  awayPossession: number;
  events: MatchEvent[];
  homeStats: TeamMatchStats;
  awayStats: TeamMatchStats;
}

export interface MatchEvent {
  minute: number;
  type: 'goal' | 'card' | 'injury' | 'substitution';
  team: 'home' | 'away';
  player: Player;
  description: string;
  assistPlayer?: Player;
}

export interface TeamMatchStats {
  shots: number;
  shotsOnTarget: number;
  possession: number;
  passes: number;
  passAccuracy: number;
  fouls: number;
  yellowCards: number;
  redCards: number;
  corners: number;
  offsides: number;
}

export interface MatchResult {
  homeScore: number;
  awayScore: number;
  events: MatchEvent[];
  stats: {
    home: TeamMatchStats;
    away: TeamMatchStats;
  };
  extraTime?: {
    homeScore: number;
    awayScore: number;
  };
  penalties?: {
    homeScore: number;
    awayScore: number;
  };
}

export interface PlayerPerformance {
  player: Player;
  rating: number;
  goals: number;
  assists: number;
  shotsOnTarget: number;
  passes: number;
  tackles: number;
  fouls: number;
  cards: {
    yellow: number;
    red: number;
  };
  minutesPlayed: number;
}