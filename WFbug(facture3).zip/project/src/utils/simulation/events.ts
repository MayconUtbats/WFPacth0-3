import { MatchEvent, MatchState } from '../../types/match';
import { Team, Player } from '../../types/game';

export function generateMatchEvent(
  state: MatchState,
  type: 'goal' | 'card' | 'injury' | 'chance' | 'possession' | 'tackle',
  team: 'home' | 'away',
  currentTeam: Team,
  minute: number
): MatchEvent {
  const player = selectPlayerForEvent(currentTeam, type);
  let description = '';
  let assistPlayer: Player | undefined;

  switch (type) {
    case 'goal':
      const goalDetails = generateGoalDescription(player, currentTeam, state);
      description = goalDetails.description;
      assistPlayer = goalDetails.assist;
      break;
    case 'card':
      description = generateCardDescription(player, state);
      break;
    case 'injury':
      description = generateInjuryDescription(player);
      break;
    case 'chance':
      description = generateChanceDescription(player, currentTeam);
      break;
    case 'possession':
      description = generatePossessionDescription(player, currentTeam);
      break;
    case 'tackle':
      description = generateTackleDescription(player, currentTeam);
      break;
  }

  return {
    minute,
    type,
    team,
    player,
    assistPlayer,
    description
  };
}

function generateGoalDescription(scorer: Player, team: Team, state: MatchState): { description: string; assist?: Player } {
  const assist = selectPlayerForEvent(team, 'assist');
  
  const goalTypes = [
    {
      type: 'long_shot',
      description: `⚽ GOLAÇO! ${scorer.name} acerta um chute impressionante de fora da área! Uma pintura no ângulo! A torcida vai à loucura com esse golaço indefensável!`,
      probability: 0.15
    },
    {
      type: 'team_play',
      description: `⚽ Que jogada espetacular! ${assist.name} faz um passe magistral entre os zagueiros, ${scorer.name} domina com categoria e finaliza com precisão cirúrgica! Goleiro não teve chance!`,
      probability: 0.25,
      requiresAssist: true
    },
    {
      type: 'header',
      description: `⚽ ${scorer.name} sobe mais alto que todo mundo e marca um golaço de cabeça! ${assist.name} fez um cruzamento perfeito na medida, impossível defender!`,
      probability: 0.2,
      requiresAssist: true
    },
    {
      type: 'dribble',
      description: `⚽ IMPRESSIONANTE! ${scorer.name} dribla um, dribla dois, deixa a defesa toda no chão e marca um gol antológico! Que jogada fenomenal!`,
      probability: 0.15
    },
    {
      type: 'counter',
      description: `⚽ Contra-ataque fulminante! ${assist.name} rouba a bola no meio-campo e lança ${scorer.name} que dispara em velocidade, dribla o goleiro e marca com muita classe!`,
      probability: 0.15,
      requiresAssist: true
    },
    {
      type: 'one_touch',
      description: `⚽ Que categoria! ${assist.name} cruza rasteiro e ${scorer.name} finaliza de primeira, com um toque sutil que encobre o goleiro! Golaço de pura técnica!`,
      probability: 0.1,
      requiresAssist: true
    },
    {
      type: 'free_kick',
      description: `⚽ OBRA DE ARTE! ${scorer.name} cobra a falta com perfeição, a bola faz uma curva impossível e morre no ângulo! Goleiro só olhou, não havia o que fazer!`,
      probability: 0.1
    },
    {
      type: 'penalty',
      description: `⚽ ${scorer.name} mostra frieza na cobrança do pênalti! Bola de um lado, goleiro do outro! Batida com categoria e precisão!`,
      probability: 0.1
    }
  ];

  const random = Math.random();
  let accumulatedProbability = 0;
  
  for (const goalType of goalTypes) {
    accumulatedProbability += goalType.probability;
    if (random <= accumulatedProbability) {
      return {
        description: goalType.description,
        assist: goalType.requiresAssist ? assist : undefined
      };
    }
  }

  return {
    description: `⚽ ${scorer.name} marca o gol!`,
    assist: undefined
  };
}

function generateChanceDescription(player: Player, team: Team): string {
  const chances = [
    `🎯 Que chance incrível! ${player.name} recebe dentro da área, gira bonito mas o goleiro faz uma defesa espetacular!`,
    `💫 Quase um golaço! ${player.name} arrisca de fora da área, a bola explode no travessão! Que finalização sensacional!`,
    `⚡ ${player.name} faz jogada individual brilhante, deixa dois marcadores para trás mas na hora do chute a bola sai raspando a trave!`,
    `🔥 Linda tabela! ${player.name} recebe na entrada da área, mas a defesa consegue bloquear o chute no último instante!`,
    `💨 Contra-ataque perigoso! ${player.name} dispara em velocidade, invade a área mas o goleiro sai muito bem e fecha o ângulo!`,
    `🌟 Que jogada! ${player.name} dribla o marcador com um lindo drible, mas na hora da finalização acaba chutando por cima do gol!`,
    `⚔️ ${player.name} recebe um cruzamento perfeito na pequena área, cabeceia firme mas o goleiro faz um milagre! Que defesa!`,
    `🎭 Linda jogada coletiva! ${player.name} finaliza de primeira após tabela, mas a bola passa tirando tinta da trave!`
  ];

  return chances[Math.floor(Math.random() * chances.length)];
}

function generateCardDescription(player: Player, state: MatchState): string {
  const isRed = Math.random() < 0.2;
  
  if (isRed) {
    const redCardReasons = [
      `🟥 EXPULSO! ${player.name} faz entrada duríssima por trás, sem chance de jogar a bola. Juiz não perdoa e mostra o cartão vermelho!`,
      `🟥 ${player.name} recebe o vermelho direto após entrada violenta que coloca em risco a integridade física do adversário!`,
      `🟥 Segundo amarelo e vermelho! ${player.name} comete falta tática, já estava advertido e agora está fora do jogo!`,
      `🟥 Confusão em campo! ${player.name} se desentende com adversário e recebe vermelho direto após conduta antidesportiva!`
    ];
    return redCardReasons[Math.floor(Math.random() * redCardReasons.length)];
  }

  const yellowCardReasons = [
    `🟨 Cartão amarelo para ${player.name} após falta tática para parar contra-ataque perigoso!`,
    `🟨 ${player.name} chega atrasado na dividida, faz falta dura e recebe amarelo justamente!`,
    `🟨 Advertência para ${player.name}! Muita reclamação com a arbitragem após lance polêmico!`,
    `🟨 Falta perigosa de ${player.name} próxima à área! Juiz aplica o amarelo e marca tiro livre!`,
    `🟨 ${player.name} retarda a reposição de bola e recebe amarelo por anti-jogo!`
  ];

  return yellowCardReasons[Math.floor(Math.random() * yellowCardReasons.length)];
}

function generateInjuryDescription(player: Player): string {
  const injuries = [
    `🚑 Preocupante! ${player.name} sente dores musculares após sprint e precisa ser substituído imediatamente!`,
    `🚑 Lance forte resulta em lesão! ${player.name} torce o tornozelo após dividida e não tem condições de continuar!`,
    `🚑 ${player.name} cai no gramado sentindo a posterior da coxa, departamento médico é acionado às pressas!`,
    `🚑 Momento tenso! ${player.name} se choca com adversário e fica caído em campo, médicos entram para atendimento!`,
    `🚑 Problema para a equipe! ${player.name} sinaliza que não pode continuar após sentir dores no joelho!`
  ];

  return injuries[Math.floor(Math.random() * injuries.length)];
}

function generatePossessionDescription(player: Player, team: Team): string {
  const possessionEvents = [
    `👟 ${player.name} cadencia o jogo no meio-campo, organizando a construção das jogadas com categoria!`,
    `🎯 Troca de passes envolvente! ${player.name} comanda o meio-campo e dita o ritmo da partida!`,
    `⚡ ${player.name} avança pelo campo com a bola dominada, procurando espaços na defesa adversária!`,
    `🔄 Que passe! ${player.name} inverte o jogo com categoria, mudando o eixo da jogada!`,
    `🎭 ${player.name} mostra personalidade, mantém a posse e organiza o ataque com inteligência!`,
    `🌟 Linda triangulação! ${player.name} participa de jogada de primeira, time mantém o controle!`
  ];

  return possessionEvents[Math.floor(Math.random() * possessionEvents.length)];
}

function generateTackleDescription(player: Player, team: Team): string {
  const tackles = [
    `💪 Que desarme! ${player.name} chega com precisão e categoria, recuperando a bola de forma limpa!`,
    `🛡️ ${player.name} faz uma interceptação crucial, cortando uma jogada muito perigosa do adversário!`,
    `⚔️ Grande lance defensivo! ${player.name} se antecipa e rouba a bola com perfeição!`,
    `🔒 Defesa impecável! ${player.name} fecha o espaço e não dá chances ao atacante!`,
    `🎯 ${player.name} mostra todo seu poder defensivo, realizando um carrinho perfeito e legal!`,
    `💫 Que leitura de jogo! ${player.name} antecipa a jogada e recupera a posse com categoria!`
  ];

  return tackles[Math.floor(Math.random() * tackles.length)];
}

function selectPlayerForEvent(team: Team, eventType: string): Player {
  const weights = team.players.map(player => {
    switch (eventType) {
      case 'goal':
        return getGoalScoringWeight(player);
      case 'assist':
        return getAssistWeight(player);
      case 'tackle':
        return getDefensiveWeight(player);
      default:
        return 1;
    }
  });

  const totalWeight = weights.reduce((sum, w) => sum + w, 0);
  let random = Math.random() * totalWeight;

  for (let i = 0; i < weights.length; i++) {
    random -= weights[i];
    if (random <= 0) return team.players[i];
  }

  return team.players[0];
}

function getGoalScoringWeight(player: Player): number {
  switch (player.position) {
    case 'FWD': return player.rating * 2;
    case 'MID': return player.rating * 1.5;
    case 'DEF': return player.rating * 0.5;
    case 'GK': return player.rating * 0.1;
    default: return player.rating;
  }
}

function getAssistWeight(player: Player): number {
  switch (player.position) {
    case 'MID': return player.rating * 2;
    case 'FWD': return player.rating * 1.5;
    case 'DEF': return player.rating * 1;
    case 'GK': return player.rating * 0.2;
    default: return player.rating;
  }
}

function getDefensiveWeight(player: Player): number {
  switch (player.position) {
    case 'DEF': return player.rating * 2;
    case 'MID': return player.rating * 1.5;
    case 'FWD': return player.rating * 0.5;
    case 'GK': return player.rating * 0.1;
    default: return player.rating;
  }
}