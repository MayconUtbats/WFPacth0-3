import { Team } from '../../types/game';

export interface TacticalSetup {
  formation: string;
  style: 'possession' | 'counter' | 'direct';
  pressing: 'high' | 'medium' | 'low';
  width: 'wide' | 'balanced' | 'narrow';
  tempo: 'fast' | 'balanced' | 'slow';
}

export function calculateTacticalBonus(
  team: Team,
  tactics: TacticalSetup,
  opposition: Team
): number {
  let bonus = 1.0;

  // Formation compatibility with players
  bonus *= calculateFormationFit(team, tactics.formation);
  
  // Style effectiveness
  if (tactics.style === 'possession') {
    bonus *= team.players.reduce((acc, player) => 
      acc + (player.rating * 0.01), 0) / team.players.length;
  }

  // Pressing effectiveness based on team stamina
  if (tactics.pressing === 'high') {
    const averageStamina = team.players.reduce((acc, player) => 
      acc + player.stamina, 0) / team.players.length;
    bonus *= (averageStamina / 100);
  }

  return bonus;
}

function calculateFormationFit(team: Team, formation: string): number {
  // Calculate how well players fit their positions in the formation
  const positions = formation.split('-');
  const defCount = Number(positions[0]);
  const midCount = Number(positions[1]);
  const fwdCount = Number(positions[2]);

  const defenders = team.players.filter(p => p.position === 'DEF').length;
  const midfielders = team.players.filter(p => p.position === 'MID').length;
  const forwards = team.players.filter(p => p.position === 'FWD').length;

  const fit = (
    Math.min(defenders / defCount, 1) +
    Math.min(midfielders / midCount, 1) +
    Math.min(forwards / fwdCount, 1)
  ) / 3;

  return 0.8 + (fit * 0.4); // Base 0.8 with up to 0.4 bonus for perfect fit
}