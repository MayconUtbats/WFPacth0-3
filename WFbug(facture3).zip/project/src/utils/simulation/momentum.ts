import { MatchState } from './types';
import { Team } from '../../types/game';

export interface MomentumFactors {
  recentGoals: number;
  possession: number;
  successfulActions: number;
  morale: number;
}

export function calculateMomentum(
  state: MatchState,
  team: Team,
  isHome: boolean
): number {
  const momentum: MomentumFactors = {
    recentGoals: 0,
    possession: 0,
    successfulActions: 0,
    morale: 1
  };

  // Recent goals impact (last 15 minutes)
  const recentEvents = state.events
    .filter(e => e.type === 'goal' && 
      e.team === (isHome ? 'home' : 'away') &&
      state.minute - e.minute <= 15);
  
  momentum.recentGoals = recentEvents.length * 0.2;

  // Possession impact
  const possessionPercentage = isHome ? 
    state.homeStats.possession : 
    state.awayStats.possession;
  momentum.possession = (possessionPercentage > 55 ? 0.1 : 0) +
    (possessionPercentage > 65 ? 0.1 : 0);

  // Successful actions (passes, shots on target)
  const stats = isHome ? state.homeStats : state.awayStats;
  momentum.successfulActions = 
    (stats.passAccuracy > 80 ? 0.1 : 0) +
    (stats.shotsOnTarget > 3 ? 0.1 : 0);

  // Calculate total momentum
  return 1 + momentum.recentGoals + momentum.possession + 
    momentum.successfulActions + (momentum.morale - 1);
}