import { Player } from '../../types/game';
import { SIMULATION_CONFIG } from './config';

export function calculatePlayerImpact(player: Player, context: 'attack' | 'defense'): number {
  const { technical, physical, mental } = SIMULATION_CONFIG;
  let impact = 0;
  
  // Technical attributes
  if (context === 'attack') {
    impact += player.rating * technical.passing.weight;
    impact += player.rating * technical.shooting.weight;
    impact += player.rating * technical.dribbling.weight;
  } else {
    impact += player.rating * technical.tackling.weight;
  }
  
  // Physical attributes
  impact += player.rating * physical.speed.weight;
  impact += player.rating * physical.strength.weight;
  impact += player.stamina * physical.stamina.weight;
  impact += player.rating * physical.agility.weight;
  
  // Mental attributes
  impact += player.rating * mental.decisions.weight;
  impact += player.rating * mental.positioning.weight;
  impact += player.rating * mental.workRate.weight;
  
  // Position-based modifiers
  const positionModifier = getPositionModifier(player.position, context);
  impact *= positionModifier;
  
  return impact;
}

function getPositionModifier(position: string, context: 'attack' | 'defense'): number {
  if (context === 'attack') {
    switch (position) {
      case 'FWD': return 1.3;
      case 'MID': return 1.1;
      case 'DEF': return 0.7;
      case 'GK': return 0.3;
      default: return 1.0;
    }
  } else {
    switch (position) {
      case 'FWD': return 0.7;
      case 'MID': return 1.0;
      case 'DEF': return 1.3;
      case 'GK': return 1.5;
      default: return 1.0;
    }
  }
}