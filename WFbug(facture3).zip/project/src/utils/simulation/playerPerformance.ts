import { Player } from '../../types/game';
import { MatchEvent, PlayerPerformance } from './types';

export function calculatePlayerPerformances(
  players: Player[],
  events: MatchEvent[]
): PlayerPerformance[] {
  return players.map(player => {
    const performance: PlayerPerformance = {
      player,
      rating: calculateBaseRating(player),
      goals: countPlayerEvents(player, events, 'goal'),
      assists: countPlayerAssists(player, events),
      shotsOnTarget: 0,
      passes: 0,
      tackles: 0,
      fouls: countPlayerEvents(player, events, 'card'),
      cards: {
        yellow: countPlayerYellowCards(player, events),
        red: countPlayerRedCards(player, events),
      },
      minutesPlayed: 90,
    };

    // Adjust rating based on performance
    performance.rating = adjustRating(performance);

    return performance;
  });
}

function calculateBaseRating(player: Player): number {
  return player.rating * (player.stamina / 100);
}

function countPlayerEvents(
  player: Player,
  events: MatchEvent[],
  type: 'goal' | 'card' | 'injury'
): number {
  return events.filter(event => 
    event.type === type && event.player.id === player.id
  ).length;
}

function countPlayerAssists(player: Player, events: MatchEvent[]): number {
  return events.filter(event => 
    event.type === 'goal' && 
    event.assistPlayer?.id === player.id
  ).length;
}

function countPlayerYellowCards(player: Player, events: MatchEvent[]): number {
  return events.filter(event =>
    event.type === 'card' &&
    event.player.id === player.id &&
    event.description.includes('amarelo')
  ).length;
}

function countPlayerRedCards(player: Player, events: MatchEvent[]): number {
  return events.filter(event =>
    event.type === 'card' &&
    event.player.id === player.id &&
    event.description.includes('vermelho')
  ).length;
}

function adjustRating(performance: PlayerPerformance): number {
  let rating = performance.rating;

  // Adjust for goals
  rating += performance.goals * 0.5;

  // Adjust for assists
  rating += performance.assists * 0.3;

  // Adjust for cards
  rating -= performance.cards.yellow * 0.2;
  rating -= performance.cards.red * 0.5;

  // Cap rating between 0 and 10
  return Math.max(0, Math.min(10, rating));
}