import { Player, Team } from '../../../types/game';

export function generateGeneralPlayNarrative(
  player: Player,
  team: Team,
  phase: 'attack' | 'midfield' | 'defense'
): string {
  switch (phase) {
    case 'attack':
      return generateAttackingPlayNarrative(player, team);
    case 'midfield':
      return generateMidfieldPlayNarrative(player, team);
    case 'defense':
      return generateDefensivePlayNarrative(player, team);
    default:
      return generateMidfieldPlayNarrative(player, team);
  }
}

function generateAttackingPlayNarrative(player: Player, team: Team): string {
  const attackingPlays = [
    `${player.name} tenta uma jogada pela direita, mas a defesa está bem postada`,
    `Bola longa buscando ${player.name} na área, mas sai muito forte pela linha de fundo`,
    `${player.name} tenta o drible, mas a defesa consegue afastar o perigo`,
    `Cruzamento fechado de ${player.name}, goleiro sai bem do gol e faz a defesa`,
    `${player.name} arrisca de longe, mas a bola sai sem perigo pela linha de fundo`,
    `Boa movimentação de ${player.name} pela esquerda, mas perde o controle da bola`,
    `${player.name} tenta tabela na entrada da área, mas a defesa intercepta`,
    `Bola espirrada sobra para ${player.name}, mas estava impedido no lance`,
    `${player.name} tenta jogada individual, mas é desarmado com categoria`,
    `Lançamento em profundidade para ${player.name}, mas goleiro sai bem do gol e fica com a bola`
  ];

  return attackingPlays[Math.floor(Math.random() * attackingPlays.length)];
}

function generateMidfieldPlayNarrative(player: Player, team: Team): string {
  const midfieldPlays = [
    `${player.name} troca passes no meio-campo, equipe tenta encontrar espaços`,
    `Boa movimentação de ${player.name}, time trabalha a bola com paciência`,
    `${player.name} recebe no meio e tenta virar o jogo, bola sai pela lateral`,
    `Troca de passes entre a defesa e ${player.name}, time administra a posse`,
    `${player.name} tenta passe em profundidade, mas bola sai muito forte`,
    `Marcação pressiona ${player.name}, que recua para reorganizar a jogada`,
    `${player.name} faz o pivô no meio-campo e tenta abrir o jogo`,
    `Bola chega em ${player.name}, que tenta acelerar o jogo mas é desarmado`,
    `${player.name} recebe livre, mas demora para decidir e perde a bola`,
    `Boa cobertura defensiva em ${player.name}, que não consegue progredir`
  ];

  return midfieldPlays[Math.floor(Math.random() * midfieldPlays.length)];
}

function generateDefensivePlayNarrative(player: Player, team: Team): string {
  const defensivePlays = [
    `${player.name} afasta o perigo e manda para lateral, defesa se reorganiza`,
    `Boa cobertura de ${player.name}, cortando o lance sem fazer falta`,
    `${player.name} sobe bem no alto e ganha a disputa pelo alto`,
    `Defesa bem postada com ${player.name} comandando a linha defensiva`,
    `${player.name} faz o recuo para o goleiro, time tenta sair jogando`,
    `Boa antecipação de ${player.name}, interceptando o passe e iniciando contra-ataque`,
    `${player.name} marca forte na saída de bola e força o erro do adversário`,
    `Bom posicionamento de ${player.name}, fechando os espaços na defesa`,
    `${player.name} faz cobertura na lateral e cede o escanteio`,
    `Defesa atenta com ${player.name} orientando o posicionamento da equipe`
  ];

  return defensivePlays[Math.floor(Math.random() * defensivePlays.length)];
}