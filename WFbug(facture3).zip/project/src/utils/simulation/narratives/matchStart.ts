export function generateMatchStartNarrative(): string {
  const startNarratives = [
    "🏟️ As equipes entram em campo! A atmosfera é eletrizante enquanto os jogadores se preparam para o início da partida.",
    "🎭 Os capitães se encontram no centro do campo para o sorteio inicial, enquanto as torcidas fazem uma festa nas arquibancadas!",
    "⚽ Times perfilados para o início do jogo! A bola vai rolar em instantes nesse duelo que promete grandes emoções!",
    "🌟 O árbitro confere os últimos detalhes enquanto os jogadores se posicionam. A expectativa toma conta do estádio!",
    "🎪 Que ambiente fantástico! As equipes completam o aquecimento e se preparam para mais um espetáculo do futebol!",
    "🔥 A torcida está em festa! Os times entram em campo sob aplausos ensurdecedores das arquibancadas!",
    "🌈 O gramado está em condições perfeitas para esse grande duelo que está prestes a começar!",
    "🎯 Os goleiros fazem os últimos aquecimentos enquanto os jogadores se cumprimentam no centro do campo!",
    "🎼 O hino ecoa pelo estádio enquanto os times se alinham para o início desta partida!",
    "⭐ Tudo pronto para mais um grande espetáculo do futebol! A bola vai rolar em instantes!"
  ];

  return startNarratives[Math.floor(Math.random() * startNarratives.length)];
}

export function generateHalfTimeStartNarrative(): string {
  const halfTimeStartNarratives = [
    "🔄 Times de volta para a segunda etapa! Vamos ver quais ajustes os técnicos fizeram no intervalo.",
    "⚡ Bola rolando para o segundo tempo! As equipes retornam com tudo em busca da vitória.",
    "🎯 Começa a etapa final! Os jogadores parecem renovados após o descanso do intervalo.",
    "🌟 Segunda etapa em andamento! Momento decisivo da partida com os times buscando seus objetivos.",
    "🔥 Recomeça o jogo! A intensidade promete ser ainda maior neste segundo tempo.",
    "🌈 Os times voltam com mudanças táticas para a etapa final! Vamos ver como isso afetará o jogo.",
    "⚔️ Começa o segundo tempo! As equipes parecem mais dispostas após as orientações do intervalo.",
    "🎭 A bola volta a rolar! Momento crucial da partida com os times ajustados taticamente.",
    "💫 Segunda etapa iniciada! Os times retornam determinados a mudar o panorama do jogo.",
    "⭐ Tudo pronto para os últimos 45 minutos! As equipes prometem ainda mais emoções nesta etapa final."
  ];

  return halfTimeStartNarratives[Math.floor(Math.random() * halfTimeStartNarratives.length)];
}

export function generateHalfTimeNarrative(homeScore: number, awayScore: number): string {
  const baseNarratives = [
    `⏸️ Fim do primeiro tempo! ${getScoreNarrative(homeScore, awayScore)}`,
    `🔔 O árbitro apita e encerra a primeira etapa! ${getScoreNarrative(homeScore, awayScore)}`,
    `⌛ Intervalo! ${getScoreNarrative(homeScore, awayScore)}`,
    `🌟 Final do primeiro tempo! ${getScoreNarrative(homeScore, awayScore)}`,
    `🎭 O árbitro encerra a primeira etapa! ${getScoreNarrative(homeScore, awayScore)}`
  ];

  return baseNarratives[Math.floor(Math.random() * baseNarratives.length)];
}

function getScoreNarrative(homeScore: number, awayScore: number): string {
  if (homeScore === awayScore) {
    return `Placar igualado em ${homeScore} a ${awayScore}.`;
  } else if (homeScore > awayScore) {
    return `Time da casa vence por ${homeScore} a ${awayScore}.`;
  } else {
    return `Visitantes na frente: ${awayScore} a ${homeScore}.`;
  }
}