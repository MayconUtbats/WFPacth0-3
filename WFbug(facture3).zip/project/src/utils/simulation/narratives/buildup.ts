import { Player, Team } from '../../../types/game';

export function generateBuildUpNarrative(
  player: Player,
  team: Team,
  phase: 'initial' | 'middle' | 'final'
): string {
  switch (phase) {
    case 'initial':
      return generateInitialBuildUpNarrative(player, team);
    case 'middle':
      return generateMiddleBuildUpNarrative(player, team);
    case 'final':
      return generateFinalBuildUpNarrative(player, team);
    default:
      return generateMiddleBuildUpNarrative(player, team);
  }
}

function generateInitialBuildUpNarrative(player: Player, team: Team): string {
  const buildups = [
    `${player.name} inicia a construção tocando curto com os zagueiros`,
    `Saída de bola com ${player.name} buscando opções pelo meio`,
    `${player.name} trabalha a bola com calma no campo de defesa`,
    `Time tenta sair jogando com ${player.name} organizando a jogada`,
    `${player.name} recebe do goleiro e busca companheiros adiantados`,
    `Construção paciente com ${player.name} no primeiro passe`,
    `${player.name} toca curto, equipe tenta encontrar espaços`,
    `Bola com ${player.name}, que procura opções para iniciar jogada`,
    `${player.name} recebe livre e inicia nova tentativa de ataque`,
    `Time trabalha a bola desde trás com ${player.name}`
  ];

  return buildups[Math.floor(Math.random() * buildups.length)];
}

function generateMiddleBuildUpNarrative(player: Player, team: Team): string {
  const buildups = [
    `${player.name} faz o pivô no meio e abre para as pontas`,
    `Boa movimentação com ${player.name} articulando no meio-campo`,
    `${player.name} troca passes rápidos buscando espaços`,
    `Time circula a bola com ${player.name} no comando das ações`,
    `${player.name} recebe e gira procurando companheiros`,
    `Troca de passes envolvente com ${player.name} no meio`,
    `${player.name} puxa contra-ataque após roubada de bola`,
    `Boa inversão de ${player.name} mudando o lado do jogo`,
    `${player.name} acelera o jogo buscando penetração`,
    `Time mantém posse com ${player.name} cadenciando o ritmo`
  ];

  return buildups[Math.floor(Math.random() * buildups.length)];
}

function generateFinalBuildUpNarrative(player: Player, team: Team): string {
  const buildups = [
    `${player.name} tenta penetração na área adversária`,
    `Boa tabela com ${player.name} próximo à área`,
    `${player.name} busca espaço para finalização`,
    `Time chega com perigo através de ${player.name}`,
    `${player.name} tenta jogada individual pela ponta`,
    `Bola chega em ${player.name} em posição promissora`,
    `${player.name} recebe na entrada da área e tenta a jogada`,
    `Time trabalha a bola com ${player.name} próximo à área`,
    `${player.name} tenta encontrar companheiro livre na área`,
    `Boa movimentação ofensiva com ${player.name} no comando`
  ];

  return buildups[Math.floor(Math.random() * buildups.length)];
}