import { Player, Team } from '../../../types/game';

export function generateTransitionNarrative(
  player: Player,
  team: Team,
  type: 'attack-to-defense' | 'defense-to-attack'
): string {
  if (type === 'attack-to-defense') {
    return generateDefensiveTransitionNarrative(player, team);
  } else {
    return generateOffensiveTransitionNarrative(player, team);
  }
}

function generateOffensiveTransitionNarrative(player: Player, team: Team): string {
  const transitions = [
    `${player.name} rouba a bola e inicia rápido contra-ataque`,
    `Boa recuperação de ${player.name}, time parte em velocidade`,
    `${player.name} intercepta o passe e aciona o ataque rapidamente`,
    `Bola sobra para ${player.name} que tenta pegar a defesa desorganizada`,
    `${player.name} ganha dividida importante e time tenta surpreender no contra-ataque`,
    `Saída rápida com ${player.name} após recuperação da posse`,
    `${player.name} aciona o atacante em velocidade após roubada de bola`,
    `Transição rápida iniciada por ${player.name} pelo meio-campo`,
    `${player.name} aproveita espaço e conduz bola em velocidade`,
    `Boa leitura de ${player.name} para roubar a bola e iniciar contra-golpe`
  ];

  return transitions[Math.floor(Math.random() * transitions.length)];
}

function generateDefensiveTransitionNarrative(player: Player, team: Team): string {
  const transitions = [
    `${player.name} faz falta tática para parar contra-ataque perigoso`,
    `Time se recompõe rapidamente com ${player.name} organizando a marcação`,
    `${player.name} fecha espaço e força recuo do ataque adversário`,
    `Boa recomposição defensiva com ${player.name} retornando rapidamente`,
    `${player.name} temporiza e permite equipe se reorganizar defensivamente`,
    `Marcação pressiona com ${player.name} liderando a recuperação`,
    `${player.name} acompanha corrida do atacante e evita progressão`,
    `Time volta compacto com ${player.name} coordenando o posicionamento`,
    `${player.name} retorna para ajudar na marcação após perda de bola`,
    `Boa cobertura de ${player.name} impedindo contra-ataque perigoso`
  ];

  return transitions[Math.floor(Math.random() * transitions.length)];
}