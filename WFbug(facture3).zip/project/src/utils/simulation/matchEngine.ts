import { Team } from '../../types/game';
import { MatchState, MatchEvent, MatchResult } from '../../types/match';
import { SIMULATION_CONFIG } from './config';
import { generateBuildUpNarrative } from './narratives/buildup';
import { generateTransitionNarrative } from './narratives/transitions';
import { generateGeneralPlayNarrative } from './narratives/generalPlay';

export function simulateMatch(homeTeam: Team, awayTeam: Team): MatchResult {
  let state = initializeMatchState();
  
  // Simulate each minute
  for (let minute = 1; minute <= 90; minute++) {
    state = simulateMinute(state, homeTeam, awayTeam, minute);
  }

  return {
    homeScore: state.homeScore,
    awayScore: state.awayScore,
    events: state.events,
    stats: {
      home: state.homeStats,
      away: state.awayStats,
    }
  };
}

function simulateMinute(
  state: MatchState,
  homeTeam: Team,
  awayTeam: Team,
  minute: number
): MatchState {
  const newState = { ...state };
  const eventsThisMinute = [];

  // Simulate multiple events per minute
  for (let i = 0; i < SIMULATION_CONFIG.eventsPerMinute; i++) {
    const eventType = determineEventType();
    const attackingTeam = state.possession === 'home' ? homeTeam : awayTeam;
    const defendingTeam = state.possession === 'home' ? awayTeam : homeTeam;
    
    let event: MatchEvent;

    switch (eventType) {
      case 'buildup':
        event = simulateBuildUp(attackingTeam, minute);
        break;
      case 'transition':
        event = simulateTransition(attackingTeam, defendingTeam, minute);
        break;
      case 'general':
        event = simulateGeneralPlay(attackingTeam, defendingTeam, minute);
        break;
      default:
        event = simulateGeneralPlay(attackingTeam, defendingTeam, minute);
    }

    eventsThisMinute.push(event);

    // Update possession and other stats
    updateMatchStats(newState, event);

    // Check for possession change
    if (Math.random() < SIMULATION_CONFIG.possessionChangeProbability) {
      newState.possession = newState.possession === 'home' ? 'away' : 'home';
    }
  }

  newState.events = [...newState.events, ...eventsThisMinute];
  return newState;
}

function determineEventType(): 'buildup' | 'transition' | 'general' {
  const random = Math.random();
  
  if (random < SIMULATION_CONFIG.buildupProbability) {
    return 'buildup';
  } else if (random < SIMULATION_CONFIG.buildupProbability + SIMULATION_CONFIG.transitionProbability) {
    return 'transition';
  } else {
    return 'general';
  }
}

function simulateBuildUp(team: Team, minute: number): MatchEvent {
  const player = selectRandomPlayer(team);
  const phase = determinePhase();
  const description = generateBuildUpNarrative(player, team, phase);

  return {
    minute,
    type: 'buildup',
    team: team.id,
    player,
    description
  };
}

function simulateTransition(attackingTeam: Team, defendingTeam: Team, minute: number): MatchEvent {
  const player = selectRandomPlayer(attackingTeam);
  const type = Math.random() > 0.5 ? 'attack-to-defense' : 'defense-to-attack';
  const description = generateTransitionNarrative(player, attackingTeam, type);

  return {
    minute,
    type: 'transition',
    team: attackingTeam.id,
    player,
    description
  };
}

function simulateGeneralPlay(attackingTeam: Team, defendingTeam: Team, minute: number): MatchEvent {
  const player = selectRandomPlayer(attackingTeam);
  const phase = determinePhase();
  const description = generateGeneralPlayNarrative(player, attackingTeam, phase);

  return {
    minute,
    type: 'general',
    team: attackingTeam.id,
    player,
    description
  };
}

function determinePhase(): 'initial' | 'middle' | 'final' {
  const random = Math.random();
  if (random < 0.33) return 'initial';
  if (random < 0.66) return 'middle';
  return 'final';
}

function selectRandomPlayer(team: Team) {
  return team.players[Math.floor(Math.random() * team.players.length)];
}

function updateMatchStats(state: MatchState, event: MatchEvent) {
  const stats = event.team === 'home' ? state.homeStats : state.awayStats;
  
  switch (event.type) {
    case 'goal':
      stats.shots++;
      stats.shotsOnTarget++;
      if (event.team === 'home') {
        state.homeScore++;
      } else {
        state.awayScore++;
      }
      break;
    case 'chance':
      stats.shots++;
      if (Math.random() > 0.5) {
        stats.shotsOnTarget++;
      }
      break;
    case 'buildup':
    case 'transition':
      stats.passes += Math.floor(Math.random() * 3) + 1;
      stats.passAccuracy = Math.min(100, stats.passAccuracy + Math.random() * 2);
      break;
  }
}

function initializeMatchState(): MatchState {
  const initialStats = {
    shots: 0,
    shotsOnTarget: 0,
    possession: 0,
    passes: 0,
    passAccuracy: 0,
    fouls: 0,
    yellowCards: 0,
    redCards: 0,
    corners: 0,
    offsides: 0,
  };

  return {
    minute: 0,
    homeScore: 0,
    awayScore: 0,
    possession: Math.random() > 0.5 ? 'home' : 'away',
    homePossession: 0,
    awayPossession: 0,
    events: [],
    homeStats: { ...initialStats },
    awayStats: { ...initialStats },
    isHalfTime: false,
  };
}