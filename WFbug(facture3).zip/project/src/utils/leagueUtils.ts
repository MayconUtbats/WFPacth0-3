import { League, Team } from '../types/game';

export const LEAGUE_MAX_TEAMS = 15;

export function findAvailableLeague(leagues: League[]): League | null {
  // Ordena as ligas da divisão mais baixa para a mais alta
  const sortedLeagues = [...leagues].sort((a, b) => b.division - a.division);
  
  // Procura a primeira liga com vaga disponível
  return sortedLeagues.find(league => league.teams.length < LEAGUE_MAX_TEAMS) || null;
}

export function assignTeamToLeague(team: Team, league: League): Team {
  if (league.teams.length >= LEAGUE_MAX_TEAMS) {
    throw new Error('Liga já está cheia');
  }

  return {
    ...team,
    league: league.id,
    division: league.division,
  };
}

export function generateLeagueSchedule(teams: Team[]): Match[] {
  const matches: Match[] = [];
  const numTeams = teams.length;
  
  // Gera jogos de ida
  for (let round = 0; round < numTeams - 1; round++) {
    for (let i = 0; i < numTeams / 2; i++) {
      const homeTeam = teams[i];
      const awayTeam = teams[numTeams - 1 - i];
      
      matches.push({
        id: crypto.randomUUID(),
        homeTeam,
        awayTeam,
        competition: 'league',
        date: new Date(), // A data será ajustada depois
      });
    }
    
    // Rotaciona os times mantendo o primeiro fixo
    teams.splice(1, 0, teams.pop()!);
  }
  
  // Gera jogos de volta invertendo mando de campo
  const returnMatches = matches.map(match => ({
    id: crypto.randomUUID(),
    homeTeam: match.awayTeam,
    awayTeam: match.homeTeam,
    competition: 'league',
    date: new Date(), // A data será ajustada depois
  }));
  
  return [...matches, ...returnMatches];
}

export function checkLeaguePromotion(team: Team, leagues: League[]): boolean {
  const currentLeague = leagues.find(l => l.id === team.league);
  if (!currentLeague) return false;
  
  // Verifica se é a primeira divisão
  if (currentLeague.division === 1) return false;
  
  // Encontra a liga da divisão superior
  const upperLeague = leagues.find(l => 
    l.country === currentLeague.country && 
    l.division === currentLeague.division - 1
  );
  
  return !!upperLeague && upperLeague.teams.length < LEAGUE_MAX_TEAMS;
}

export function checkLeagueRelegation(team: Team, leagues: League[]): boolean {
  const currentLeague = leagues.find(l => l.id === team.league);
  if (!currentLeague) return false;
  
  // Verifica se é a última divisão
  const maxDivision = Math.max(...leagues
    .filter(l => l.country === currentLeague.country)
    .map(l => l.division)
  );
  
  if (currentLeague.division === maxDivision) return false;
  
  // Encontra a liga da divisão inferior
  const lowerLeague = leagues.find(l => 
    l.country === currentLeague.country && 
    l.division === currentLeague.division + 1
  );
  
  return !!lowerLeague && lowerLeague.teams.length < LEAGUE_MAX_TEAMS;
}