import { Team, Match } from '../../types/game';
import { addDays } from 'date-fns';

export function generateNationalCupSchedule(teams: Team[], startDate: Date): Match[] {
  const matches: Match[] = [];
  let roundTeams = [...teams];
  let currentRound = 1;
  let currentDate = startDate;

  while (roundTeams.length > 1) {
    const roundMatches: Match[] = [];
    const pairsCount = Math.floor(roundTeams.length / 2);

    for (let i = 0; i < pairsCount; i++) {
      const homeTeam = roundTeams[i * 2];
      const awayTeam = roundTeams[i * 2 + 1];

      roundMatches.push({
        id: crypto.randomUUID(),
        homeTeam,
        awayTeam,
        competition: 'national_cup',
        date: currentDate,
        round: currentRound,
        isNeutralVenue: currentRound === Math.ceil(Math.log2(teams.length)) // Final
      });
    }

    matches.push(...roundMatches);
    roundTeams = roundTeams.slice(0, Math.ceil(roundTeams.length / 2));
    currentRound++;
    currentDate = addDays(currentDate, 7); // Uma semana entre as rodadas
  }

  return matches;
}