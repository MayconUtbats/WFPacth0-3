import { Team, Match } from '../../types/game';
import { addDays } from 'date-fns';

export function generateContinentalSchedule(
  teams: Team[], 
  startDate: Date, 
  competitionType: 'champions' | 'libertadores'
): Match[] {
  const matches: Match[] = [];
  let roundTeams = [...teams];
  let currentRound = 1;
  let currentDate = startDate;

  while (roundTeams.length > 1) {
    const roundMatches: Match[] = [];
    const pairsCount = Math.floor(roundTeams.length / 2);

    for (let i = 0; i < pairsCount; i++) {
      const homeTeam = roundTeams[i * 2];
      const awayTeam = roundTeams[i * 2 + 1];

      // Jogo de ida
      roundMatches.push({
        id: crypto.randomUUID(),
        homeTeam,
        awayTeam,
        competition: 'continental_cup',
        date: currentDate,
        round: currentRound,
        leg: 'first'
      });

      // Jogo de volta
      roundMatches.push({
        id: crypto.randomUUID(),
        homeTeam: awayTeam,
        awayTeam: homeTeam,
        competition: 'continental_cup',
        date: addDays(currentDate, 7),
        round: currentRound,
        leg: 'second'
      });
    }

    // Final em jogo único
    if (roundTeams.length === 2) {
      roundMatches.length = 0;
      roundMatches.push({
        id: crypto.randomUUID(),
        homeTeam: roundTeams[0],
        awayTeam: roundTeams[1],
        competition: 'continental_cup',
        date: currentDate,
        round: currentRound,
        isNeutralVenue: true
      });
    }

    matches.push(...roundMatches);
    roundTeams = roundTeams.slice(0, Math.ceil(roundTeams.length / 2));
    currentRound++;
    currentDate = addDays(currentDate, 14); // Duas semanas entre as fases
  }

  return matches;
}