import { Team, Match } from '../../types/game';
import { addDays } from 'date-fns';

export function generateWorldCupSchedule(
  championsTeams: Team[],
  libertadoresTeams: Team[],
  startDate: Date
): Match[] {
  const matches: Match[] = [];
  const currentDate = startDate;

  // Semifinais (ida e volta)
  // Champions 1 vs Libertadores 2
  matches.push(
    {
      id: crypto.randomUUID(),
      homeTeam: championsTeams[0],
      awayTeam: libertadoresTeams[1],
      competition: 'world_cup',
      date: currentDate,
      round: 1,
      leg: 'first'
    },
    {
      id: crypto.randomUUID(),
      homeTeam: libertadoresTeams[1],
      awayTeam: championsTeams[0],
      competition: 'world_cup',
      date: addDays(currentDate, 7),
      round: 1,
      leg: 'second'
    }
  );

  // Libertadores 1 vs Champions 2
  matches.push(
    {
      id: crypto.randomUUID(),
      homeTeam: libertadoresTeams[0],
      awayTeam: championsTeams[1],
      competition: 'world_cup',
      date: currentDate,
      round: 1,
      leg: 'first'
    },
    {
      id: crypto.randomUUID(),
      homeTeam: championsTeams[1],
      awayTeam: libertadoresTeams[0],
      competition: 'world_cup',
      date: addDays(currentDate, 7),
      round: 1,
      leg: 'second'
    }
  );

  // Final (jogo único em campo neutro)
  matches.push({
    id: crypto.randomUUID(),
    homeTeam: championsTeams[0], // Placeholder, será atualizado após as semifinais
    awayTeam: libertadoresTeams[0], // Placeholder, será atualizado após as semifinais
    competition: 'world_cup',
    date: addDays(currentDate, 14),
    round: 2,
    isNeutralVenue: true
  });

  return matches;
}