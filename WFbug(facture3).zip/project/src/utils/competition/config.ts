import { CompetitionConfig } from '../../types/competition';

export const LEAGUE_CONFIG: CompetitionConfig = {
  maxTeams: 15,
  roundTrip: true,
  promotionSpots: 3,
  relegationSpots: 3,
  extraTime: false,
  penalties: false,
  pointsForWin: 3,
  pointsForDraw: 1,
  seasonDurationDays: 30,
  matchesPerDay: 1,
};

export const NATIONAL_CUP_CONFIG: CompetitionConfig = {
  maxTeams: 32,
  roundTrip: false,
  extraTime: true,
  penalties: true,
  pointsForWin: 0,
  pointsForDraw: 0,
  seasonDurationDays: 30,
  matchesPerDay: 1,
};

export const CONTINENTAL_CUP_CONFIG: CompetitionConfig = {
  maxTeams: 32,
  roundTrip: true,
  extraTime: true,
  penalties: true,
  pointsForWin: 0,
  pointsForDraw: 0,
  seasonDurationDays: 30,
  matchesPerDay: 1,
};

export const WORLD_CUP_CONFIG: CompetitionConfig = {
  maxTeams: 4,
  roundTrip: true,
  extraTime: true,
  penalties: true,
  pointsForWin: 0,
  pointsForDraw: 0,
  seasonDurationDays: 7,
  matchesPerDay: 1,
};