import { Team } from '../../types/game';
import { CompetitionMatch } from '../../types/competition';

interface MatchResult {
  homeScore: number;
  awayScore: number;
  extraTime?: {
    homeScore: number;
    awayScore: number;
  };
  penalties?: {
    homeScore: number;
    awayScore: number;
  };
}

export function simulateMatch(match: CompetitionMatch): MatchResult {
  const homeStrength = calculateTeamStrength(match.homeTeam);
  const awayStrength = calculateTeamStrength(match.awayTeam);
  
  // Base result
  const result = simulateRegularTime(homeStrength, awayStrength);
  
  // Check if extra time is needed
  if (match.extraTime && isDrawInKnockout(match, result)) {
    const extraTime = simulateExtraTime(homeStrength, awayStrength);
    result.extraTime = extraTime;
    
    // Check if penalties are needed
    if (match.penalties && isDrawAfterExtraTime(result)) {
      result.penalties = simulatePenalties();
    }
  }
  
  return result;
}

function calculateTeamStrength(team: Team): number {
  return team.players.reduce((sum, player) => sum + player.rating, 0) / team.players.length;
}

function simulateRegularTime(homeStrength: number, awayStrength: number): MatchResult {
  const homeAdvantage = 1.1;
  const homeScoreChance = (homeStrength * homeAdvantage) / 20;
  const awayScoreChance = awayStrength / 20;
  
  return {
    homeScore: Math.floor(Math.random() * homeScoreChance),
    awayScore: Math.floor(Math.random() * awayScoreChance),
  };
}

function simulateExtraTime(homeStrength: number, awayStrength: number) {
  const fatigueEffect = 0.8;
  const homeScoreChance = (homeStrength * fatigueEffect) / 30;
  const awayScoreChance = (awayStrength * fatigueEffect) / 30;
  
  return {
    homeScore: Math.floor(Math.random() * homeScoreChance),
    awayScore: Math.floor(Math.random() * awayScoreChance),
  };
}

function simulatePenalties() {
  const maxPenalties = 5;
  let homeScore = 0;
  let awayScore = 0;
  
  for (let i = 0; i < maxPenalties; i++) {
    if (Math.random() > 0.25) homeScore++;
    if (Math.random() > 0.25) awayScore++;
  }
  
  // Sudden death if tied
  while (homeScore === awayScore) {
    if (Math.random() > 0.25) homeScore++;
    if (homeScore > awayScore) break;
    if (Math.random() > 0.25) awayScore++;
  }
  
  return { homeScore, awayScore };
}

function isDrawInKnockout(match: CompetitionMatch, result: MatchResult): boolean {
  if (match.competition === 'league') return false;
  return result.homeScore === result.awayScore;
}

function isDrawAfterExtraTime(result: MatchResult): boolean {
  if (!result.extraTime) return false;
  const totalHomeScore = result.homeScore + result.extraTime.homeScore;
  const totalAwayScore = result.awayScore + result.extraTime.awayScore;
  return totalHomeScore === totalAwayScore;
}