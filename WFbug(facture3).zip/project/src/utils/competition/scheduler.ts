```typescript
import { addDays, addWeeks } from 'date-fns';
import { ContinentalSchedule } from '../../types/competition';
import { SEASON_CONFIG } from '../../constants/season';

export function generateContinentalSchedule(season: number): ContinentalSchedule {
  const startDate = new Date(season, SEASON_CONFIG.SEASON_START_MONTH - 1, 15);
  
  // Group stage runs for 3 months
  const groupEndDate = addWeeks(startDate, 12);
  
  // Knockout stages after winter break
  const knockoutStartDate = addWeeks(groupEndDate, 8);
  
  return {
    groupStage: {
      startDate,
      endDate: groupEndDate,
      matchdays: generateGroupMatchdays(startDate),
    },
    knockoutStage: {
      rounds: [
        {
          name: 'round_of_16',
          firstLeg: knockoutStartDate,
          secondLeg: addWeeks(knockoutStartDate, 2),
        },
        {
          name: 'quarter',
          firstLeg: addWeeks(knockoutStartDate, 4),
          secondLeg: addWeeks(knockoutStartDate, 6),
        },
        {
          name: 'semi',
          firstLeg: addWeeks(knockoutStartDate, 8),
          secondLeg: addWeeks(knockoutStartDate, 10),
        },
        {
          name: 'final',
          firstLeg: addWeeks(knockoutStartDate, 12),
          secondLeg: null, // Single match final
        },
      ],
    },
  };
}

function generateGroupMatchdays(startDate: Date): number[] {
  const matchdays = [];
  let currentDate = startDate;

  // 6 matchdays for group stage (home and away)
  for (let i = 0; i < 6; i++) {
    matchdays.push(currentDate.getTime());
    currentDate = addWeeks(currentDate, 2);
  }

  return matchdays;
}
```