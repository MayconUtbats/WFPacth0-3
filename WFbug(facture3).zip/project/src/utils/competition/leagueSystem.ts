import { Team, League, Match } from '../../types/game';
import { addDays } from 'date-fns';

export const LEAGUE_MAX_TEAMS = 15;
export const SEASON_DURATION_DAYS = 30;

export function generateLeagueSchedule(teams: Team[], startDate: Date): Match[] {
  const matches: Match[] = [];
  const numTeams = teams.length;
  let currentDate = startDate;
  
  // Gera jogos de ida
  for (let round = 0; round < numTeams - 1; round++) {
    for (let i = 0; i < numTeams / 2; i++) {
      const homeTeam = teams[i];
      const awayTeam = teams[numTeams - 1 - i];
      
      matches.push({
        id: crypto.randomUUID(),
        homeTeam,
        awayTeam,
        competition: 'league',
        date: currentDate,
        round: round + 1
      });
    }
    
    // Rotaciona os times mantendo o primeiro fixo
    teams.splice(1, 0, teams.pop()!);
    currentDate = addDays(currentDate, 1);
  }
  
  // Gera jogos de volta invertendo mando de campo
  const firstLegMatches = [...matches];
  for (const match of firstLegMatches) {
    matches.push({
      id: crypto.randomUUID(),
      homeTeam: match.awayTeam,
      awayTeam: match.homeTeam,
      competition: 'league',
      date: addDays(match.date, numTeams - 1),
      round: match.round + numTeams - 1
    });
  }
  
  return matches;
}