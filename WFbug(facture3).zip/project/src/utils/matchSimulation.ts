import { Team, Match } from '../types/game';

const calculateTeamStrength = (team: Team): number => {
  if (!team.players.length) return 50; // Default strength for teams without players
  return team.players.reduce((sum, player) => sum + player.rating, 0) / team.players.length;
};

export const simulateMatch = (homeTeam: Team, awayTeam: Team): { homeScore: number; awayScore: number } => {
  const homeStrength = calculateTeamStrength(homeTeam);
  const awayStrength = calculateTeamStrength(awayTeam);
  
  // Home advantage factor
  const homeAdvantage = 1.1;
  
  // Calculate base scoring chances
  const homeScoreChance = (homeStrength * homeAdvantage) / 20;
  const awayScoreChance = awayStrength / 20;
  
  // Simulate goals
  const homeScore = Math.floor(Math.random() * homeScoreChance);
  const awayScore = Math.floor(Math.random() * awayScoreChance);
  
  return { homeScore, awayScore };
};