import { Team } from '../types/game';
import { CompetitionMatch, CompetitionType } from '../types/competition';
import { addDays } from 'date-fns';

export const generateLeagueSchedule = (teams: Team[], startDate: Date): CompetitionMatch[] => {
  const matches: CompetitionMatch[] = [];
  const teamsCount = teams.length;
  
  // Generate home and away matches for each team
  for (let round = 0; round < 2; round++) {
    for (let i = 0; i < teamsCount; i++) {
      for (let j = i + 1; j < teamsCount; j++) {
        const homeTeam = round === 0 ? teams[i] : teams[j];
        const awayTeam = round === 0 ? teams[j] : teams[i];
        const matchDay = matches.length;
        
        matches.push({
          id: `match_${matches.length + 1}`,
          homeTeam,
          awayTeam,
          competition: 'league',
          date: addDays(startDate, matchDay),
          round: Math.floor(matchDay / (teamsCount / 2)) + 1,
        });
      }
    }
  }
  
  return matches;
};

export const generateKnockoutSchedule = (
  teams: Team[],
  startDate: Date,
  competitionType: CompetitionType,
  hasSecondLeg: boolean = false
): CompetitionMatch[] => {
  const matches: CompetitionMatch[] = [];
  let roundTeams = [...teams];
  let currentRound = 1;
  let matchDay = 0;

  while (roundTeams.length > 1) {
    const roundMatches: CompetitionMatch[] = [];
    const pairsCount = Math.floor(roundTeams.length / 2);

    for (let i = 0; i < pairsCount; i++) {
      const homeTeam = roundTeams[i * 2];
      const awayTeam = roundTeams[i * 2 + 1];

      if (hasSecondLeg) {
        // First leg
        roundMatches.push({
          id: `match_${matches.length + 1}`,
          homeTeam,
          awayTeam,
          competition: competitionType,
          date: addDays(startDate, matchDay),
          round: currentRound,
          leg: 'first',
        });

        // Second leg
        roundMatches.push({
          id: `match_${matches.length + 2}`,
          homeTeam: awayTeam,
          awayTeam: homeTeam,
          competition: competitionType,
          date: addDays(startDate, matchDay + 1),
          round: currentRound,
          leg: 'second',
        });

        matchDay += 2;
      } else {
        roundMatches.push({
          id: `match_${matches.length + 1}`,
          homeTeam,
          awayTeam,
          competition: competitionType,
          date: addDays(startDate, matchDay),
          round: currentRound,
          isNeutralVenue: currentRound === Math.ceil(Math.log2(teams.length)), // Final
        });

        matchDay += 1;
      }
    }

    matches.push(...roundMatches);
    roundTeams = roundTeams.slice(0, Math.ceil(roundTeams.length / 2));
    currentRound++;
  }

  return matches;
};