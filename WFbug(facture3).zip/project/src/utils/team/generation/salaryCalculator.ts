export function calculateInitialSalary(rating: number, isNewTeam: boolean = false): number {
  // Salários mais baixos para times novos
  const baseSalary = isNewTeam ? 500 : 1000; // Base salary in currency units
  const ratingMultiplier = Math.pow(1.1, rating - (isNewTeam ? 27 : 60));
  return Math.round(baseSalary * ratingMultiplier);
}

export function calculateSalaryRange(rating: number, isNewTeam: boolean = false): {
  min: number;
  max: number;
} {
  const baseSalary = calculateInitialSalary(rating, isNewTeam);
  return {
    min: Math.round(baseSalary * 0.8),
    max: Math.round(baseSalary * 1.2)
  };
}