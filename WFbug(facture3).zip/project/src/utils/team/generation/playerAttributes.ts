import { Position } from '../../../types/game';

interface AttributeRanges {
  min: number;
  max: number;
}

const NEW_TEAM_ATTRIBUTES: Record<Position, Record<string, AttributeRanges>> = {
  GK: {
    reflexes: { min: 27, max: 50 },
    positioning: { min: 27, max: 50 },
    handling: { min: 27, max: 50 },
    kicking: { min: 27, max: 50 },
  },
  DEF: {
    tackling: { min: 27, max: 50 },
    marking: { min: 27, max: 50 },
    heading: { min: 27, max: 50 },
    strength: { min: 27, max: 50 },
  },
  MID: {
    passing: { min: 27, max: 50 },
    technique: { min: 27, max: 50 },
    vision: { min: 27, max: 50 },
    stamina: { min: 27, max: 50 },
  },
  FWD: {
    finishing: { min: 27, max: 50 },
    dribbling: { min: 27, max: 50 },
    speed: { min: 27, max: 50 },
    shooting: { min: 27, max: 50 },
  }
};

export function generatePlayerAttributes(position: Position, baseRating: number, isNewTeam: boolean = false) {
  const attributes = isNewTeam ? NEW_TEAM_ATTRIBUTES[position] : POSITION_ATTRIBUTES[position];
  const result: Record<string, number> = {};

  // Gera atributos dentro do range definido
  Object.entries(attributes).forEach(([attr, ranges]) => {
    const min = ranges.min;
    const max = ranges.max;
    result[attr] = Math.floor(min + Math.random() * (max - min));
  });

  return result;
}