import { Player } from '../../../types/game';
import { generatePlayerName } from '../../nameGenerator';
import { calculateInitialSalary } from './salaryCalculator';

export function generateDefaultPlayers(teamId: string, isNewTeam: boolean = false): Player[] {
  const positions = {
    GK: 2,  // Goleiros
    DEF: 6, // Defensores
    MID: 6, // Meio-campistas
    FWD: 4  // Atacantes
  };

  const players: Player[] = [];

  Object.entries(positions).forEach(([position, count]) => {
    for (let i = 0; i < count; i++) {
      // Rating entre 27-50 para times novos
      const baseRating = isNewTeam 
        ? 27 + Math.floor(Math.random() * 23) // 27-50 para times novos
        : position === 'GK' 
          ? 65 + Math.floor(Math.random() * 10) 
          : 60 + Math.floor(Math.random() * 10);
      
      // Idade entre 19-33 anos
      const age = 19 + Math.floor(Math.random() * 14); // 19-33 anos
      
      // Baixo potencial de crescimento (máximo 5-10 pontos acima do rating atual)
      const potentialIncrease = Math.floor(Math.random() * 5) + 5; // 5-10 pontos
      const potential = baseRating + potentialIncrease;
      
      const player: Player = {
        id: `${teamId}_player_${players.length + 1}`,
        name: generatePlayerName(),
        position: position as 'GK' | 'DEF' | 'MID' | 'FWD',
        rating: baseRating,
        stamina: 70 + Math.floor(Math.random() * 20), // 70-90 stamina
        salary: calculateInitialSalary(baseRating),
        age: age,
        potential: potential
      };

      players.push(player);
    }
  });

  return players;
}