const prefixes = [
  'Atlético', 'Esporte', 'Sociedade', 'Clube', 'Associação',
  'União', 'Sport', 'Grêmio', 'Real', 'Nacional'
];

const cities = [
  'São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Porto Alegre',
  'Curitiba', 'Salvador', 'Recife', 'Fortaleza', 'Brasília',
  'Goiânia', 'Manaus', 'Belém', 'Vitória', 'Florianópolis'
];

const suffixes = [
  'FC', 'Futebol Clube', 'Esporte Clube', 'Atlético Clube',
  'Sport Club', 'Clube de Futebol'
];

export function generateTeamName(): string {
  const usePrefix = Math.random() > 0.5;
  const useSuffix = Math.random() > 0.5;
  
  let name = '';
  
  if (usePrefix) {
    name += prefixes[Math.floor(Math.random() * prefixes.length)] + ' ';
  }
  
  name += cities[Math.floor(Math.random() * cities.length)];
  
  if (useSuffix) {
    name += ' ' + suffixes[Math.floor(Math.random() * suffixes.length)];
  }
  
  return name;
}