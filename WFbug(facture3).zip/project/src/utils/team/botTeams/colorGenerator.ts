interface TeamColors {
  primary: string;
  secondary: string;
  accent: string;
}

const colorPalettes: TeamColors[] = [
  {
    primary: '#1a365d',   // Navy Blue
    secondary: '#ffffff', // White
    accent: '#e53e3e',   // Red
  },
  {
    primary: '#2f855a',   // Green
    secondary: '#ffffff', // White
    accent: '#d69e2e',   // Gold
  },
  {
    primary: '#c53030',   // Red
    secondary: '#000000', // Black
    accent: '#d69e2e',   // Gold
  },
  {
    primary: '#2b6cb0',   // Blue
    secondary: '#ffffff', // White
    accent: '#c53030',   // Red
  },
  {
    primary: '#000000',   // Black
    secondary: '#ffffff', // White
    accent: '#d69e2e',   // Gold
  },
];

export function generateTeamColors(): TeamColors {
  return colorPalettes[Math.floor(Math.random() * colorPalettes.length)];
}