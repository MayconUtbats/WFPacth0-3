import { Team, Player } from '../../../types/game';
import { generatePlayerName } from '../../nameGenerator';
import { generateTeamName } from './nameGenerator';
import { generateTeamColors } from './colorGenerator';
import { generateDefaultPlayers } from '../generation/defaultPlayers';

export function generateBotTeam(division: number): Team {
  const teamId = crypto.randomUUID();
  const teamName = generateTeamName();
  const colors = generateTeamColors();
  
  const team: Team = {
    id: teamId,
    name: teamName,
    shortName: teamName.substring(0, 3).toUpperCase(),
    country: 'BRA',
    league: `serie-${String.fromCharCode(96 + division)}`, // 'a', 'b', 'c'
    division,
    founded: 1900 + Math.floor(Math.random() * 123), // Random year between 1900-2023
    colors,
    logo: {
      shape: 'shield',
      icon: 'star',
    },
    players: generateDefaultPlayers(teamId),
    budget: 1000000 + Math.floor(Math.random() * 4000000), // 1M to 5M
  };

  return team;
}

export function generateBotTeamsForDivision(
  division: number,
  requiredTeams: number
): Team[] {
  const teams: Team[] = [];
  
  for (let i = 0; i < requiredTeams; i++) {
    teams.push(generateBotTeam(division));
  }
  
  return teams;
}