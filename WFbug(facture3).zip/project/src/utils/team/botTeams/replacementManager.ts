import { Team } from '../../../types/game';
import { League } from '../../../types/league';
import { generateBotTeam } from './generator';

export function replaceBotTeam(
  leagues: League[],
  playerTeam: Team,
  targetDivision: number
): { updatedLeagues: League[]; replacedTeam: Team | null } {
  const targetLeague = leagues.find(l => l.division === targetDivision);
  
  if (!targetLeague) {
    return { updatedLeagues: leagues, replacedTeam: null };
  }

  // Find a bot team to replace
  const botTeamIndex = targetLeague.teams.findIndex(team => 
    team.name.includes('Bot') || team.name.includes('Atlético') || team.name.includes('Sport')
  );

  if (botTeamIndex === -1) {
    return { updatedLeagues: leagues, replacedTeam: null };
  }

  // Store the replaced team
  const replacedTeam = targetLeague.teams[botTeamIndex];

  // Update the leagues array
  const updatedLeagues = leagues.map(league => {
    if (league.division === targetDivision) {
      const updatedTeams = [...league.teams];
      updatedTeams[botTeamIndex] = playerTeam;
      return { ...league, teams: updatedTeams };
    }
    return league;
  });

  return { updatedLeagues, replacedTeam };
}

export function fillLeagueWithBots(league: League, requiredTeams: number): League {
  const currentTeams = league.teams.length;
  const botsNeeded = requiredTeams - currentTeams;

  if (botsNeeded <= 0) {
    return league;
  }

  const botTeams = Array.from({ length: botsNeeded }, () => 
    generateBotTeam(league.division)
  );

  return {
    ...league,
    teams: [...league.teams, ...botTeams]
  };
}