import React from 'react';
import { useGameStore } from '../store/gameStore';
import { FinancesOverview } from '../components/finances/FinancesOverview';
import { IncomeBreakdown } from '../components/finances/IncomeBreakdown';
import { ExpensesBreakdown } from '../components/finances/ExpensesBreakdown';
import { FinancialSummary } from '../components/finances/FinancialSummary';
import { Card } from '../components/ui/card';
import { DollarSign, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';

export function FinancesPage() {
  const navigate = useNavigate();
  const { currentTeam } = useGameStore();

  if (!currentTeam) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate(-1)}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Finanças</h1>
                <p className="text-sm text-gray-500">
                  Gestão financeira do clube
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Financial Summary */}
          <FinancialSummary />

          {/* Income & Expenses */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <IncomeBreakdown />
            <ExpensesBreakdown />
          </div>

          {/* Financial History */}
          <Card>
            <Card.Header>
              <h2 className="text-xl font-bold flex items-center">
                <DollarSign className="w-6 h-6 text-green-600 mr-2" />
                Histórico Financeiro
              </h2>
            </Card.Header>
            <Card.Body>
              <div className="space-y-4">
                {/* Add financial history table or chart here */}
              </div>
            </Card.Body>
          </Card>
        </div>
      </div>
    </div>
  );
}