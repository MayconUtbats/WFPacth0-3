import React from 'react';
import { useParams } from 'react-router-dom';
import { useGameStore } from '../store/gameStore';
import { useScoutingStore } from '../store/scoutingStore';
import { PlayerCard } from '../components/player/PlayerCard';
import { ScoutingReport } from '../components/scouting/ScoutingReport';
import { Card } from '../components/ui/card';

export function PlayerPage() {
  const { id } = useParams();
  const { currentTeam } = useGameStore();
  const { department, getScoutReport } = useScoutingStore();
  
  // Find player from current team or free agents
  const player = currentTeam?.players.find(p => p.id === id);
  const scoutReport = getScoutReport(id);
  const scout = scoutReport ? department.scouts.find(s => s.id === scoutReport.scoutId) : undefined;

  if (!player) {
    return (
      <div className="p-6">
        <Card>
          <Card.Body>
            <p className="text-center text-gray-500">Jogador não encontrado</p>
          </Card.Body>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Player Card */}
        <PlayerCard 
          player={player}
          scoutReport={scoutReport}
          showAttributes={true}
        />

        {/* Scout Report */}
        {scoutReport && scout && (
          <ScoutingReport
            report={scoutReport}
            player={player}
            scout={scout}
          />
        )}
      </div>
    </div>
  );
}