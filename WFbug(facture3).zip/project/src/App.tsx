import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { AuthPage } from './components/auth/AuthPage';
import { ClubCreationWizard } from './components/club/creation/ClubCreationWizard';
import { AuthenticatedLayout } from './components/layouts/AuthenticatedLayout';
import { Dashboard } from './components/Dashboard';
import { Squad } from './components/Squad';
import { FreeAgentsPage } from './pages/FreeAgentsPage';
import { FinancesPage } from './routes/FinancesPage';
import { PlayerPage } from './routes/PlayerPage';
import { FansPage } from './pages/FansPage';
import { StadiumPage } from './pages/StadiumPage';
import { YouthAcademyPage } from './pages/YouthAcademyPage';
import { Toaster } from 'react-hot-toast';
import { useGameStore } from './store/gameStore';

function App() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const currentTeam = useGameStore((state) => state.currentTeam);

  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Routes>
          {/* Public routes */}
          <Route path="/auth" element={!isAuthenticated ? <AuthPage /> : <Navigate to="/" />} />

          {/* Protected routes */}
          {isAuthenticated && (
            <>
              {!currentTeam ? (
                <Route path="/" element={<ClubCreationWizard />} />
              ) : (
                <Route element={<AuthenticatedLayout />}>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/squad" element={<Squad />} />
                  <Route path="/free-agents" element={<FreeAgentsPage />} />
                  <Route path="/finances" element={<FinancesPage />} />
                  <Route path="/player/:id" element={<PlayerPage />} />
                  <Route path="/fans" element={<FansPage />} />
                  <Route path="/stadium" element={<StadiumPage />} />
                  <Route path="/youth-academy" element={<YouthAcademyPage />} />
                </Route>
              )}
            </>
          )}

          {/* Redirect to auth if not authenticated */}
          <Route path="*" element={<Navigate to={isAuthenticated ? "/" : "/auth"} />} />
        </Routes>
      </div>
      <Toaster position="top-right" />
    </Router>
  );
}

export default App;