import { Country } from '../types/game';
import { LEAGUE_MAX_TEAMS } from '../utils/leagueUtils';

export const countries: Country[] = [
  {
    code: 'BRA',
    name: 'Brasil',
    leagues: [
      { 
        id: 'serie-a', 
        name: 'Série A', 
        division: 1, 
        country: 'BRA',
        teams: [],
        maxTeams: LEAGUE_MAX_TEAMS,
        hasVacancy: true
      },
      { 
        id: 'serie-b', 
        name: 'Série B', 
        division: 2, 
        country: 'BRA',
        teams: [],
        maxTeams: LEAGUE_MAX_TEAMS,
        hasVacancy: true
      },
      { 
        id: 'serie-c', 
        name: 'Série C', 
        division: 3, 
        country: 'BRA',
        teams: [],
        maxTeams: LEAGUE_MAX_TEAMS,
        hasVacancy: true
      },
    ],
  },
  {
    code: 'ARG',
    name: 'Argentina',
    leagues: [
      {
        id: 'primera-division',
        name: 'Primera División',
        division: 1,
        country: 'ARG',
        teams: [],
        maxTeams: LEAGUE_MAX_TEAMS,
        hasVacancy: true
      },
      {
        id: 'primera-nacional',
        name: 'Primera Nacional',
        division: 2,
        country: 'ARG',
        teams: [],
        maxTeams: LEAGUE_MAX_TEAMS,
        hasVacancy: true
      },
      {
        id: 'primera-b',
        name: 'Primera B',
        division: 3,
        country: 'ARG',
        teams: [],
        maxTeams: LEAGUE_MAX_TEAMS,
        hasVacancy: true
      },
    ],
  },
];