import { Team, Player } from '../types/game';
import { generatePlayerName } from '../utils/nameGenerator';

// Função auxiliar para gerar jogadores
function generatePlayers(teamId: string, count: number): Player[] {
  return Array.from({ length: count }, (_, index) => {
    const positions = ['GK', 'DEF', 'MID', 'FWD'] as const;
    const position = positions[Math.floor(index / 6)] || 'MID';
    
    return {
      id: `${teamId}_player_${index + 1}`,
      name: generatePlayerName('BRA'),
      position,
      rating: 65 + Math.floor(Math.random() * 20),
      stamina: 80 + Math.floor(Math.random() * 20),
      salary: 5000 + Math.floor(Math.random() * 15000),
    };
  });
}

export const exampleTeams: Team[] = [
  {
    id: 'team_1',
    name: 'Cruzeiro FC',
    shortName: 'CRU',
    country: 'BRA',
    league: 'serie-a',
    division: 1,
    founded: 1921,
    colors: {
      primary: '#1a365d',
      secondary: '#ffffff',
      accent: '#e53e3e',
    },
    logo: {
      shape: 'shield',
      icon: 'star',
    },
    players: generatePlayers('team_1', 23),
    budget: 15000000,
  },
  {
    id: 'team_2',
    name: 'Palmeiras EC',
    shortName: 'PAL',
    country: 'BRA',
    league: 'serie-a',
    division: 1,
    founded: 1914,
    colors: {
      primary: '#006400',
      secondary: '#ffffff',
      accent: '#ffd700',
    },
    logo: {
      shape: 'shield',
      icon: 'crown',
    },
    players: generatePlayers('team_2', 23),
    budget: 20000000,
  },
  {
    id: 'team_3',
    name: 'Flamengo SC',
    shortName: 'FLA',
    country: 'BRA',
    league: 'serie-a',
    division: 1,
    founded: 1895,
    colors: {
      primary: '#8b0000',
      secondary: '#000000',
      accent: '#ffd700',
    },
    logo: {
      shape: 'shield',
      icon: 'flame',
    },
    players: generatePlayers('team_3', 23),
    budget: 25000000,
  }
];