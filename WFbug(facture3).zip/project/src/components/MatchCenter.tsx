import React from 'react';
import { useGameStore } from '../store/gameStore';
import { simulateMatch } from '../utils/matchSimulation';
import { Play, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export function MatchCenter() {
  const { currentTeam, matches, playMatch, currentDate } = useGameStore();

  const todayMatches = matches.filter(
    match => format(match.date, 'yyyy-MM-dd') === format(currentDate, 'yyyy-MM-dd') &&
    !match.result &&
    (match.homeTeam.id === currentTeam?.id || match.awayTeam.id === currentTeam?.id)
  );

  const handlePlayMatch = (matchId: string) => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return;

    const result = simulateMatch(match.homeTeam, match.awayTeam);
    playMatch(matchId, result.homeScore, result.awayScore);
  };

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Match Center</h2>
      
      {todayMatches.length > 0 ? (
        <div className="space-y-4">
          {todayMatches.map(match => (
            <div key={match.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                  <span className="text-sm text-gray-500">
                    {format(match.date, 'MMM d, yyyy')}
                  </span>
                </div>
                <span className="text-sm font-semibold text-blue-600">
                  {match.competition.replace('_', ' ').toUpperCase()}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-semibold">{match.homeTeam.name}</p>
                  <p className="font-semibold">{match.awayTeam.name}</p>
                </div>
                
                <button
                  onClick={() => handlePlayMatch(match.id)}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg flex items-center hover:bg-green-600 transition-colors"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Play Match
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500">No matches scheduled for today</p>
      )}
    </div>
  );
}