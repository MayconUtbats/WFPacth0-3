import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useGameStore } from '../../store/gameStore';
import { 
  Trophy, Users, Building2, DollarSign, 
  GraduationCap, Heart, LogOut, Shield 
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

export function GameMenu() {
  const { currentTeam } = useGameStore();
  const { logout } = useAuthStore();
  const location = useLocation();

  const menuItems = [
    { to: '/', icon: Trophy, label: 'Visão Geral' },
    { to: '/teams', icon: Shield, label: 'Times' },
    { to: '/squad', icon: Users, label: 'Elenco' },
    { to: '/stadium', icon: Building2, label: 'Estádio' },
    { to: '/youth-academy', icon: GraduationCap, label: 'Base' },
    { to: '/fans', icon: Heart, label: 'Torcida' },
    { to: '/finances', icon: DollarSign, label: 'Finanças' },
  ];

  const MenuItem = ({ to, icon: Icon, label }) => (
    <Link
      to={to}
      className={`flex items-center space-x-3 w-full p-3 rounded-lg transition-colors ${
        location.pathname === to 
          ? 'bg-blue-50 text-blue-600'
          : 'hover:bg-gray-50 text-gray-700'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-medium">{label}</span>
    </Link>
  );

  return (
    <div className="w-64 bg-white h-screen p-4 border-r border-gray-200">
      <div className="flex items-center space-x-3 p-4 mb-6">
        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
          <Trophy className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="font-bold text-gray-900">{currentTeam?.name}</h2>
          <p className="text-sm text-gray-500">{currentTeam?.division}ª Divisão</p>
        </div>
      </div>

      <nav className="space-y-2">
        {menuItems.map((item) => (
          <MenuItem key={item.to} {...item} />
        ))}
      </nav>

      <div className="absolute bottom-4 left-4 right-4">
        <button
          onClick={logout}
          className="flex items-center space-x-3 w-full p-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sair</span>
        </button>
      </div>
    </div>
  );
}