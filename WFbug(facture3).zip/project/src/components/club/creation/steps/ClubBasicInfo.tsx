import React from 'react';
import { Input } from '../../../ui/input';
import { Card } from '../../../ui/card';
import { Trophy } from 'lucide-react';

interface ClubBasicInfoProps {
  formData: {
    name: string;
    shortName: string;
    stadiumName: string;
    motto: string;
    foundingYear: number;
  };
  setFormData: (data: any) => void;
  onNext: () => void;
}

export function ClubBasicInfo({ formData, setFormData, onNext }: ClubBasicInfoProps) {
  const currentYear = new Date().getFullYear();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };

  const isValid = () => {
    return (
      formData.name.length >= 3 &&
      formData.shortName.length === 3 &&
      formData.stadiumName.length >= 3 &&
      formData.foundingYear >= 1850 &&
      formData.foundingYear <= currentYear
    );
  };

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-3">
          <Trophy className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold">Informações Básicas</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          <Input
            label="Nome do Clube"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Digite o nome do clube"
            error={formData.name.length > 0 && formData.name.length < 3 ? 'Nome deve ter pelo menos 3 caracteres' : ''}
          />

          <Input
            label="Nome Abreviado"
            name="shortName"
            value={formData.shortName}
            onChange={handleChange}
            maxLength={3}
            placeholder="ABC"
            error={formData.shortName.length > 0 && formData.shortName.length !== 3 ? 'Use exatamente 3 letras' : ''}
          />

          <Input
            label="Nome do Estádio"
            name="stadiumName"
            value={formData.stadiumName}
            onChange={handleChange}
            placeholder="Digite o nome do estádio"
            error={formData.stadiumName.length > 0 && formData.stadiumName.length < 3 ? 'Nome deve ter pelo menos 3 caracteres' : ''}
          />

          <Input
            label="Lema do Clube"
            name="motto"
            value={formData.motto}
            onChange={handleChange}
            placeholder="Digite o lema do clube"
          />

          <Input
            type="number"
            label="Ano de Fundação"
            name="foundingYear"
            value={formData.foundingYear}
            onChange={handleChange}
            min={1850}
            max={currentYear}
            placeholder="Digite o ano de fundação"
            error={
              formData.foundingYear &&
              (formData.foundingYear < 1850 || formData.foundingYear > currentYear)
                ? 'Ano inválido'
                : ''
            }
          />

          <div className="flex justify-end">
            <button
              onClick={onNext}
              disabled={!isValid()}
              className={`px-4 py-2 rounded-lg text-white font-medium ${
                isValid()
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Próximo
            </button>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}