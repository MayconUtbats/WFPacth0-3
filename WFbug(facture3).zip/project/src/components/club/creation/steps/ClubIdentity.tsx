import React from 'react';
import { Card } from '../../../ui/card';
import { ColorPicker } from '../components/ColorPicker';
import { LogoEditor } from '../components/LogoEditor';
import { StepNavigation } from '../components/StepNavigation';
import { Palette } from 'lucide-react';

interface ClubIdentityProps {
  formData: {
    colors: {
      primary: string;
      secondary: string;
      accent: string;
    };
    logo: {
      shape: string;
      icon: string;
      style: string;
    };
  };
  setFormData: (data: any) => void;
  onNext: () => void;
  onBack: () => void;
}

export function ClubIdentity({ formData, setFormData, onNext, onBack }: ClubIdentityProps) {
  const handleColorChange = (type: keyof typeof formData.colors, color: string) => {
    setFormData((prev: any) => ({
      ...prev,
      colors: { ...prev.colors, [type]: color },
    }));
  };

  const handleLogoChange = (type: keyof typeof formData.logo, value: string) => {
    setFormData((prev: any) => ({
      ...prev,
      logo: { ...prev.logo, [type]: value },
    }));
  };

  return (
    <div className="space-y-8">
      <Card>
        <Card.Header>
          <div className="flex items-center space-x-3">
            <Palette className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold">Identidade Visual</h2>
          </div>
        </Card.Header>
        <Card.Body>
          <div className="space-y-8">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Cores do Clube
              </h3>
              <ColorPicker colors={formData.colors} onChange={handleColorChange} />
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Escudo do Clube
              </h3>
              <LogoEditor
                logo={formData.logo}
                colors={formData.colors}
                onChange={handleLogoChange}
              />
            </div>
          </div>
        </Card.Body>
      </Card>

      <StepNavigation
        onNext={onNext}
        onBack={onBack}
        isValid={true}
      />
    </div>
  );
}