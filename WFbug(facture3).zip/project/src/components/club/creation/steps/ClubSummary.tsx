import React from 'react';
import { Card } from '../../../ui/card';
import { Trophy, Building2, MapPin, Palette, Users } from 'lucide-react';
import { countries } from '../../../../data/countries';
import { findAvailableLeague } from '../../../../utils/leagueUtils';
import { LogoPreview } from '../../logo/LogoPreview';

interface ClubSummaryProps {
  formData: {
    name: string;
    shortName: string;
    country: string;
    stadiumName: string;
    colors: {
      primary: string;
      secondary: string;
      accent: string;
    };
    logo: {
      shape: string;
      icon: string;
      style: string;
    };
  };
  onSubmit: () => void;
  onBack: () => void;
}

export function ClubSummary({ formData, onSubmit, onBack }: ClubSummaryProps) {
  const selectedCountry = countries.find(c => c.code === formData.country);
  const availableLeague = selectedCountry ? findAvailableLeague(selectedCountry.leagues) : null;

  const SummarySection = ({ icon: Icon, title, content }: { icon: any, title: string, content: React.ReactNode }) => (
    <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
      <Icon className="w-5 h-5 text-blue-600 mt-1" />
      <div>
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <div className="mt-1 text-lg font-medium text-gray-900">{content}</div>
      </div>
    </div>
  );

  const ColorPreview = ({ color, label }: { color: string, label: string }) => (
    <div className="flex items-center space-x-2">
      <div
        className="w-6 h-6 rounded-full border border-gray-200"
        style={{ backgroundColor: color }}
      />
      <span className="text-sm text-gray-600">{label}</span>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Resumo do Clube
        </h2>
        <p className="text-gray-500">
          Confira as informações do seu novo clube antes de criar
        </p>
      </div>

      <div className="flex justify-center">
        <div className="w-40 h-40 p-4 bg-white rounded-lg shadow-lg">
          <LogoPreview
            selectedShape={formData.logo.shape}
            selectedIcon={formData.logo.icon}
            selectedStyle={formData.logo.style}
            colors={formData.colors}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SummarySection
          icon={Trophy}
          title="Informações do Clube"
          content={
            <div className="space-y-2">
              <p>{formData.name}</p>
              <p className="text-sm text-gray-500">({formData.shortName})</p>
            </div>
          }
        />

        <SummarySection
          icon={Building2}
          title="Estádio"
          content={formData.stadiumName}
        />

        <SummarySection
          icon={MapPin}
          title="Localização"
          content={
            <div className="space-y-1">
              <p>{selectedCountry?.name}</p>
              <p className="text-sm text-blue-600">
                {availableLeague?.name} (Divisão {availableLeague?.division})
              </p>
            </div>
          }
        />

        <SummarySection
          icon={Palette}
          title="Cores"
          content={
            <div className="space-y-2">
              <ColorPreview color={formData.colors.primary} label="Principal" />
              <ColorPreview color={formData.colors.secondary} label="Secundária" />
              <ColorPreview color={formData.colors.accent} label="Destaque" />
            </div>
          }
        />
      </div>

      <div className="flex items-center justify-between pt-6 border-t">
        <button
          onClick={onBack}
          className="px-6 py-2 rounded-lg text-gray-700 font-medium border border-gray-300 hover:bg-gray-50 transition-colors"
        >
          Voltar
        </button>
        <button
          onClick={onSubmit}
          className="px-8 py-2 rounded-lg text-white font-medium bg-green-600 hover:bg-green-700 transition-colors flex items-center space-x-2"
        >
          <Users className="w-5 h-5" />
          <span>Criar Clube</span>
        </button>
      </div>
    </div>
  );
}