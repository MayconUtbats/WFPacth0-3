import React from 'react';
import { Card } from '../../../ui/card';
import { MapPin, Building2 } from 'lucide-react';
import { Select } from '../../../ui/select';
import { countries } from '../../../../data/countries';
import { findAvailableLeague } from '../../../../utils/leagueUtils';

interface ClubLocationProps {
  formData: {
    country: string;
    city: string;
    region: string;
  };
  setFormData: (data: any) => void;
  onNext: () => void;
  onBack: () => void;
}

export function ClubLocation({ formData, setFormData, onNext, onBack }: ClubLocationProps) {
  const handleChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };

  const availableLeague = formData.country ? 
    findAvailableLeague(countries.find(c => c.code === formData.country)?.leagues || []) 
    : null;

  const isValid = () => {
    return (
      formData.country && 
      formData.city?.length >= 3 && 
      formData.region?.length >= 2 &&
      availableLeague
    );
  };

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-3">
          <MapPin className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold">Localização</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          <Select
            label="País"
            name="country"
            value={formData.country}
            onChange={handleChange}
          >
            <option value="">Selecione um país</option>
            {countries.map((country) => (
              <option key={country.code} value={country.code}>
                {country.name}
              </option>
            ))}
          </Select>

          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              name="city"
              value={formData.city}
              onChange={handleChange}
              placeholder="Cidade"
              className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />

            <input
              type="text"
              name="region"
              value={formData.region}
              onChange={handleChange}
              placeholder="Estado/Região"
              className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          {formData.country && availableLeague && (
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                <h3 className="font-medium text-blue-800">
                  Liga Disponível
                </h3>
              </div>
              <p className="text-blue-600">
                {availableLeague.name} (Divisão {availableLeague.division})
              </p>
              <p className="text-sm text-blue-500 mt-1">
                Vagas disponíveis: {availableLeague.maxTeams - availableLeague.teams.length}
              </p>
            </div>
          )}

          <div className="flex justify-between pt-4">
            <button
              onClick={onBack}
              className="px-4 py-2 rounded-lg text-gray-700 font-medium border border-gray-300 hover:bg-gray-50"
            >
              Voltar
            </button>
            <button
              onClick={onNext}
              disabled={!isValid()}
              className={`px-4 py-2 rounded-lg text-white font-medium ${
                isValid()
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Próximo
            </button>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}