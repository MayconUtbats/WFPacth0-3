import React from 'react';

interface StepNavigationProps {
  onBack?: () => void;
  onNext?: () => void;
  onSubmit?: () => void;
  isLastStep?: boolean;
  isValid?: boolean;
}

export function StepNavigation({
  onBack,
  onNext,
  onSubmit,
  isLastStep = false,
  isValid = true,
}: StepNavigationProps) {
  return (
    <div className="flex justify-between pt-6 border-t">
      {onBack && (
        <button
          onClick={onBack}
          className="px-6 py-2 rounded-lg text-gray-700 font-medium border border-gray-300 hover:bg-gray-50 transition-colors"
        >
          Voltar
        </button>
      )}
      
      {(onNext || onSubmit) && (
        <button
          onClick={isLastStep ? onSubmit : onNext}
          disabled={!isValid}
          className={`px-6 py-2 rounded-lg font-medium transition-colors ${
            isLastStep
              ? 'bg-green-600 hover:bg-green-700 text-white'
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          } ${!isValid && 'opacity-50 cursor-not-allowed'}`}
        >
          {isLastStep ? 'Criar' : 'Próximo'}
        </button>
      )}
    </div>
  );
}