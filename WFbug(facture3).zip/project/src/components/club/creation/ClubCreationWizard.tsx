import React, { useState } from 'react';
import { Trophy } from 'lucide-react';
import { useGameStore } from '../../../store/gameStore';
import { useNavigate } from 'react-router-dom';
import { countries } from '../../../data/countries';
import { Team } from '../../../types/game';
import { ClubBasicInfo } from './steps/ClubBasicInfo';
import { ClubLocation } from './steps/ClubLocation';
import { ClubIdentity } from './steps/ClubIdentity';
import { ClubSummary } from './steps/ClubSummary';
import { StepIndicator } from './components/StepIndicator';
import { findAvailableLeague } from '../../../utils/leagueUtils';
import { toast } from 'react-hot-toast';

export function ClubCreationWizard() {
  const navigate = useNavigate();
  const setTeam = useGameStore((state) => state.setTeam);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    shortName: '',
    country: '',
    colors: {
      primary: '#1a365d',
      secondary: '#ffffff',
      accent: '#e53e3e',
    },
    stadiumName: '',
    logo: {
      shape: 'shield-classic',
      icon: 'star',
      style: 'solid',
    },
  });

  const handleNext = () => setStep(step + 1);
  const handleBack = () => setStep(step - 1);

  const handleSubmit = () => {
    const selectedCountry = countries.find(c => c.code === formData.country);
    if (!selectedCountry) {
      toast.error('País inválido selecionado');
      return;
    }

    const availableLeague = findAvailableLeague(selectedCountry.leagues);
    if (!availableLeague) {
      toast.error('Não há vagas disponíveis nas ligas');
      return;
    }

    const newTeam: Team = {
      id: crypto.randomUUID(),
      name: formData.name,
      shortName: formData.shortName,
      country: formData.country,
      league: availableLeague.id,
      division: availableLeague.division,
      founded: new Date().getFullYear(),
      colors: formData.colors,
      logo: formData.logo,
      players: [],
      budget: 5000000,
    };

    try {
      setTeam(newTeam);
      toast.success('Clube criado com sucesso!');
      navigate('/');
    } catch (error) {
      toast.error('Erro ao criar o clube');
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <ClubBasicInfo
            formData={formData}
            setFormData={setFormData}
            onNext={handleNext}
          />
        );
      case 2:
        return (
          <ClubLocation
            formData={formData}
            setFormData={setFormData}
            onNext={handleNext}
            onBack={handleBack}
          />
        );
      case 3:
        return (
          <ClubIdentity
            formData={formData}
            setFormData={setFormData}
            onNext={handleNext}
            onBack={handleBack}
          />
        );
      case 4:
        return (
          <ClubSummary
            formData={formData}
            onSubmit={handleSubmit}
            onBack={handleBack}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-700 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="px-6 py-8">
          <div className="flex items-center justify-center mb-8">
            <Trophy className="w-12 h-12 text-blue-600" />
          </div>
          <h2 className="text-center text-3xl font-bold text-gray-900 mb-8">
            Criar Novo Clube
          </h2>

          <StepIndicator currentStep={step} totalSteps={4} />
          {renderStep()}
        </div>
      </div>
    </div>
  );
}