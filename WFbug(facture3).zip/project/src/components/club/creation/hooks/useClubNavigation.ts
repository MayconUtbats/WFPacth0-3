import { useNavigate } from 'react-router-dom';
import { useGameStore } from '../../../../store/gameStore';
import { Team } from '../../../../types/game';

export function useClubNavigation() {
  const navigate = useNavigate();
  const setTeam = useGameStore((state) => state.setTeam);

  const handleTeamCreation = (team: Team) => {
    setTeam(team);
    navigate('/');
  };

  return {
    handleTeamCreation
  };
}