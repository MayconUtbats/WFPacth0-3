import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGameStore } from '../../../../store/gameStore';
import { Team } from '../../../../types/game';
import { findAvailableLeague } from '../../../../utils/leagueUtils';
import { countries } from '../../../../data/countries';

export interface ClubFormData {
  name: string;
  shortName: string;
  country: string;
  stadiumName: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  logo: {
    shape: string;
    icon: string;
    style: string;
  };
}

export function useClubCreation() {
  const setTeam = useGameStore((state) => state.setTeam);
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<ClubFormData>({
    name: '',
    shortName: '',
    country: '',
    stadiumName: '',
    colors: {
      primary: '#1a365d',
      secondary: '#ffffff',
      accent: '#e53e3e',
    },
    logo: {
      shape: 'shield-classic',
      icon: 'star',
      style: 'solid',
    },
  });

  const handleNext = () => setStep(step + 1);
  const handleBack = () => setStep(step - 1);

  const handleSubmit = () => {
    const selectedCountry = countries.find(c => c.code === formData.country);
    if (!selectedCountry) return;

    const availableLeague = findAvailableLeague(selectedCountry.leagues);
    if (!availableLeague) return;

    const newTeam: Team = {
      id: crypto.randomUUID(),
      name: formData.name,
      shortName: formData.shortName,
      country: formData.country,
      league: availableLeague.id,
      division: availableLeague.division,
      founded: new Date().getFullYear(),
      colors: formData.colors,
      logo: formData.logo,
      players: [],
      budget: 5000000,
    };

    setTeam(newTeam);
    navigate('/');
  };

  return {
    step,
    formData,
    setFormData,
    handleNext,
    handleBack,
    handleSubmit,
  };
}