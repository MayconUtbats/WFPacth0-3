import React from 'react';
import { countries } from '../../../data/countries';
import { findAvailableLeague } from '../../../utils/leagueUtils';
import { Select } from '../../ui/select';

interface ClubLocationProps {
  formData: {
    country: string;
  };
  setFormData: (data: any) => void;
  onNext: () => void;
  onBack: () => void;
}

export function ClubLocation({ formData, setFormData, onNext, onBack }: ClubLocationProps) {
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const country = e.target.value;
    setFormData((prev: any) => ({ ...prev, country }));
  };

  const availableLeague = formData.country ? 
    findAvailableLeague(countries.find(c => c.code === formData.country)?.leagues || []) 
    : null;

  return (
    <div className="space-y-6">
      <Select
        label="País"
        value={formData.country}
        onChange={handleCountryChange}
      >
        <option value="">Selecione um país</option>
        {countries.map((country) => (
          <option key={country.code} value={country.code}>
            {country.name}
          </option>
        ))}
      </Select>

      {formData.country && availableLeague && (
        <div className="p-4 bg-blue-50 rounded-lg">
          <h3 className="font-medium text-blue-800 mb-2">
            Liga Disponível
          </h3>
          <p className="text-blue-600">
            {availableLeague.name} (Divisão {availableLeague.division})
          </p>
        </div>
      )}

      <div className="flex justify-between">
        <button
          onClick={onBack}
          className="px-4 py-2 rounded-lg text-gray-700 font-medium border border-gray-300 hover:bg-gray-50"
        >
          Voltar
        </button>
        <button
          onClick={onNext}
          disabled={!formData.country || !availableLeague}
          className={`px-4 py-2 rounded-lg text-white font-medium ${
            formData.country && availableLeague
              ? 'bg-blue-600 hover:bg-blue-700'
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          Próximo
        </button>
      </div>
    </div>
  );
}