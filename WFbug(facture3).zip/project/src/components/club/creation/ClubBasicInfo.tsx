import React from 'react';
import { Input } from '../../ui/input';

interface ClubBasicInfoProps {
  formData: {
    name: string;
    shortName: string;
    stadiumName: string;
  };
  setFormData: (data: any) => void;
  onNext: () => void;
}

export function ClubBasicInfo({ formData, setFormData, onNext }: ClubBasicInfoProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };

  const isValid = () => {
    return (
      formData.name.length >= 3 &&
      formData.shortName.length === 3 &&
      formData.stadiumName.length >= 3
    );
  };

  return (
    <div className="space-y-6">
      <Input
        label="Nome do Clube"
        name="name"
        value={formData.name}
        onChange={handleChange}
        placeholder="Digite o nome do clube"
        error={formData.name.length > 0 && formData.name.length < 3 ? 'Nome deve ter pelo menos 3 caracteres' : ''}
      />

      <Input
        label="Nome Abreviado"
        name="shortName"
        value={formData.shortName}
        onChange={handleChange}
        maxLength={3}
        placeholder="ABC"
        error={formData.shortName.length > 0 && formData.shortName.length !== 3 ? 'Use exatamente 3 letras' : ''}
      />

      <Input
        label="Nome do Estádio"
        name="stadiumName"
        value={formData.stadiumName}
        onChange={handleChange}
        placeholder="Digite o nome do estádio"
        error={formData.stadiumName.length > 0 && formData.stadiumName.length < 3 ? 'Nome deve ter pelo menos 3 caracteres' : ''}
      />

      <div className="flex justify-end">
        <button
          onClick={onNext}
          disabled={!isValid()}
          className={`px-4 py-2 rounded-lg text-white font-medium ${
            isValid()
              ? 'bg-blue-600 hover:bg-blue-700'
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          Próximo
        </button>
      </div>
    </div>
  );
}