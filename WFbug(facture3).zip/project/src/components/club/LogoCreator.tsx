import React from 'react';
import { Shield, Star, Circle, Triangle, Square, Heart } from 'lucide-react';

interface LogoCreatorProps {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  selectedShape: string;
  selectedIcon: string;
  onShapeChange: (shape: string) => void;
  onIconChange: (icon: string) => void;
}

const shapes = [
  { id: 'shield', icon: Shield },
  { id: 'circle', icon: Circle },
  { id: 'square', icon: Square },
];

const icons = [
  { id: 'star', icon: Star },
  { id: 'heart', icon: Heart },
  { id: 'triangle', icon: Triangle },
];

export function LogoCreator({ 
  colors, 
  selectedShape, 
  selectedIcon, 
  onShapeChange, 
  onIconChange 
}: LogoCreatorProps) {
  const ShapeComponent = shapes.find(s => s.id === selectedShape)?.icon || Shield;
  const IconComponent = icons.find(i => i.id === selectedIcon)?.icon || Star;

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Logo Shape</label>
        <div className="flex space-x-4">
          {shapes.map(({ id, icon: ShapeIcon }) => (
            <button
              key={id}
              onClick={() => onShapeChange(id)}
              className={`p-3 rounded-lg ${
                selectedShape === id 
                  ? 'bg-blue-100 ring-2 ring-blue-500' 
                  : 'bg-gray-50 hover:bg-gray-100'
              }`}
            >
              <ShapeIcon 
                size={32}
                className={selectedShape === id ? 'text-blue-600' : 'text-gray-600'}
              />
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Logo Icon</label>
        <div className="flex space-x-4">
          {icons.map(({ id, icon: IconComp }) => (
            <button
              key={id}
              onClick={() => onIconChange(id)}
              className={`p-3 rounded-lg ${
                selectedIcon === id 
                  ? 'bg-blue-100 ring-2 ring-blue-500' 
                  : 'bg-gray-50 hover:bg-gray-100'
              }`}
            >
              <IconComp 
                size={24}
                className={selectedIcon === id ? 'text-blue-600' : 'text-gray-600'}
              />
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Preview</label>
        <div className="w-32 h-32 mx-auto relative">
          <ShapeComponent
            size={128}
            style={{ color: colors.primary }}
            className="absolute inset-0"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <IconComponent
              size={64}
              style={{ color: colors.accent }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}