import React from 'react';
import { useTranslation } from '../../../hooks/useTranslation';

interface LogoColorsProps {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
}

export function LogoColors({ colors }: LogoColorsProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-4">
      <h3 className="font-medium text-gray-900">{t('club.logo.colors')}</h3>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <div
            className="w-full aspect-square rounded-lg border-2 border-gray-200"
            style={{ backgroundColor: colors.primary }}
          />
          <p className="mt-2 text-sm text-center text-gray-600">
            {t('club.colors.primary')}
          </p>
        </div>
        <div>
          <div
            className="w-full aspect-square rounded-lg border-2 border-gray-200"
            style={{ backgroundColor: colors.secondary }}
          />
          <p className="mt-2 text-sm text-center text-gray-600">
            {t('club.colors.secondary')}
          </p>
        </div>
        <div>
          <div
            className="w-full aspect-square rounded-lg border-2 border-gray-200"
            style={{ backgroundColor: colors.accent }}
          />
          <p className="mt-2 text-sm text-center text-gray-600">
            {t('club.colors.accent')}
          </p>
        </div>
      </div>
    </div>
  );
}