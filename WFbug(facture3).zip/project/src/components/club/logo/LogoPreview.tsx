import React from 'react';
import { logoShapes } from './LogoShapes';
import { logoIcons } from './LogoIcons';
import { logoStyles } from './LogoStyles';
import { TeamColors } from '../../../types/game';
import { getLogoStyleClasses, getIconStyles } from './utils/styleUtils';

interface LogoPreviewProps {
  selectedShape: string;
  selectedIcon: string;
  selectedStyle?: string;
  colors: TeamColors;
  size?: string | number;
}

export function LogoPreview({ 
  selectedShape, 
  selectedIcon,
  selectedStyle = 'solid',
  colors,
  size = '100%' 
}: LogoPreviewProps) {
  const ShapeComponent = logoShapes.find(s => s.id === selectedShape)?.icon;
  const IconComponent = logoIcons.find(i => i.id === selectedIcon)?.icon;

  if (!ShapeComponent || !IconComponent) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-100 rounded-lg">
        <span className="text-gray-400">Selecione forma e ícone</span>
      </div>
    );
  }

  const styleClasses = getLogoStyleClasses(selectedStyle);
  const iconStyles = getIconStyles(selectedStyle, colors.accent);

  return (
    <div className="relative w-full h-full">
      <div className={`absolute inset-0 ${styleClasses}`}>
        <ShapeComponent
          size={size}
          style={{ color: colors.primary }}
          className={`absolute inset-0 transition-all duration-300 ${styleClasses}`}
        />
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <IconComponent
          size={typeof size === 'number' ? size * 0.5 : '50%'}
          style={iconStyles}
          className={`transition-all duration-300 ${styleClasses}`}
        />
      </div>
    </div>
  );
}