import React from 'react';
import { LogoShapes } from './LogoShapes';
import { LogoIcons } from './LogoIcons';
import { LogoPreview } from './LogoPreview';

interface LogoCreatorProps {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  selectedShape: string;
  selectedIcon: string;
  onShapeChange: (shape: string) => void;
  onIconChange: (icon: string) => void;
}

export function LogoCreator({ 
  colors, 
  selectedShape, 
  selectedIcon, 
  onShapeChange, 
  onIconChange 
}: LogoCreatorProps) {
  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-2 gap-8">
        <LogoShapes
          selectedShape={selectedShape}
          onShapeChange={onShapeChange}
        />
        <LogoIcons
          selectedIcon={selectedIcon}
          onIconChange={onIconChange}
        />
      </div>
      
      <LogoPreview
        selectedShape={selectedShape}
        selectedIcon={selectedIcon}
        colors={colors}
      />
    </div>
  );
}