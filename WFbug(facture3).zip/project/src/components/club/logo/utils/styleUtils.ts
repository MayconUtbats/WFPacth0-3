export function getLogoStyleClasses(style: string): string {
  switch (style) {
    case 'outline':
      return 'stroke-[3] fill-none';
    case 'gradient':
      return 'filter drop-shadow-xl';
    case 'modern':
      return 'drop-shadow-2xl';
    case 'retro':
      return 'opacity-90 border-4 border-double';
    case 'minimalist':
      return 'stroke-1';
    case 'metallic':
      return 'bg-gradient-to-br from-gray-300 via-gray-100 to-gray-400 drop-shadow-lg';
    case '3d':
      return 'shadow-[inset_0_2px_4px_rgba(0,0,0,0.2)] drop-shadow-xl';
    default:
      return '';
  }
}

export function getIconStyles(style: string, accentColor: string) {
  const baseStyles = { color: accentColor };
  
  switch (style) {
    case 'gradient':
      return {
        ...baseStyles,
        filter: 'drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))',
      };
    case '3d':
      return {
        ...baseStyles,
        filter: 'drop-shadow(2px 2px 2px rgba(0, 0, 0, 0.2))',
      };
    default:
      return baseStyles;
  }
}