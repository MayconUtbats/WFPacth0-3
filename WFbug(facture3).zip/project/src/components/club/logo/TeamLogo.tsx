import React from 'react';
import { logoShapes } from './LogoShapes';
import { logoIcons } from './LogoIcons';
import { TeamColors } from '../../../types/game';

interface TeamLogoProps {
  selectedShape: string;
  selectedIcon: string;
  colors: TeamColors;
  size?: string | number;
}

export function TeamLogo({ 
  selectedShape, 
  selectedIcon, 
  colors,
  size = '100%'
}: TeamLogoProps) {
  const ShapeComponent = logoShapes.find(s => s.id === selectedShape)?.icon;
  const IconComponent = logoIcons.find(i => i.id === selectedIcon)?.icon;

  if (!ShapeComponent || !IconComponent) return null;

  return (
    <div className="relative w-full h-full">
      <ShapeComponent
        size={size}
        style={{ color: colors.primary }}
        className="absolute inset-0"
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <IconComponent
          size={typeof size === 'number' ? size * 0.5 : '50%'}
          style={{ color: colors.accent }}
        />
      </div>
    </div>
  );
}