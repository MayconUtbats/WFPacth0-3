import React, { useState } from 'react';
import { useTranslation } from '../../../hooks/useTranslation';
import { Card } from '../../ui/card';
import { LogoShapes } from './LogoShapes';
import { LogoIcons } from './LogoIcons';
import { LogoColors } from './LogoColors';
import { LogoPreview } from './LogoPreview';
import { LogoStyles } from './LogoStyles';
import { TeamLogo } from '../../../types/game';

interface LogoEditorProps {
  value: TeamLogo;
  onChange: (logo: TeamLogo) => void;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
}

export function LogoEditor({ value, onChange, colors }: LogoEditorProps) {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'shape' | 'icon' | 'style'>('shape');

  const handleShapeChange = (shape: string) => {
    onChange({ ...value, shape });
  };

  const handleIconChange = (icon: string) => {
    onChange({ ...value, icon });
  };

  const handleStyleChange = (style: string) => {
    onChange({ ...value, style });
  };

  return (
    <Card>
      <Card.Header>
        <h3 className="text-lg font-bold">{t('club.logo.editor')}</h3>
        <div className="flex space-x-4 mt-4">
          <button
            onClick={() => setActiveTab('shape')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'shape'
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {t('club.logo.shape')}
          </button>
          <button
            onClick={() => setActiveTab('icon')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'icon'
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {t('club.logo.icon')}
          </button>
          <button
            onClick={() => setActiveTab('style')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'style'
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {t('club.logo.style')}
          </button>
        </div>
      </Card.Header>

      <Card.Body>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            {activeTab === 'shape' && (
              <LogoShapes
                selectedShape={value.shape}
                onShapeChange={handleShapeChange}
              />
            )}
            {activeTab === 'icon' && (
              <LogoIcons
                selectedIcon={value.icon}
                onIconChange={handleIconChange}
              />
            )}
            {activeTab === 'style' && (
              <LogoStyles
                selectedStyle={value.style}
                onStyleChange={handleStyleChange}
              />
            )}
          </div>

          <div className="space-y-8">
            <div className="aspect-square w-full max-w-[300px] mx-auto">
              <LogoPreview
                logo={value}
                colors={colors}
              />
            </div>
            <LogoColors colors={colors} />
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}