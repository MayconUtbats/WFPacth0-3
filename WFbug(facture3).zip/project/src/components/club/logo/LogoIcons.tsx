import React, { useState } from 'react';
import { 
  Star, Trophy, Crown, Heart, Flag, Flame, Zap, Award, Target,
  Compass, Anchor, Mountain, Sun, Moon, Shield, Sword,
  Gem, Flower2, Rocket, Sparkles, Shapes, Hexagon
} from 'lucide-react';

export const logoIcons = [
  // Ícones Esportivos
  { id: 'trophy', icon: Trophy, name: 'Troféu', category: 'esporte' },
  { id: 'shield', icon: Shield, name: 'Escudo', category: 'esporte' },
  { id: 'star', icon: Star, name: 'Estrela', category: 'esporte' },
  { id: 'award', icon: Award, name: 'Medalha', category: 'esporte' },
  
  // Ícones de Poder
  { id: 'crown', icon: Crown, name: 'Coroa', category: 'poder' },
  { id: 'sword', icon: Sword, name: 'Espada', category: 'poder' },
  { id: 'sparkles', icon: Sparkles, name: 'Brilho', category: 'poder' },
  
  // Natureza e Elementos
  { id: 'flame', icon: Flame, name: 'Chama', category: 'elementos' },
  { id: 'mountain', icon: Mountain, name: 'Montanha', category: 'elementos' },
  { id: 'sun', icon: Sun, name: 'Sol', category: 'elementos' },
  { id: 'moon', icon: Moon, name: 'Lua', category: 'elementos' },
  { id: 'zap', icon: Zap, name: 'Raio', category: 'elementos' },
  { id: 'flower', icon: Flower2, name: 'Flor', category: 'elementos' },
  
  // Ícones Modernos
  { id: 'rocket', icon: Rocket, name: 'Foguete', category: 'moderno' },
  { id: 'shapes', icon: Shapes, name: 'Formas', category: 'moderno' },
  { id: 'hexagon', icon: Hexagon, name: 'Hexágono', category: 'moderno' },
  { id: 'gem', icon: Gem, name: 'Gema', category: 'moderno' },
  
  // Ícones Simbólicos
  { id: 'heart', icon: Heart, name: 'Coração', category: 'simbolos' },
  { id: 'flag', icon: Flag, name: 'Bandeira', category: 'simbolos' },
  { id: 'anchor', icon: Anchor, name: 'Âncora', category: 'simbolos' },
  { id: 'compass', icon: Compass, name: 'Bússola', category: 'simbolos' },
  { id: 'target', icon: Target, name: 'Alvo', category: 'simbolos' },
] as const;

interface LogoIconsProps {
  selectedIcon: string;
  onIconChange: (icon: string) => void;
}

export function LogoIcons({ selectedIcon, onIconChange }: LogoIconsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');

  const categories = [
    { id: 'todos', name: 'Todos os Ícones' },
    { id: 'esporte', name: 'Esportivos' },
    { id: 'poder', name: 'Poder' },
    { id: 'elementos', name: 'Elementos' },
    { id: 'moderno', name: 'Modernos' },
    { id: 'simbolos', name: 'Símbolos' },
  ];

  const filteredIcons = selectedCategory === 'todos' 
    ? logoIcons 
    : logoIcons.filter(icon => icon.category === selectedCategory);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2">
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === category.id
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-4">
        {filteredIcons.map(({ id, icon: IconComponent, name }) => (
          <button
            key={id}
            onClick={() => onIconChange(id)}
            className={`p-4 rounded-lg flex flex-col items-center justify-center transition-all ${
              selectedIcon === id 
                ? 'bg-blue-100 ring-2 ring-blue-500 shadow-lg scale-105' 
                : 'bg-gray-50 hover:bg-gray-100 hover:scale-105 hover:shadow'
            }`}
          >
            <div className="relative w-10 h-10 flex items-center justify-center">
              <IconComponent 
                className={`w-full h-full transition-colors ${
                  selectedIcon === id ? 'text-blue-600' : 'text-gray-600'
                }`}
              />
            </div>
            <span className="mt-2 text-xs font-medium text-center">
              {name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}