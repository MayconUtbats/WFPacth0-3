import React, { useState } from 'react';

export const logoStyles = [
  { 
    id: 'solid', 
    name: 'Sólido',
    preview: 'bg-gradient-to-br from-blue-600 to-blue-700',
    description: 'Estilo clássico e sólido'
  },
  { 
    id: 'outline', 
    name: 'Contorno',
    preview: 'border-2 border-blue-600',
    description: 'Design minimalista com contornos'
  },
  { 
    id: 'gradient', 
    name: 'Gradiente',
    preview: 'bg-gradient-to-br from-blue-400 via-blue-600 to-blue-800',
    description: 'Transição suave entre cores'
  },
  { 
    id: 'modern', 
    name: 'Moderno',
    preview: 'bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg',
    description: 'Visual contemporâneo e dinâmico'
  },
  { 
    id: 'retro', 
    name: 'Retrô',
    preview: 'bg-blue-600 opacity-90 border-4 border-double border-blue-800',
    description: 'Estilo vintage e nostálgico'
  },
  { 
    id: 'minimalist', 
    name: 'Minimalista',
    preview: 'bg-blue-600 bg-opacity-90',
    description: 'Design limpo e simplificado'
  },
  {
    id: 'metallic',
    name: 'Metálico',
    preview: 'bg-gradient-to-br from-gray-300 via-gray-100 to-gray-400 shadow-inner',
    description: 'Acabamento metálico elegante'
  },
  {
    id: '3d',
    name: '3D',
    preview: 'bg-gradient-to-br from-blue-500 to-blue-700 shadow-[inset_0_2px_4px_rgba(0,0,0,0.2)] drop-shadow-lg',
    description: 'Efeito tridimensional moderno'
  }
] as const;

interface LogoStylesProps {
  selectedStyle: string;
  onStyleChange: (style: string) => void;
}

export function LogoStyles({ selectedStyle, onStyleChange }: LogoStylesProps) {
  const [hoveredStyle, setHoveredStyle] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <h3 className="font-medium text-gray-900 mb-4">Estilo do Escudo</h3>
      
      <div className="grid grid-cols-2 gap-6">
        {logoStyles.map(({ id, name, preview, description }) => (
          <button
            key={id}
            onClick={() => onStyleChange(id)}
            onMouseEnter={() => setHoveredStyle(id)}
            onMouseLeave={() => setHoveredStyle(null)}
            className={`relative group transition-all duration-300 ${
              selectedStyle === id ? 'scale-105' : 'hover:scale-105'
            }`}
          >
            <div
              className={`w-full aspect-square rounded-lg transition-all duration-300 ${preview} ${
                selectedStyle === id
                  ? 'ring-4 ring-blue-500 ring-opacity-50'
                  : 'ring-2 ring-gray-200 hover:ring-blue-200'
              }`}
            />
            <div className="mt-3 text-center">
              <span className={`block text-sm font-medium ${
                selectedStyle === id ? 'text-blue-600' : 'text-gray-700'
              }`}>
                {name}
              </span>
              {hoveredStyle === id && (
                <span className="block text-xs text-gray-500 mt-1 bg-gray-50 p-2 rounded-lg">
                  {description}
                </span>
              )}
            </div>
          </button>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-700">
          Escolha o estilo que melhor representa a identidade do seu clube. 
          Cada estilo oferece uma aparência única para o escudo.
        </p>
      </div>
    </div>
  );
}