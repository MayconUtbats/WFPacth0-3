import React from 'react';
import { Shield, Circle, Square, Hexagon, Pentagon, Star, Diamond } from 'lucide-react';

export const logoShapes = [
  { id: 'shield-classic', icon: Shield, name: 'Escudo Clássico' },
  { id: 'shield-modern', icon: Shield, name: 'Escudo Moderno' },
  { id: 'circle', icon: Circle, name: 'Círculo' },
  { id: 'hexagon', icon: Hexagon, name: 'Hexágono' },
  { id: 'diamond', icon: Diamond, name: 'Diamante' },
  { id: 'pentagon', icon: Pentagon, name: 'Pentágono' },
  { id: 'star', icon: Star, name: 'Estrela' },
  { id: 'square', icon: Square, name: 'Quadrado' },
] as const;

interface LogoShapesProps {
  selectedShape: string;
  onShapeChange: (shape: string) => void;
}

export function LogoShapes({ selectedShape, onShapeChange }: LogoShapesProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-4">
        Formato do Escudo
      </label>
      <div className="grid grid-cols-3 gap-4">
        {logoShapes.map(({ id, icon: ShapeIcon, name }) => (
          <button
            key={id}
            onClick={() => onShapeChange(id)}
            className={`p-6 rounded-lg flex flex-col items-center justify-center transition-all ${
              selectedShape === id 
                ? 'bg-blue-100 ring-2 ring-blue-500 shadow-lg' 
                : 'bg-gray-50 hover:bg-gray-100 hover:shadow'
            }`}
          >
            <div className="relative w-12 h-12 flex items-center justify-center">
              <ShapeIcon 
                className={`w-full h-full transition-colors ${
                  selectedShape === id ? 'text-blue-600' : 'text-gray-600'
                }`}
              />
            </div>
            <span className="mt-2 text-xs font-medium text-center">
              {name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}