import React from 'react';
import { TeamColors } from '../../../types/game';

interface ColorPickerProps {
  colors: TeamColors;
  onChange: (type: keyof TeamColors, color: string) => void;
}

export function ColorPicker({ colors, onChange }: ColorPickerProps) {
  const colorFields = [
    { key: 'primary', label: 'Cor Principal' },
    { key: 'secondary', label: 'Cor Secundária' },
    { key: 'accent', label: 'Cor de Destaque' }
  ] as const;

  return (
    <div className="space-y-4">
      {colorFields.map(({ key, label }) => (
        <div key={key}>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {label}
          </label>
          <div className="flex items-center space-x-3">
            <input
              type="color"
              value={colors[key]}
              onChange={(e) => onChange(key, e.target.value)}
              className="h-10 w-10 rounded-lg border border-gray-300 cursor-pointer"
            />
            <span className="text-sm text-gray-600">{colors[key]}</span>
          </div>
        </div>
      ))}
    </div>
  );
}