import React, { useState } from 'react';
import { Card } from '../../ui/card';
import { LogoShapes } from '../logo/LogoShapes';
import { LogoIcons } from '../logo/LogoIcons';
import { LogoStyles } from '../logo/LogoStyles';
import { LogoPreview } from '../logo/LogoPreview';
import { TeamColors } from '../../../types/game';

interface LogoEditorProps {
  logo: {
    shape: string;
    icon: string;
    style: string;
  };
  colors: TeamColors;
  onChange: (type: keyof typeof logo, value: string) => void;
}

export function LogoEditor({ logo, colors, onChange }: LogoEditorProps) {
  const [activeTab, setActiveTab] = useState<'shape' | 'icon' | 'style'>('shape');

  const tabs = [
    { id: 'shape', label: 'Formato' },
    { id: 'icon', label: 'Ícone' },
    { id: 'style', label: 'Estilo' }
  ] as const;

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex space-x-4">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Editor Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          {activeTab === 'shape' && (
            <LogoShapes
              selectedShape={logo.shape}
              onShapeChange={(shape) => onChange('shape', shape)}
            />
          )}
          {activeTab === 'icon' && (
            <LogoIcons
              selectedIcon={logo.icon}
              onIconChange={(icon) => onChange('icon', icon)}
            />
          )}
          {activeTab === 'style' && (
            <LogoStyles
              selectedStyle={logo.style}
              onStyleChange={(style) => onChange('style', style)}
            />
          )}
        </div>

        {/* Preview */}
        <div className="aspect-square w-full max-w-[300px] mx-auto">
          <LogoPreview
            selectedShape={logo.shape}
            selectedIcon={logo.icon}
            selectedStyle={logo.style}
            colors={colors}
          />
        </div>
      </div>

      {/* Help Text */}
      <div className="mt-4 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-700">
          Personalize o escudo do seu clube combinando formato, ícone e estilo. 
          As cores serão aplicadas automaticamente com base nas cores do clube selecionadas.
        </p>
      </div>
    </div>
  );
}