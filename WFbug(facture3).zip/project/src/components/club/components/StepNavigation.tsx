import React from 'react';
import { Button } from '../../ui/button';
import { ChevronLeft, ChevronRight, Save } from 'lucide-react';

interface StepNavigationProps {
  onBack?: () => void;
  onNext?: () => void;
  onSubmit?: () => void;
  isLastStep?: boolean;
  isValid?: boolean;
}

export function StepNavigation({
  onBack,
  onNext,
  onSubmit,
  isLastStep = false,
  isValid = true,
}: StepNavigationProps) {
  return (
    <div className="flex justify-between pt-6 border-t">
      {onBack && (
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-gray-600 hover:text-gray-900"
          icon={<ChevronLeft className="w-4 h-4 mr-2" />}
        >
          Voltar
        </Button>
      )}
      
      {(onNext || onSubmit) && (
        <Button
          variant={isLastStep ? "success" : "primary"}
          onClick={isLastStep ? onSubmit : onNext}
          disabled={!isValid}
          icon={isLastStep ? <Save className="w-4 h-4 mr-2" /> : <ChevronRight className="w-4 h-4 ml-2" />}
          className={`${isLastStep ? 'bg-green-600 hover:bg-green-700' : ''}`}
        >
          {isLastStep ? 'Criar Clube' : 'Próximo'}
        </Button>
      )}
    </div>
  );
}