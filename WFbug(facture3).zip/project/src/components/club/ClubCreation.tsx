import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trophy } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import { countries } from '../../data/countries';
import { Team } from '../../types/game';
import { ClubBasicInfo } from './creation/ClubBasicInfo';
import { ClubLocation } from './creation/ClubLocation';
import { ClubIdentity } from './creation/ClubIdentity';
import { ClubSummary } from './creation/ClubSummary';
import { findAvailableLeague } from '../../utils/leagueUtils';

export function ClubCreation() {
  const navigate = useNavigate();
  const setTeam = useGameStore((state) => state.setTeam);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    shortName: '',
    country: '',
    colors: {
      primary: '#1a365d',
      secondary: '#ffffff',
      accent: '#e53e3e',
    },
    stadiumName: '',
    logo: {
      shape: 'shield',
      icon: 'star',
    },
  });

  const handleNext = () => setStep(step + 1);
  const handleBack = () => setStep(step - 1);

  const handleSubmit = () => {
    const selectedCountry = countries.find(c => c.code === formData.country);
    if (!selectedCountry) return;

    const availableLeague = findAvailableLeague(selectedCountry.leagues);
    if (!availableLeague) return;

    const newTeam: Team = {
      id: crypto.randomUUID(),
      name: formData.name,
      shortName: formData.shortName,
      country: formData.country,
      league: availableLeague.id,
      division: availableLeague.division,
      founded: new Date().getFullYear(),
      colors: formData.colors,
      logo: formData.logo,
      players: [],
      budget: 5000000,
    };

    setTeam(newTeam);
    navigate('/'); // Redireciona para o Dashboard após criar o time
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-700 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="px-6 py-8">
          <div className="flex items-center justify-center mb-8">
            <Trophy className="w-12 h-12 text-blue-600" />
          </div>
          <h2 className="text-center text-3xl font-bold text-gray-900 mb-8">
            Criar Novo Clube
          </h2>

          {/* Step Indicator */}
          <div className="mb-8">
            <div className="flex justify-between items-center">
              {[1, 2, 3, 4].map((stepNumber) => (
                <div
                  key={stepNumber}
                  className={`flex items-center ${stepNumber < 4 ? 'flex-1' : ''}`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      step >= stepNumber
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {stepNumber}
                  </div>
                  {stepNumber < 4 && (
                    <div
                      className={`flex-1 h-1 mx-2 ${
                        step > stepNumber ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Steps */}
          {step === 1 && (
            <ClubBasicInfo
              formData={formData}
              setFormData={setFormData}
              onNext={handleNext}
            />
          )}
          {step === 2 && (
            <ClubLocation
              formData={formData}
              setFormData={setFormData}
              onNext={handleNext}
              onBack={handleBack}
            />
          )}
          {step === 3 && (
            <ClubIdentity
              formData={formData}
              setFormData={setFormData}
              onNext={handleNext}
              onBack={handleBack}
            />
          )}
          {step === 4 && (
            <ClubSummary
              formData={formData}
              onSubmit={handleSubmit}
              onBack={handleBack}
            />
          )}
        </div>
      </div>
    </div>
  );
}