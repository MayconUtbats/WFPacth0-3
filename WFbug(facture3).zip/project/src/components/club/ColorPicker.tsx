import React from 'react';
import { TeamColors } from '../../types/game';
import { useTranslation } from '../../hooks/useTranslation';

interface ColorPickerProps {
  colors: TeamColors;
  onChange: (type: keyof TeamColors, color: string) => void;
}

export function ColorPicker({ colors, onChange }: ColorPickerProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          {t('club.colors.primary')}
        </label>
        <div className="mt-1 flex items-center">
          <input
            type="color"
            value={colors.primary}
            onChange={(e) => onChange('primary', e.target.value)}
            className="h-8 w-8 rounded-md border border-gray-300 cursor-pointer"
          />
          <span className="ml-2 text-sm text-gray-500">{colors.primary}</span>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          {t('club.colors.secondary')}
        </label>
        <div className="mt-1 flex items-center">
          <input
            type="color"
            value={colors.secondary}
            onChange={(e) => onChange('secondary', e.target.value)}
            className="h-8 w-8 rounded-md border border-gray-300 cursor-pointer"
          />
          <span className="ml-2 text-sm text-gray-500">{colors.secondary}</span>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          {t('club.colors.accent')}
        </label>
        <div className="mt-1 flex items-center">
          <input
            type="color"
            value={colors.accent}
            onChange={(e) => onChange('accent', e.target.value)}
            className="h-8 w-8 rounded-md border border-gray-300 cursor-pointer"
          />
          <span className="ml-2 text-sm text-gray-500">{colors.accent}</span>
        </div>
      </div>
    </div>
  );
}