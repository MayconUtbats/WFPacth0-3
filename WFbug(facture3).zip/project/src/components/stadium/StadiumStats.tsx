import React from 'react';
import { useStadiumStore } from '../../store/stadiumStore';
import { Card } from '../ui/card';
import { Activity, TrendingUp, TrendingDown, Users } from 'lucide-react';
import { useTranslation } from '../../hooks/useTranslation';
import { formatCurrency, formatNumber } from '../../utils/formatters';

export function StadiumStats() {
  const { stadium } = useStadiumStore();
  const { t } = useTranslation();

  if (!stadium) return null;

  const stats = [
    {
      label: t('stadium.stats.averageAttendance'),
      value: formatNumber(stadium.averageAttendance || 0),
      trend: 'up',
      percentage: '+12%',
    },
    {
      label: t('stadium.stats.seasonRevenue'),
      value: formatCurrency(stadium.seasonRevenue || 0),
      trend: 'up',
      percentage: '+8%',
    },
    {
      label: t('stadium.stats.maintenanceCosts'),
      value: formatCurrency(stadium.maintenanceCosts || 0),
      trend: 'down',
      percentage: '-5%',
    },
  ];

  const recentMatches = [
    {
      date: '2024-03-01',
      attendance: 25000,
      revenue: 500000,
      type: 'league',
    },
    {
      date: '2024-02-25',
      attendance: 28000,
      revenue: 560000,
      type: 'cup',
    },
    {
      date: '2024-02-18',
      attendance: 22000,
      revenue: 440000,
      type: 'league',
    },
  ];

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-3">
          <Activity className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">
            {t('stadium.stats.title')}
          </h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          {/* Key Stats */}
          <div className="grid gap-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="p-4 bg-gray-50 rounded-lg flex items-center justify-between"
              >
                <div>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="text-lg font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`flex items-center ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4 mr-1" />
                  ) : (
                    <TrendingDown className="w-4 h-4 mr-1" />
                  )}
                  <span className="text-sm font-medium">{stat.percentage}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Recent Matches */}
          <div>
            <h3 className="font-medium text-gray-900 mb-4">
              {t('stadium.stats.recentMatches')}
            </h3>
            <div className="space-y-3">
              {recentMatches.map((match) => (
                <div
                  key={match.date}
                  className="p-3 bg-white border border-gray-200 rounded-lg flex items-center justify-between"
                >
                  <div className="flex items-center space-x-4">
                    <Users className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium">
                        {new Date(match.date).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {match.type.toUpperCase()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      {formatNumber(match.attendance)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatCurrency(match.revenue)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}