```typescript
import React from 'react';
import { Button } from '../../ui/button';
import { formatCurrency } from '../../../utils/formatters';
import { LucideIcon } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface FacilityCardProps {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  level: number;
  maxLevel: number;
  cost: number;
  onUpgrade: () => void;
}

export function FacilityCard({
  name,
  description,
  icon: Icon,
  level,
  maxLevel,
  cost,
  onUpgrade
}: FacilityCardProps) {
  const progress = (level / maxLevel) * 100;
  const isMaxLevel = level >= maxLevel;

  return (
    <div className="p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-white rounded-lg shadow-sm">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{name}</h3>
            <div className="flex items-center space-x-2">
              <p className="text-sm text-gray-500">
                Nível {level} / {maxLevel}
              </p>
              {isMaxLevel && (
                <span className="px-2 py-0.5 text-xs font-medium text-green-700 bg-green-100 rounded-full">
                  Nível Máximo
                </span>
              )}
            </div>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={onUpgrade}
          disabled={isMaxLevel}
          className={cn(
            "flex items-center space-x-1",
            isMaxLevel && "opacity-50 cursor-not-allowed"
          )}
        >
          <span>{formatCurrency(cost)}</span>
        </Button>
      </div>

      <p className="mt-4 text-sm text-gray-600">{description}</p>

      <div className="mt-4">
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={cn(
              "h-full rounded-full transition-all duration-500",
              isMaxLevel ? "bg-green-500" : "bg-blue-600"
            )}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
```