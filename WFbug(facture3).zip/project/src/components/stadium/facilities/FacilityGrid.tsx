```typescript
import React from 'react';
import { FacilityCard } from './FacilityCard';
import { StadiumFacilities } from '../../../types/stadium';
import { FACILITY_CONFIG } from './config';

interface FacilityGridProps {
  facilities: StadiumFacilities;
  maxLevel: number;
  onUpgrade: (facilityId: keyof StadiumFacilities) => void;
}

export function FacilityGrid({ facilities, maxLevel, onUpgrade }: FacilityGridProps) {
  const calculateUpgradeCost = (facilityId: keyof StadiumFacilities) => {
    const facility = FACILITY_CONFIG.find(f => f.id === facilityId);
    const currentLevel = facilities[facilityId];
    return facility ? facility.baseCost * (currentLevel + 1) : 0;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {FACILITY_CONFIG.map((facility) => (
        <FacilityCard
          key={facility.id}
          {...facility}
          level={facilities[facility.id]}
          maxLevel={maxLevel}
          cost={calculateUpgradeCost(facility.id as keyof StadiumFacilities)}
          onUpgrade={() => onUpgrade(facility.id as keyof StadiumFacilities)}
        />
      ))}
    </div>
  );
}
```