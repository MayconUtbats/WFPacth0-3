```typescript
import { Building2, Car, ShoppingBag, Utensils, Star, Tv, Wifi, Accessibility } from 'lucide-react';

export const FACILITY_CONFIG = [
  {
    id: 'parking',
    name: 'Estacionamento',
    icon: Car,
    baseCost: 100000,
    description: 'Aumente a capacidade de estacionamento para os torcedores',
  },
  {
    id: 'shops',
    name: 'Lojas',
    icon: ShoppingBag,
    baseCost: 150000,
    description: 'Lojas oficiais e pontos de venda de produtos do clube',
  },
  {
    id: 'food',
    name: 'Alimentação',
    icon: Utensils,
    baseCost: 120000,
    description: 'Lanchonetes e restaurantes para os torcedores',
  },
  {
    id: 'vip',
    name: 'Área VIP',
    icon: Star,
    baseCost: 200000,
    description: 'Camarotes e áreas exclusivas',
  },
  {
    id: 'screens',
    name: 'Telões',
    icon: Tv,
    baseCost: 180000,
    description: 'Telões para replay e informações',
  },
  {
    id: 'wifi',
    name: 'Wi-Fi',
    icon: Wifi,
    baseCost: 90000,
    description: 'Conectividade para os torcedores',
  },
  {
    id: 'accessibility',
    name: 'Acessibilidade',
    icon: Accessibility,
    baseCost: 130000,
    description: 'Melhorias para acessibilidade',
  },
] as const;
```