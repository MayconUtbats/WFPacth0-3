```tsx
import React from 'react';
import { useStadiumStore } from '../../store/stadiumStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Wrench, AlertTriangle } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

export function StadiumMaintenance() {
  const { stadium, performMaintenance } = useStadiumStore();

  if (!stadium) return null;

  const maintenanceTypes = [
    {
      id: 'routine',
      name: 'Manutenção de Rotina',
      description: 'Manutenção básica e limpeza',
      cost: 50000,
      improvement: 20,
    },
    {
      id: 'major',
      name: 'Manutenção Completa',
      description: 'Reforma geral das instalações',
      cost: 200000,
      improvement: 50,
    },
    {
      id: 'emergency',
      name: 'Manutenção Emergencial',
      description: 'Reparos urgentes necessários',
      cost: 100000,
      improvement: 30,
    },
  ];

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Wrench className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold">Manutenção</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          {/* Estado Atual */}
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-600">
                Estado Atual
              </span>
              <span className={`text-sm font-bold ${
                stadium.maintenanceLevel >= 80 ? 'text-green-600' :
                stadium.maintenanceLevel >= 50 ? 'text-yellow-600' :
                'text-red-600'
              }`}>
                {stadium.maintenanceLevel}%
              </span>
            </div>
            <div className="relative pt-1">
              <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                <div
                  style={{ width: `${stadium.maintenanceLevel}%` }}
                  className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center transition-all duration-500 ${
                    stadium.maintenanceLevel >= 80 ? 'bg-green-600' :
                    stadium.maintenanceLevel >= 50 ? 'bg-yellow-600' :
                    'bg-red-600'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Opções de Manutenção */}
          <div className="space-y-4">
            {maintenanceTypes.map((type) => (
              <div
                key={type.id}
                className="p-4 bg-white border border-gray-200 rounded-lg hover:border-blue-200 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900">{type.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      {type.description}
                    </p>
                    <p className="text-xs text-green-600 mt-2">
                      +{type.improvement}% de melhoria
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => performMaintenance(type.id)}
                    className="flex items-center space-x-2"
                  >
                    <span>{formatCurrency(type.cost)}</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Aviso de Manutenção Baixa */}
          {stadium.maintenanceLevel < 50 && (
            <div className="p-4 bg-red-50 rounded-lg flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">
                O estádio precisa de manutenção urgente!
              </p>
            </div>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}
```