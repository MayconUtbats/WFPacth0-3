import React from 'react';
import { useStadiumStore } from '../../store/stadiumStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { TrendingUp, Building2, DollarSign } from 'lucide-react';
import { useTranslation } from '../../hooks/useTranslation';
import { formatCurrency, formatNumber } from '../../utils/formatters';

export function StadiumUpgrades() {
  const { stadium, expandStadium } = useStadiumStore();
  const { t } = useTranslation();

  if (!stadium) return null;

  const upgrades = [
    {
      id: 'capacity',
      name: t('stadium.upgrades.capacity'),
      description: t('stadium.upgrades.capacityDesc'),
      icon: Building2,
      current: stadium.capacity,
      increment: 5000,
      cost: stadium.expansionCost,
      unit: t('stadium.seats'),
    },
    {
      id: 'comfort',
      name: t('stadium.upgrades.comfort'),
      description: t('stadium.upgrades.comfortDesc'),
      icon: TrendingUp,
      current: stadium.comfort || 1,
      increment: 1,
      cost: 250000,
      unit: t('stadium.level'),
      maxLevel: 5,
    },
  ];

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-900">
              {t('stadium.upgrades.title')}
            </h2>
            <p className="text-sm text-gray-500">
              {t('stadium.upgrades.description')}
            </p>
          </div>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          {upgrades.map((upgrade) => (
            <div
              key={upgrade.id}
              className="p-6 bg-gray-50 rounded-lg border border-gray-200"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-white rounded-lg shadow-sm">
                    <upgrade.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {upgrade.name}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">
                      {upgrade.description}
                    </p>
                    <div className="mt-2 flex items-center space-x-2">
                      <span className="text-sm font-medium text-gray-600">
                        {t('stadium.current')}:
                      </span>
                      <span className="text-sm font-bold">
                        {formatNumber(upgrade.current)} {upgrade.unit}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => expandStadium(upgrade.id)}
                    disabled={upgrade.maxLevel && upgrade.current >= upgrade.maxLevel}
                    className="flex items-center space-x-2"
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>{formatCurrency(upgrade.cost)}</span>
                  </Button>
                  <p className="text-xs text-gray-500 mt-2">
                    +{formatNumber(upgrade.increment)} {upgrade.unit}
                  </p>
                </div>
              </div>

              {upgrade.maxLevel && (
                <div className="mt-4">
                  <div className="relative pt-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-gray-600">
                        {t('stadium.progress')}
                      </span>
                      <span className="text-xs font-semibold text-gray-600">
                        {Math.round((upgrade.current / upgrade.maxLevel) * 100)}%
                      </span>
                    </div>
                    <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                      <div
                        style={{
                          width: `${(upgrade.current / upgrade.maxLevel) * 100}%`,
                        }}
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600 transition-all duration-500"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card.Body>
    </Card>
  );
}