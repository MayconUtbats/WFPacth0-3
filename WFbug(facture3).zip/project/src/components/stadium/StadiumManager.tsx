import React from 'react';
import { useStadiumStore } from '../../store/stadiumStore';
import { useGameStore } from '../../store/gameStore';
import { Users, DollarSign, Building2 } from 'lucide-react';
import { STADIUM_CONFIG } from '../../utils/stadiumUtils';

export function StadiumManager() {
  const stadium = useStadiumStore((state) => state.stadium);
  const { expandStadium, setTicketPrice } = useStadiumStore();
  const currentTeam = useGameStore((state) => state.currentTeam);

  if (!stadium || !currentTeam) return null;

  const handleExpand = () => {
    if (currentTeam.budget >= stadium.expansionCost) {
      const success = expandStadium();
      if (success) {
        // Update team budget after expansion
        // This would need to be implemented in the game store
      }
    }
  };

  const handleTicketPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPrice = Number(e.target.value);
    if (newPrice >= 0) {
      setTicketPrice(newPrice);
    }
  };

  const canExpand = stadium.capacity < STADIUM_CONFIG.maxCapacity && 
                    currentTeam.budget >= stadium.expansionCost;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-6">
        <Building2 className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-2xl font-bold">{stadium.name}</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Users className="w-5 h-5 text-gray-500 mr-2" />
              <span className="font-medium">Capacity</span>
            </div>
            <span className="text-lg font-bold">{stadium.capacity.toLocaleString()}</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Users className="w-5 h-5 text-gray-500 mr-2" />
              <span className="font-medium">Current Attendance</span>
            </div>
            <span className="text-lg font-bold">{stadium.currentAttendance.toLocaleString()}</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ticket Price
            </label>
            <div className="flex items-center">
              <DollarSign className="w-5 h-5 text-gray-500 mr-2" />
              <input
                type="number"
                min="0"
                value={stadium.ticketPrice}
                onChange={handleTicketPriceChange}
                className="block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <button
            onClick={handleExpand}
            disabled={!canExpand}
            className={`w-full py-2 px-4 rounded-lg text-white font-medium ${
              canExpand
                ? 'bg-blue-600 hover:bg-blue-700'
                : 'bg-gray-400 cursor-not-allowed'
            }`}
          >
            Expand Stadium (+{STADIUM_CONFIG.expansionStep.toLocaleString()} seats)
            <span className="block text-sm">
              Cost: ${stadium.expansionCost.toLocaleString()}
            </span>
          </button>
        </div>
      </div>

      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-medium mb-2">Stadium Finances</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-gray-600">Maintenance Cost:</span>
            <span className="block font-bold">
              ${stadium.maintenanceCost.toLocaleString()}/match
            </span>
          </div>
          <div>
            <span className="text-gray-600">Match Revenue:</span>
            <span className="block font-bold">
              ${(stadium.currentAttendance * stadium.ticketPrice).toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}