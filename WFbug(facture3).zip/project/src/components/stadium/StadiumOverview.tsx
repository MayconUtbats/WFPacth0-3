```tsx
import React from 'react';
import { useStadiumStore } from '../../store/stadiumStore';
import { Building2, Users, DollarSign, Star } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { formatCurrency, formatNumber } from '../../utils/formatters';

export function StadiumOverview() {
  const { stadium } = useStadiumStore();

  if (!stadium) return null;

  const stats = [
    {
      icon: Users,
      label: 'Capacidade',
      value: formatNumber(stadium.capacity),
      color: 'text-blue-600',
    },
    {
      icon: DollarSign,
      label: 'Preço do Ingresso',
      value: formatCurrency(stadium.ticketPrice),
      color: 'text-green-600',
    },
    {
      icon: Building2,
      label: 'Custo de Manutenção',
      value: formatCurrency(stadium.maintenanceCost),
      color: 'text-red-600',
    },
    {
      icon: Star,
      label: 'Avaliação',
      value: '4.5/5',
      color: 'text-yellow-600',
    },
  ];

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-900">{stadium.name}</h2>
            <p className="text-sm text-gray-500">Visão geral do estádio</p>
          </div>
          <Button variant="outline" className="flex items-center space-x-2">
            <Building2 className="w-4 h-4" />
            <span>Renomear</span>
          </Button>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => (
            <div key={stat.label} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
                <span className="text-sm text-gray-600">{stat.label}</span>
              </div>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          ))}
        </div>

        <div className="mt-6">
          <div className="relative pt-1">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-xs font-semibold inline-block text-blue-600">
                  Ocupação
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold inline-block text-blue-600">
                  {Math.round((stadium.currentAttendance / stadium.capacity) * 100)}%
                </span>
              </div>
            </div>
            <div className="overflow-hidden h-2 text-xs flex rounded bg-blue-100">
              <div
                style={{
                  width: `${(stadium.currentAttendance / stadium.capacity) * 100}%`,
                }}
                className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600 transition-all duration-500"
              />
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}
```