```typescript
import React from 'react';
import { useStadiumStore } from '../../store/stadiumStore';
import { Card } from '../ui/card';
import { Building2 } from 'lucide-react';
import { FacilityGrid } from './facilities/FacilityGrid';

export function StadiumFacilities() {
  const { stadium, upgradeFacility } = useStadiumStore();

  if (!stadium) return null;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <Building2 className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-bold text-gray-900">Instalações</h2>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              Melhore as instalações do seu estádio
            </p>
          </div>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Object.entries(stadium.facilities).map(([facilityId, facility]) => (
            <div
              key={facilityId}
              className="p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-white rounded-lg shadow-sm">
                    <Building2 className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{facilityId}</h3>
                    <p className="text-sm text-gray-500">
                      Nível {facility} / {stadium.level}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => upgradeFacility(facilityId)}
                  className="flex items-center space-x-1"
                >
                  <span>{formatCurrency(500000 * (facility + 1))}</span>
                </Button>
              </div>

              <div className="mt-4">
                <div className="h-2 bg-gray-200 rounded-full">
                  <div
                    className="h-2 bg-blue-600 rounded-full transition-all duration-500"
                    style={{ width: `${((facility.level / 5) * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card.Body>
    </Card>
  );
}
```