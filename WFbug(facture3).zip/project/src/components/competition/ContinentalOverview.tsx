```tsx
import React from 'react';
import { useCompetitionStore } from '../../store/competitionStore';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/card';
import { Trophy, Calendar, Star } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function ContinentalOverview() {
  const { currentTeam } = useGameStore();
  const { getTeamCompetitions } = useCompetitionStore();

  if (!currentTeam) return null;

  const competitions = getTeamCompetitions(currentTeam.id);
  if (competitions.length === 0) return null;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Trophy className="w-6 h-6 text-yellow-500" />
          <h2 className="text-xl font-bold">Competições Continentais</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          {competitions.map(competition => (
            <div key={competition.id} className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-semibold text-lg">{competition.name}</h3>
                  <p className="text-sm text-gray-500">
                    {competition.currentStage === 'group' 
                      ? 'Fase de Grupos'
                      : competition.currentStage.replace('_', ' ').toUpperCase()}
                  </p>
                </div>
                <Star className="w-5 h-5 text-yellow-500" />
              </div>

              {competition.currentStage === 'group' && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium mb-2">Próximas Partidas</h4>
                  {competition.groups.map(group => 
                    group.teams.includes(currentTeam.id) && (
                      <div key={group.id} className="space-y-2">
                        {group.matches
                          .filter(match => !match.result)
                          .slice(0, 2)
                          .map(match => (
                            <div 
                              key={match.id}
                              className="flex justify-between items-center"
                            >
                              <div className="flex items-center space-x-2">
                                <Calendar className="w-4 h-4 text-gray-400" />
                                <span className="text-sm">
                                  {format(match.date, "d 'de' MMMM", { locale: ptBR })}
                                </span>
                              </div>
                              <span className="text-sm font-medium">
                                {match.homeTeam} vs {match.awayTeam}
                              </span>
                            </div>
                          ))}
                      </div>
                    )
                  )}
                </div>
              )}

              {competition.currentStage !== 'group' && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium mb-2">Fase Atual</h4>
                  {competition.knockoutStages
                    .find(stage => !stage.completed)
                    ?.matches.map(match => (
                      <div 
                        key={match.id}
                        className="flex justify-between items-center"
                      >
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">
                            {format(match.date, "d 'de' MMMM", { locale: ptBR })}
                          </span>
                        </div>
                        <span className="text-sm font-medium">
                          {match.homeTeam} vs {match.awayTeam}
                        </span>
                      </div>
                    ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </Card.Body>
    </Card>
  );
}
```