import React from 'react';
import { Trophy, Calendar, Star } from 'lucide-react';
import { useCompetitionStore } from '../../store/competitionStore';
import { useGameStore } from '../../store/gameStore';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useTranslation } from '../../hooks/useTranslation';

export function CompetitionOverview() {
  const { t } = useTranslation();
  const { currentTeam } = useGameStore();
  const { activeCompetitions } = useCompetitionStore();

  const teamCompetitions = activeCompetitions.filter(comp =>
    comp.teams.some(team => team.id === currentTeam?.id)
  );

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <div className="flex items-center mb-6">
        <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
        <h2 className="text-2xl font-bold">{t('competition.overview.title')}</h2>
      </div>

      <div className="space-y-6">
        {teamCompetitions.map(competition => (
          <div key={competition.id} className="border-b pb-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold">{competition.name}</h3>
              <span className="text-sm text-gray-500">
                {t(`competition.types.${competition.type}`)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center">
                <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                <span>
                  {format(competition.startDate, "d 'de' MMMM", { locale: ptBR })} - 
                  {format(competition.endDate, "d 'de' MMMM", { locale: ptBR })}
                </span>
              </div>
              <div className="flex items-center">
                <Star className="w-4 h-4 text-gray-400 mr-2" />
                <span>
                  {t('competition.overview.round', {
                    current: competition.currentRound,
                    total: competition.totalRounds,
                  })}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}