import React from 'react';
import { Trophy, Table } from 'lucide-react';
import { useCompetitionStore } from '../../../store/competitionStore';
import { useGameStore } from '../../../store/gameStore';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useTranslation } from '../../../hooks/useTranslation';

export function LeagueOverview() {
  const { t } = useTranslation();
  const { currentTeam } = useGameStore();
  const { activeCompetitions } = useCompetitionStore();

  const leagueCompetition = activeCompetitions.find(
    comp => comp.type === 'league' && comp.teams.some(team => team.id === currentTeam?.id)
  );

  if (!leagueCompetition) return null;

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <div className="flex items-center mb-6">
        <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
        <h2 className="text-2xl font-bold">Liga Nacional</h2>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-600">Temporada</p>
            <p className="font-semibold">
              {format(leagueCompetition.startDate, "MMMM 'de' yyyy", { locale: ptBR })}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Divisão</p>
            <p className="font-semibold">{currentTeam?.division}ª Divisão</p>
          </div>
        </div>

        <div className="border-t pt-4">
          <div className="flex items-center mb-2">
            <Table className="w-5 h-5 text-blue-500 mr-2" />
            <h3 className="font-semibold">Próximas Rodadas</h3>
          </div>
          <div className="space-y-2">
            {leagueCompetition.matches
              .filter(match => !match.result)
              .slice(0, 3)
              .map(match => (
                <div key={match.id} className="flex justify-between items-center text-sm">
                  <span>{match.homeTeam.name}</span>
                  <span className="text-gray-500">vs</span>
                  <span>{match.awayTeam.name}</span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}