import React from 'react';
import { Trophy } from 'lucide-react';
import { useCompetitionStore } from '../../../store/competitionStore';
import { useGameStore } from '../../../store/gameStore';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useTranslation } from '../../../hooks/useTranslation';

export function NationalCupOverview() {
  const { t } = useTranslation();
  const { currentTeam } = useGameStore();
  const { activeCompetitions } = useCompetitionStore();

  const cupCompetition = activeCompetitions.find(
    comp => comp.type === 'national_cup' && comp.teams.some(team => team.id === currentTeam?.id)
  );

  if (!cupCompetition) return null;

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <div className="flex items-center mb-6">
        <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
        <h2 className="text-2xl font-bold">Copa Nacional</h2>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-600">Fase Atual</p>
            <p className="font-semibold">
              {`${cupCompetition.currentRound}ª Fase`}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Status</p>
            <p className="font-semibold capitalize">
              {cupCompetition.status === 'pending' ? 'Aguardando' : 'Em Andamento'}
            </p>
          </div>
        </div>

        <div className="border-t pt-4">
          <h3 className="font-semibold mb-2">Próximo Jogo</h3>
          {cupCompetition.matches
            .filter(match => !match.result && 
              (match.homeTeam.id === currentTeam?.id || match.awayTeam.id === currentTeam?.id))
            .slice(0, 1)
            .map(match => (
              <div key={match.id} className="text-center p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">
                  {format(match.date, "d 'de' MMMM", { locale: ptBR })}
                </p>
                <div className="flex justify-center items-center space-x-3">
                  <span className="font-semibold">{match.homeTeam.name}</span>
                  <span className="text-gray-500">vs</span>
                  <span className="font-semibold">{match.awayTeam.name}</span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}