import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Trophy, Calendar } from 'lucide-react';
import { useCompetitionStore } from '../../store/competitionStore';
import { useGameStore } from '../../store/gameStore';
import { CompetitionMatch } from '../../types/competition';
import { useTranslation } from '../../hooks/useTranslation';

export function CompetitionSchedule() {
  const { t } = useTranslation();
  const { currentTeam, currentDate } = useGameStore();
  const { activeCompetitions } = useCompetitionStore();

  const todayMatches = activeCompetitions.flatMap(comp =>
    comp.matches.filter(match => {
      const isToday = format(match.date, 'yyyy-MM-dd') === format(currentDate, 'yyyy-MM-dd');
      const isTeamPlaying = match.homeTeam.id === currentTeam?.id || match.awayTeam.id === currentTeam?.id;
      return isToday && isTeamPlaying && !match.result;
    })
  );

  const renderMatchType = (match: CompetitionMatch) => {
    switch (match.competition) {
      case 'league':
        return t('competition.types.league');
      case 'national_cup':
        return t('competition.types.nationalCup');
      case 'continental_cup':
        return t('competition.types.continentalCup');
      case 'world_cup':
        return t('competition.types.worldCup');
      default:
        return t('competition.types.friendly');
    }
  };

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <div className="flex items-center mb-6">
        <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
        <h2 className="text-2xl font-bold">{t('competition.schedule.title')}</h2>
      </div>

      {todayMatches.length > 0 ? (
        <div className="space-y-4">
          {todayMatches.map(match => (
            <div key={match.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                  <span className="text-sm text-gray-500">
                    {format(match.date, "d 'de' MMMM", { locale: ptBR })}
                  </span>
                </div>
                <span className="text-sm font-semibold text-blue-600">
                  {renderMatchType(match)}
                  {match.leg && ` - ${match.leg === 'first' ? 'Ida' : 'Volta'}`}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6">
                      {/* Logo component here */}
                    </div>
                    <p className="font-semibold">{match.homeTeam.name}</p>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <div className="w-6 h-6">
                      {/* Logo component here */}
                    </div>
                    <p className="font-semibold">{match.awayTeam.name}</p>
                  </div>
                </div>

                <button
                  onClick={() => {/* Handle play match */}}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg flex items-center hover:bg-green-600 transition-colors"
                >
                  {t('competition.schedule.playMatch')}
                </button>
              </div>

              {match.isNeutralVenue && (
                <div className="mt-2 text-sm text-gray-500">
                  {t('competition.schedule.neutralVenue')}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500">{t('competition.schedule.noMatches')}</p>
      )}
    </div>
  );
}