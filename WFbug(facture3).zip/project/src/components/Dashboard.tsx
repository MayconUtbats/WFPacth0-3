import React from 'react';
import { useGameStore } from '../store/gameStore';
import { CompetitionOverview } from './competition/CompetitionOverview';
import { YouthAcademy } from './academy/YouthAcademy';
import { AcademyFacilities } from './academy/AcademyFacilities';
import { FinancesOverview } from './finances/FinancesOverview';
import { TransferMarket } from './transfers/TransferMarket';
import { FreeAgentsMarket } from './transfers/FreeAgentsMarket';
import { Trophy, Users, Building2, DollarSign, Briefcase } from 'lucide-react';
import { Card } from './ui/card';

export function Dashboard() {
  const { currentTeam } = useGameStore();

  if (!currentTeam) return null;

  return (
    <div className="p-4 md:p-6 bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6 md:space-y-8">
        {/* Cards de Visão Geral */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <Card className="bg-white">
            <Card.Body className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 md:p-3 bg-blue-100 rounded-lg shrink-0">
                  <Trophy className="w-5 h-5 md:w-6 md:h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs md:text-sm text-gray-500">Posição</p>
                  <p className="text-lg md:text-xl font-bold">3º Lugar</p>
                </div>
              </div>
            </Card.Body>
          </Card>

          <Card className="bg-white">
            <Card.Body className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 md:p-3 bg-green-100 rounded-lg shrink-0">
                  <DollarSign className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-xs md:text-sm text-gray-500">Orçamento</p>
                  <p className="text-lg md:text-xl font-bold truncate">
                    {currentTeam.budget.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </p>
                </div>
              </div>
            </Card.Body>
          </Card>

          <Card className="bg-white">
            <Card.Body className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 md:p-3 bg-yellow-100 rounded-lg shrink-0">
                  <Users className="w-5 h-5 md:w-6 md:h-6 text-yellow-600" />
                </div>
                <div>
                  <p className="text-xs md:text-sm text-gray-500">Elenco</p>
                  <p className="text-lg md:text-xl font-bold">{currentTeam.players.length} Jogadores</p>
                </div>
              </div>
            </Card.Body>
          </Card>

          <Card className="bg-white">
            <Card.Body className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 md:p-3 bg-purple-100 rounded-lg shrink-0">
                  <Building2 className="w-5 h-5 md:w-6 md:h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-xs md:text-sm text-gray-500">Instalações</p>
                  <p className="text-lg md:text-xl font-bold">Nível {currentTeam.facilities?.level || 1}</p>
                </div>
              </div>
            </Card.Body>
          </Card>
        </div>

        {/* Visão Geral da Competição */}
        <section>
          <CompetitionOverview />
        </section>

        {/* Mercado de Transferências e Jogadores Livres */}
        <section className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h2 className="text-xl md:text-2xl font-bold flex items-center px-1">
              <Briefcase className="w-6 h-6 mr-2 text-blue-600" />
              Mercado de Transferências
            </h2>
            <TransferMarket />
          </div>
          <div className="space-y-4">
            <h2 className="text-xl md:text-2xl font-bold flex items-center px-1">
              <Users className="w-6 h-6 mr-2 text-green-600" />
              Jogadores Livres
            </h2>
            <FreeAgentsMarket />
          </div>
        </section>

        {/* Seção da Base */}
        <section className="space-y-4">
          <h2 className="text-xl md:text-2xl font-bold px-1">Base</h2>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <YouthAcademy />
            <AcademyFacilities />
          </div>
        </section>

        {/* Seção Financeira */}
        <section>
          <FinancesOverview />
        </section>
      </div>
    </div>
  );
}