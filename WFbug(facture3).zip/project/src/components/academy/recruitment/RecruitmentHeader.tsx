import React from 'react';
import { Search } from 'lucide-react';

export function RecruitmentHeader({ title, description }: { title: string; description: string }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-2">
        <Search className="w-6 h-6 text-blue-600" />
        <h2 className="text-xl font-bold">{title}</h2>
      </div>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
  );
}