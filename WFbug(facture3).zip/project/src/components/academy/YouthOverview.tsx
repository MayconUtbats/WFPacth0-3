import React from 'react';
import { useAcademyStore } from '../../store/academyStore';
import { Card } from '../ui/card';
import { Trophy, Users, Star, Activity, Clock, GraduationCap } from 'lucide-react';
import { formatCurrency, formatNumber } from '../../utils/formatters';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function YouthOverview() {
  const academy = useAcademyStore((state) => state.academy);

  if (!academy) return null;

  const stats = [
    {
      icon: Users,
      label: 'Total de Jogadores',
      value: `${academy.currentPlayers.length}/${academy.maxPlayers}`,
      color: 'text-blue-600',
    },
    {
      icon: Star,
      label: 'Nível da Academia',
      value: `${academy.level}/${academy.maxLevel}`,
      color: 'text-yellow-600',
    },
    {
      icon: Activity,
      label: 'Custo Mensal',
      value: formatCurrency(academy.monthlyFee),
      color: 'text-green-600',
    },
    {
      icon: GraduationCap,
      label: 'Próxima Formatura',
      value: format(academy.nextGraduationDate, 'dd/MM/yyyy', { locale: ptBR }),
      color: 'text-purple-600',
    },
  ];

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Trophy className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold">Academia de Base</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <stat.icon className={`w-5 h-5 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="text-lg font-bold">{stat.value}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {academy.currentPlayers.length > 0 && (
          <div className="mt-6">
            <h3 className="font-medium text-gray-900 mb-4">Jogadores Promissores</h3>
            <div className="space-y-2">
              {academy.currentPlayers
                .sort((a, b) => b.potential - a.potential)
                .slice(0, 3)
                .map((player) => (
                  <div
                    key={player.id}
                    className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="font-medium">{player.name}</p>
                      <p className="text-sm text-gray-500">
                        {player.position} • {player.age} anos
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-yellow-600">
                        Potencial: {player.potential}
                      </p>
                      <p className="text-xs text-gray-500">
                        Atual: {player.currentAbility}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </Card.Body>
    </Card>
  );
}