import React from 'react';
import { Card } from '../ui/card';
import { Search } from 'lucide-react';
import { Button } from '../ui/button';
import { useAcademyStore } from '../../store/academyStore';

export function YouthRecruitment() {
  const { academy, generateYouthPlayer } = useAcademyStore();

  if (!academy) {
    return null;
  }

  const canRecruitMore = academy.currentPlayers.length < academy.maxPlayers;
  const availableSpots = academy.maxPlayers - academy.currentPlayers.length;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Search className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold">Recrutamento</h2>
          </div>
          <Button
            variant="primary"
            onClick={generateYouthPlayer}
            disabled={!canRecruitMore}
          >
            Recrutar Jogador
          </Button>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          <div className="p-4 bg-blue-50 rounded-lg">
            <h3 className="font-medium text-blue-800 mb-2">
              Status do Recrutamento
            </h3>
            <p className="text-blue-700">
              {canRecruitMore 
                ? `${availableSpots} vagas disponíveis`
                : 'Academia está cheia'}
            </p>
            <p className="text-sm text-blue-600 mt-2">
              Nível de Observação: {academy.facilities.scouting}
            </p>
            <p className="text-sm text-blue-600">
              Próxima Formatura: {academy.nextGraduationDate.toLocaleDateString()}
            </p>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}