```tsx
import React from 'react';
import { useAcademyStore } from '../../store/academyStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Dumbbell, TrendingUp } from 'lucide-react';

export function YouthTraining() {
  const { academy, trainPlayers } = useAcademyStore();

  if (!academy) return null;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Dumbbell className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-bold">Treinamento</h2>
          </div>
          <Button
            variant="primary"
            onClick={trainPlayers}
            icon={<TrendingUp className="w-4 h-4" />}
          >
            Treinar Jogadores
          </Button>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-4">
          {academy.currentPlayers.length > 0 ? (
            academy.currentPlayers.map((player) => (
              <div
                key={player.id}
                className="p-4 bg-gray-50 rounded-lg flex justify-between items-center"
              >
                <div>
                  <h3 className="font-semibold">{player.name}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span>{player.position}</span>
                    <span>{player.age} anos</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-blue-600">
                    {player.currentAbility} → {player.potential}
                  </div>
                  <div className="text-sm text-gray-500">
                    Progresso: {Math.round(player.development.progress)}%
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-gray-500 py-4">
              Nenhum jogador na academia
            </p>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}
```