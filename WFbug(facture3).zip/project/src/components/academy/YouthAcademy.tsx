```tsx
import React from 'react';
import { useAcademyStore } from '../../store/academyStore';
import { useGameStore } from '../../store/gameStore';
import { YouthOverview } from './YouthOverview';
import { YouthTraining } from './YouthTraining';
import { YouthRecruitment } from './YouthRecruitment';
import { YouthFacilities } from './YouthFacilities';

export function YouthAcademy() {
  const academy = useAcademyStore((state) => state.academy);
  const currentTeam = useGameStore((state) => state.currentTeam);

  if (!academy || !currentTeam) return null;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <YouthOverview />
          <YouthTraining />
        </div>
        <div className="space-y-6">
          <YouthRecruitment />
          <YouthFacilities />
        </div>
      </div>
    </div>
  );
}
```