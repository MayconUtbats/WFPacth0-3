```tsx
import React from 'react';
import { YouthPlayer } from '../../types/academy';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { formatCurrency } from '../../utils/formatters';
import { GraduationCap, X } from 'lucide-react';

interface YouthPlayerCardProps {
  player: YouthPlayer;
  onGraduate: (playerId: string) => void;
  onDismiss: (playerId: string) => void;
}

export function YouthPlayerCard({ player, onGraduate, onDismiss }: YouthPlayerCardProps) {
  const getAbilityColor = (value: number) => {
    if (value >= 80) return 'text-green-600';
    if (value >= 60) return 'text-yellow-600';
    return 'text-gray-600';
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <Card.Body>
        <div className="space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold text-lg">{player.name}</h3>
              <p className="text-sm text-gray-500">
                {player.age} anos • {player.position}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">{formatCurrency(player.monthlySalary)}/mês</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Habilidade Atual</p>
              <p className={`font-bold ${getAbilityColor(player.currentAbility)}`}>
                {player.currentAbility}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Potencial</p>
              <p className={`font-bold ${getAbilityColor(player.potential)}`}>
                {player.potential}
              </p>
            </div>
          </div>

          <div className="flex justify-between space-x-2">
            <Button
              variant="primary"
              size="sm"
              className="flex-1"
              onClick={() => onGraduate(player.id)}
              icon={<GraduationCap className="w-4 h-4" />}
            >
              Promover
            </Button>
            <Button
              variant="danger"
              size="sm"
              onClick={() => onDismiss(player.id)}
              icon={<X className="w-4 h-4" />}
            >
              Dispensar
            </Button>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}
```