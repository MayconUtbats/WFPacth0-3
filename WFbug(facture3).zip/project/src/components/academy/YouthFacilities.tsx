import React from 'react';
import { useAcademyStore } from '../../store/academyStore';
import { Card } from '../ui/card';
import { Building2 } from 'lucide-react';
import { FacilityList } from './facilities/FacilityList';

export function YouthFacilities() {
  const { academy, upgradeFacility } = useAcademyStore();

  if (!academy) return null;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building2 className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold">Instalações da Base</h2>
          </div>
        </div>
        <p className="mt-2 text-sm text-gray-500">
          Melhore as instalações para desenvolver melhor os jovens talentos
        </p>
      </Card.Header>
      <Card.Body>
        <FacilityList
          facilities={academy.facilities}
          maxLevel={academy.level}
          onUpgrade={upgradeFacility}
        />
      </Card.Body>
    </Card>
  );
}