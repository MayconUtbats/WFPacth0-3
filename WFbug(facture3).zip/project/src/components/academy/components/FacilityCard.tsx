import React from 'react';
import { Card } from '../../ui/card';
import { Button } from '../../ui/button';
import { formatCurrency } from '../../../utils/formatters';

interface FacilityCardProps {
  name: string;
  description: string;
  icon: React.ElementType;
  level: number;
  maxLevel: number;
  upgradeCost: number;
  onUpgrade: () => void;
}

export function FacilityCard({
  name,
  description,
  icon: Icon,
  level,
  maxLevel,
  upgradeCost,
  onUpgrade
}: FacilityCardProps) {
  const progress = (level / maxLevel) * 100;

  return (
    <div className="p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-white rounded-lg shadow-sm">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{name}</h3>
            <p className="text-sm text-gray-500">
              Nível {level} / {maxLevel}
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={onUpgrade}
          disabled={level >= maxLevel}
          className="flex items-center space-x-1"
        >
          <span>{formatCurrency(upgradeCost)}</span>
        </Button>
      </div>

      <p className="mt-4 text-sm text-gray-600">{description}</p>

      <div className="mt-4">
        <div className="h-2 bg-gray-200 rounded-full">
          <div
            className="h-2 bg-blue-600 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}