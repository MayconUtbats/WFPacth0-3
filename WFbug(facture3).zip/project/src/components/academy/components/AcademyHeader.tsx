import React from 'react';
import { GraduationCap } from 'lucide-react';

export function AcademyHeader() {
  return (
    <div className="flex items-center space-x-3">
      <GraduationCap className="w-8 h-8 text-blue-600" />
      <div>
        <h2 className="text-2xl font-bold">Academia de Base</h2>
        <p className="text-sm text-gray-500">Desenvolva os futuros talentos do clube</p>
      </div>
    </div>
  );
}