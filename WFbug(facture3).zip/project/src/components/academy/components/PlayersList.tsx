import React from 'react';
import { Card } from '../../ui/card';
import { Button } from '../../ui/button';
import { YouthPlayerCard } from '../YouthPlayerCard';
import { YouthPlayer } from '../../../types/academy';

interface PlayersListProps {
  players: YouthPlayer[];
  maxPlayers: number;
  onRecruit: () => void;
  onGraduate: (playerId: string) => void;
  onDismiss: (playerId: string) => void;
}

export function PlayersList({
  players,
  maxPlayers,
  onRecruit,
  onGraduate,
  onDismiss,
}: PlayersListProps) {
  return (
    <Card>
      <Card.Header className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Jogadores da Base</h3>
        <Button
          variant="success"
          onClick={onRecruit}
          disabled={players.length >= maxPlayers}
        >
          Recrutar Jogador
        </Button>
      </Card.Header>
      <Card.Body>
        {players.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {players.map((player) => (
              <YouthPlayerCard
                key={player.id}
                player={player}
                onGraduate={onGraduate}
                onDismiss={onDismiss}
              />
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">
            Nenhum jogador na base ainda
          </p>
        )}
      </Card.Body>
    </Card>
  );
}