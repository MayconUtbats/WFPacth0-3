import React from 'react';
import { Users, DollarSign, GraduationCap } from 'lucide-react';
import { Card } from '../../ui/card';
import { formatCurrency } from '../../../utils/formatters';

interface AcademyStatsProps {
  currentPlayers: number;
  maxPlayers: number;
  monthlyFee: number;
  nextGraduationDate: Date;
}

export function AcademyStats({ 
  currentPlayers, 
  maxPlayers, 
  monthlyFee, 
  nextGraduationDate 
}: AcademyStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card>
        <Card.Header>
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold">Jogadores</h3>
          </div>
        </Card.Header>
        <Card.Body>
          <p className="text-2xl font-bold">
            {currentPlayers} / {maxPlayers}
          </p>
        </Card.Body>
      </Card>

      <Card>
        <Card.Header>
          <div className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            <h3 className="font-semibold">Custo Mensal</h3>
          </div>
        </Card.Header>
        <Card.Body>
          <p className="text-2xl font-bold">{formatCurrency(monthlyFee)}</p>
        </Card.Body>
      </Card>

      <Card>
        <Card.Header>
          <div className="flex items-center space-x-2">
            <GraduationCap className="w-5 h-5 text-purple-600" />
            <h3 className="font-semibold">Próxima Formatura</h3>
          </div>
        </Card.Header>
        <Card.Body>
          <p className="text-2xl font-bold">
            {nextGraduationDate.toLocaleDateString()}
          </p>
        </Card.Body>
      </Card>
    </div>
  );
}