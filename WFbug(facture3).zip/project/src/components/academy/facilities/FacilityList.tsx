import React from 'react';
import { Building2, Search, GraduationCap, Heart } from 'lucide-react';
import { FacilityCard } from './FacilityCard';
import { AcademyFacilities } from '../../../types/academy';

interface FacilityListProps {
  facilities: AcademyFacilities;
  maxLevel: number;
  onUpgrade: (facilityId: keyof AcademyFacilities) => void;
}

export function FacilityList({ facilities, maxLevel, onUpgrade }: FacilityListProps) {
  const facilityConfig = [
    {
      id: 'training',
      name: 'Centro de Treinamento',
      description: 'Melhore a qualidade dos treinos e o desenvolvimento dos jogadores',
      icon: Building2,
      upgradeCost: 500000,
    },
    {
      id: 'scouting',
      name: 'Departamento de Observação',
      description: 'Aumente a chance de encontrar talentos promissores',
      icon: Search,
      upgradeCost: 500000,
    },
    {
      id: 'education',
      name: 'Centro Educacional',
      description: 'Desenvolva as habilidades mentais e técnicas dos jovens',
      icon: GraduationCap,
      upgradeCost: 500000,
    },
    {
      id: 'medical',
      name: 'Departamento Médico',
      description: 'Cuide da saúde e recuperação dos atletas',
      icon: Heart,
      upgradeCost: 500000,
    },
  ] as const;

  return (
    <div className="grid grid-cols-1 gap-6">
      {facilityConfig.map((facility) => (
        <FacilityCard
          key={facility.id}
          name={facility.name}
          description={facility.description}
          icon={facility.icon}
          level={facilities[facility.id]}
          maxLevel={maxLevel}
          upgradeCost={facility.upgradeCost * (facilities[facility.id] + 1)}
          onUpgrade={() => onUpgrade(facility.id)}
        />
      ))}
    </div>
  );
}