import React from 'react';
import { useText } from '../../hooks/useText';
import { useAcademyStore } from '../../store/academyStore';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Building2, Search, GraduationCap, Heart } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

export function AcademyFacilities() {
  const text = useText();
  const academy = useAcademyStore((state) => state.academy);
  const { upgradeFacility } = useAcademyStore();
  const currentTeam = useGameStore((state) => state.currentTeam);

  if (!academy || !currentTeam) return null;

  const facilities = [
    { key: 'training', icon: Building2, label: text.academy.facilities.training },
    { key: 'scouting', icon: Search, label: text.academy.facilities.scouting },
    { key: 'education', icon: GraduationCap, label: text.academy.facilities.education },
    { key: 'medical', icon: Heart, label: text.academy.facilities.medical },
  ] as const;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Building2 className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold">{text.academy.facilities.title}</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {facilities.map(({ key, icon: Icon, label }) => (
            <div
              key={key}
              className="p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-white rounded-lg shadow-sm">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{label}</h3>
                    <p className="text-sm text-gray-500">
                      {text.academy.level} {academy.facilities[key]} / {academy.level}
                    </p>
                  </div>
                </div>
                {academy.facilities[key] < academy.level && (
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => upgradeFacility(key)}
                  >
                    {text.academy.upgrade} ({formatCurrency(500000 * (academy.facilities[key] + 1))})
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card.Body>
    </Card>
  );
}