import React, { useState } from 'react';
import { useAuthStore } from '../../../store/authStore';
import { Mail, Lock, User, Eye, EyeOff } from 'lucide-react';
import { Input } from '../../ui/input';
import { Button } from '../../ui/button';
import { toast } from 'react-hot-toast';

export function RegisterForm() {
  const register = useAuthStore((state) => state.register);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [credentials, setCredentials] = useState({
    email: '',
    username: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (credentials.password !== credentials.confirmPassword) {
      setError('As senhas não conferem');
      return;
    }

    setIsLoading(true);
    try {
      await register(credentials);
      toast.success('Cadastro realizado com sucesso!');
    } catch (err) {
      setError('Falha no cadastro');
      toast.error('Erro ao realizar cadastro');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentials(prev => ({ ...prev, [name]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="E-mail"
        type="email"
        name="email"
        icon={<Mail className="h-5 w-5 text-gray-400" />}
        value={credentials.email}
        onChange={handleChange}
        required
      />

      <Input
        label="Nome de usuário"
        type="text"
        name="username"
        icon={<User className="h-5 w-5 text-gray-400" />}
        value={credentials.username}
        onChange={handleChange}
        required
      />

      <Input
        label="Senha"
        type={showPassword ? 'text' : 'password'}
        name="password"
        icon={<Lock className="h-5 w-5 text-gray-400" />}
        value={credentials.password}
        onChange={handleChange}
        required
      />

      <Input
        label="Confirmar Senha"
        type={showPassword ? 'text' : 'password'}
        name="confirmPassword"
        icon={<Lock className="h-5 w-5 text-gray-400" />}
        value={credentials.confirmPassword}
        onChange={handleChange}
        required
        error={error}
      />

      <Button
        type="submit"
        variant="primary"
        isLoading={isLoading}
        className="w-full"
      >
        Cadastrar
      </Button>
    </form>
  );
}