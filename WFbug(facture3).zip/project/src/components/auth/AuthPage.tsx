import React, { useState } from 'react';
import { LoginForm } from './LoginForm';
import { RegisterForm } from './RegisterForm';
import { Trophy } from 'lucide-react';

export function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gray-100">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="p-4 bg-blue-600 rounded-2xl">
            <Trophy className="w-16 h-16 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          World Manager
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          {isLogin ? 'Não tem uma conta?' : 'Já tem uma conta?'}{' '}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="font-medium text-blue-600 hover:text-blue-500"
          >
            {isLogin ? 'Cadastre-se' : 'Entre'}
          </button>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          {isLogin ? <LoginForm /> : <RegisterForm />}
        </div>
      </div>

      <div className="mt-8 text-center">
        <div className="space-x-4">
          <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
            Política de Privacidade
          </a>
          <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
            Termos de Serviço
          </a>
          <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
            Suporte
          </a>
        </div>
      </div>
    </div>
  );
}