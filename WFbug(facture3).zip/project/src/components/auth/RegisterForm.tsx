import React, { useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { Mail, Lock, User, Eye, EyeOff } from 'lucide-react';
import { useText } from '../../hooks/useText';
import { Input } from '../ui/input';
import { Button } from '../ui/button';

export function RegisterForm() {
  const text = useText();
  const register = useAuthStore((state) => state.register);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [credentials, setCredentials] = useState({
    email: '',
    username: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (credentials.password !== credentials.confirmPassword) {
      setError('As senhas não conferem');
      return;
    }

    setIsLoading(true);
    try {
      await register(credentials);
    } catch (err) {
      setError('Falha no cadastro');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label={text.auth.email}
        type="email"
        icon={<Mail className="h-5 w-5 text-gray-400" />}
        value={credentials.email}
        onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
        required
      />

      <Input
        label="Nome de usuário"
        type="text"
        icon={<User className="h-5 w-5 text-gray-400" />}
        value={credentials.username}
        onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
        required
      />

      <Input
        label={text.auth.password}
        type={showPassword ? 'text' : 'password'}
        icon={<Lock className="h-5 w-5 text-gray-400" />}
        value={credentials.password}
        onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
        required
        endAdornment={
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="text-gray-400 hover:text-gray-600"
          >
            {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        }
      />

      <Input
        label={text.auth.confirmPassword}
        type={showConfirmPassword ? 'text' : 'password'}
        icon={<Lock className="h-5 w-5 text-gray-400" />}
        value={credentials.confirmPassword}
        onChange={(e) => setCredentials({ ...credentials, confirmPassword: e.target.value })}
        required
        endAdornment={
          <button
            type="button"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            className="text-gray-400 hover:text-gray-600"
          >
            {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        }
      />

      {error && (
        <div className="text-red-500 text-sm bg-red-50 p-3 rounded-lg">
          {error}
        </div>
      )}

      <Button
        type="submit"
        variant="primary"
        isLoading={isLoading}
        className="w-full"
      >
        {text.auth.register}
      </Button>
    </form>
  );
}