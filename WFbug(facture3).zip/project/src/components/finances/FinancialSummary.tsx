import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface FinancialSummaryProps {
  balance: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlyBalance: number;
}

export function FinancialSummary({
  balance,
  monthlyIncome,
  monthlyExpenses,
  monthlyBalance,
}: FinancialSummaryProps) {
  const SummaryCard = ({ title, amount, icon: Icon, trend = 'neutral' }) => (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-700">{title}</h3>
        <Icon className={`w-6 h-6 ${
          trend === 'positive' ? 'text-green-500' :
          trend === 'negative' ? 'text-red-500' :
          'text-blue-500'
        }`} />
      </div>
      <p className={`text-2xl font-bold ${
        trend === 'positive' ? 'text-green-600' :
        trend === 'negative' ? 'text-red-600' :
        'text-gray-900'
      }`}>
        {formatCurrency(amount)}
      </p>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <SummaryCard
        title="Saldo"
        amount={balance}
        icon={Wallet}
      />
      <SummaryCard
        title="Receita Mensal"
        amount={monthlyIncome}
        icon={TrendingUp}
        trend="positive"
      />
      <SummaryCard
        title="Despesas Mensais"
        amount={monthlyExpenses}
        icon={TrendingDown}
        trend="negative"
      />
      <SummaryCard
        title="Balanço Mensal"
        amount={monthlyBalance}
        icon={DollarSign}
        trend={monthlyBalance >= 0 ? 'positive' : 'negative'}
      />
    </div>
  );
}