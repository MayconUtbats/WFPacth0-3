import React from 'react';
import { useTranslation } from '../../hooks/useTranslation';
import { TrendingDown, Users, Building2, Package } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface ExpensesBreakdownProps {
  salaries: number;
  facilities: number;
  transfers: number;
  other: number;
}

export function ExpensesBreakdown({
  salaries,
  facilities,
  transfers,
  other,
}: ExpensesBreakdownProps) {
  const { t } = useTranslation();

  const totalExpenses = salaries + facilities + transfers + other;

  const ExpenseItem = ({ icon: Icon, title, amount, percentage }) => (
    <div className="flex items-center justify-between p-4 border-b last:border-0">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-red-100 rounded-lg">
          <Icon className="w-5 h-5 text-red-600" />
        </div>
        <div>
          <p className="font-medium text-gray-900">{title}</p>
          <p className="text-sm text-gray-500">{percentage}%</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-bold text-gray-900">{formatCurrency(amount)}</p>
        <p className="text-sm text-gray-500">Drex</p>
      </div>
    </div>
  );

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-6 border-b">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-bold text-gray-900">
            {t('finances.expenses.title')}
          </h2>
          <TrendingDown className="w-6 h-6 text-red-600" />
        </div>
        <p className="text-gray-600">{t('finances.expenses.description')}</p>
      </div>

      <div className="divide-y">
        <ExpenseItem
          icon={Users}
          title={t('finances.expenses.salaries')}
          amount={salaries}
          percentage={Math.round((salaries / totalExpenses) * 100)}
        />
        <ExpenseItem
          icon={Building2}
          title={t('finances.expenses.facilities')}
          amount={facilities}
          percentage={Math.round((facilities / totalExpenses) * 100)}
        />
        <ExpenseItem
          icon={Package}
          title={t('finances.expenses.transfers')}
          amount={transfers}
          percentage={Math.round((transfers / totalExpenses) * 100)}
        />
        <ExpenseItem
          icon={Package}
          title={t('finances.expenses.other')}
          amount={other}
          percentage={Math.round((other / totalExpenses) * 100)}
        />
      </div>

      <div className="p-6 bg-gray-50 rounded-b-lg">
        <div className="flex items-center justify-between">
          <p className="font-medium text-gray-700">{t('finances.expenses.total')}</p>
          <div className="text-right">
            <p className="text-xl font-bold text-red-600">{formatCurrency(totalExpenses)}</p>
            <p className="text-sm text-gray-500">Drex</p>
          </div>
        </div>
      </div>
    </div>
  );
}