import React from 'react';
import { useGameStore } from '../../store/gameStore';
import { useStadiumStore } from '../../store/stadiumStore';
import { IncomeBreakdown } from './IncomeBreakdown';
import { ExpensesBreakdown } from './ExpensesBreakdown';
import { FinancialSummary } from './FinancialSummary';
import { DollarSign } from 'lucide-react';
import { Card } from '../ui/card';

export function FinancesOverview() {
  const { currentTeam } = useGameStore();
  const stadium = useStadiumStore((state) => state.stadium);

  if (!currentTeam || !stadium) return null;

  // Cálculo de receitas
  const matchdayIncome = stadium.currentAttendance * stadium.ticketPrice;
  const sponsorshipIncome = 100000; // Valor fixo mensal de patrocínio
  const tvRightsIncome = 200000; // Valor fixo mensal de direitos de TV
  const totalIncome = matchdayIncome + sponsorshipIncome + tvRightsIncome;

  // Cálculo de despesas
  const totalSalaries = currentTeam.players.reduce((sum, player) => sum + player.salary, 0);
  const stadiumMaintenance = stadium.maintenanceCost;
  const otherExpenses = 50000; // Custos operacionais fixos
  const totalExpenses = totalSalaries + stadiumMaintenance + otherExpenses;

  // Balanço final
  const monthlyBalance = totalIncome - totalExpenses;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center">
          <DollarSign className="w-8 h-8 text-green-600 mr-2" />
          Finanças
        </h1>
        <p className="text-gray-600 mt-2">Gestão financeira do clube</p>
      </div>

      <FinancialSummary
        balance={currentTeam.budget}
        monthlyIncome={totalIncome}
        monthlyExpenses={totalExpenses}
        monthlyBalance={monthlyBalance}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <IncomeBreakdown
          matchdayIncome={matchdayIncome}
          sponsorshipIncome={sponsorshipIncome}
          tvRightsIncome={tvRightsIncome}
        />
        
        <ExpensesBreakdown
          salaries={totalSalaries}
          facilities={stadiumMaintenance}
          transfers={0}
          other={otherExpenses}
        />
      </div>
    </div>
  );
}