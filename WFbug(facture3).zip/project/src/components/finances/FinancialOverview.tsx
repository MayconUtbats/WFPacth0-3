import React from 'react';
import { useTranslation } from '../../hooks/useTranslation';
import { DollarSign, TrendingUp, TrendingDown, PieChart } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import { useFinanceStore } from '../../store/financeStore';
import { IncomeBreakdown } from './IncomeBreakdown';
import { ExpensesBreakdown } from './ExpensesBreakdown';
import { FinancialSummary } from './FinancialSummary';
import { formatCurrency } from '../../utils/formatters';

export function FinancialOverview() {
  const { t } = useTranslation();
  const { currentTeam } = useGameStore();
  const finances = useFinanceStore();

  if (!currentTeam) return null;

  const totalIncome = Object.values(finances.income).reduce((a, b) => a + b, 0);
  const totalExpenses = Object.values(finances.expenses).reduce((a, b) => a + b, 0);
  const monthlyBalance = totalIncome - totalExpenses;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center">
          <DollarSign className="w-8 h-8 text-green-600 mr-2" />
          {t('finances.title')}
        </h1>
        <p className="text-gray-600 mt-2">{t('finances.description')}</p>
      </div>

      <FinancialSummary
        balance={finances.balance}
        monthlyIncome={totalIncome}
        monthlyExpenses={totalExpenses}
        monthlyBalance={monthlyBalance}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <IncomeBreakdown
          matchdayIncome={finances.income.matchday}
          sponsorshipIncome={finances.income.commercial}
          tvRightsIncome={finances.income.broadcasting}
        />
        
        <ExpensesBreakdown
          salaries={finances.expenses.wages}
          facilities={finances.expenses.facilities}
          transfers={finances.expenses.transfers}
          other={finances.expenses.other}
        />
      </div>

      <div className="mt-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <PieChart className="w-6 h-6 text-blue-600 mr-2" />
            {t('finances.transactions.recent')}
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b">
                  <th className="pb-2">Data</th>
                  <th className="pb-2">Descrição</th>
                  <th className="pb-2">Categoria</th>
                  <th className="pb-2 text-right">Valor</th>
                </tr>
              </thead>
              <tbody>
                {finances.transactions.slice(0, 10).map((transaction) => (
                  <tr key={transaction.id} className="border-b">
                    <td className="py-2">
                      {new Date(transaction.date).toLocaleDateString()}
                    </td>
                    <td className="py-2">{transaction.description}</td>
                    <td className="py-2 capitalize">{transaction.category}</td>
                    <td className={`py-2 text-right font-medium ${
                      transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'} {formatCurrency(transaction.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}