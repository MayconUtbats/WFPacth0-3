import React from 'react';
import { TrendingUp, Ticket, Tv, Award } from 'lucide-react';
import { Card } from '../ui/card';
import { formatCurrency } from '../../utils/formatters';

interface IncomeBreakdownProps {
  matchdayIncome: number;
  sponsorshipIncome: number;
  tvRightsIncome: number;
}

export function IncomeBreakdown({
  matchdayIncome,
  sponsorshipIncome,
  tvRightsIncome,
}: IncomeBreakdownProps) {
  const totalIncome = matchdayIncome + sponsorshipIncome + tvRightsIncome;

  const IncomeItem = ({ icon: Icon, title, amount, percentage }) => (
    <div className="flex items-center justify-between p-4 border-b last:border-0">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-green-100 rounded-lg">
          <Icon className="w-5 h-5 text-green-600" />
        </div>
        <div>
          <p className="font-medium text-gray-900">{title}</p>
          <p className="text-sm text-gray-500">{percentage}%</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-bold text-gray-900">{formatCurrency(amount)}</p>
      </div>
    </div>
  );

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-bold text-gray-900">
            Receitas
          </h2>
          <TrendingUp className="w-6 h-6 text-green-600" />
        </div>
      </Card.Header>

      <Card.Body>
        <div className="divide-y">
          <IncomeItem
            icon={Ticket}
            title="Bilheteria"
            amount={matchdayIncome}
            percentage={Math.round((matchdayIncome / totalIncome) * 100)}
          />
          <IncomeItem
            icon={Award}
            title="Patrocínios"
            amount={sponsorshipIncome}
            percentage={Math.round((sponsorshipIncome / totalIncome) * 100)}
          />
          <IncomeItem
            icon={Tv}
            title="Direitos de TV"
            amount={tvRightsIncome}
            percentage={Math.round((tvRightsIncome / totalIncome) * 100)}
          />
        </div>

        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between">
            <p className="font-medium text-gray-700">Total</p>
            <p className="text-xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}