import React from 'react';
import { Input, InputProps } from '../input';

interface FormFieldProps extends InputProps {
  name: string;
  label: string;
}

export function FormField({ name, label, ...props }: FormFieldProps) {
  return (
    <div className="space-y-1">
      <Input
        name={name}
        label={label}
        {...props}
      />
    </div>
  );
}