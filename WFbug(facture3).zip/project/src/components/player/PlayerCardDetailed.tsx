import React from 'react';
import { Card } from '../ui/card';
import { Player } from '../../types/game';
import { PlayerNameLink } from './PlayerNameLink';
import { Star, Activity, Heart, Brain, Zap, Trophy, Flag } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import { getPositionName, getPositionColor } from '../../utils/nameGenerator';

interface PlayerCardDetailedProps {
  player: Player;
  showFullAttributes?: boolean;
}

export function PlayerCardDetailed({ player, showFullAttributes = true }: PlayerCardDetailedProps) {
  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <Card.Body>
        <div className="space-y-4">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div>
              <PlayerNameLink 
                playerId={player.id} 
                playerName={player.name} 
                className="text-lg font-bold"
              />
              <div className="flex items-center space-x-2 mt-1">
                <span className={`px-2 py-0.5 text-xs rounded-full ${getPositionColor(player.position)}`}>
                  {getPositionName(player.position)}
                </span>
                <span className="text-sm text-gray-500">{player.age} anos</span>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="text-center">
                <Star className="w-5 h-5 text-yellow-500 mx-auto" />
                <span className="text-sm font-medium">{player.rating}</span>
              </div>
              <div className="text-center">
                <Activity className="w-5 h-5 text-green-500 mx-auto" />
                <span className="text-sm font-medium">{player.stamina}%</span>
              </div>
            </div>
          </div>

          {/* Atributos */}
          {showFullAttributes && (
            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div className="space-y-2">
                <h4 className="font-medium flex items-center">
                  <Zap className="w-4 h-4 text-blue-500 mr-2" />
                  Físico
                </h4>
                <div className="space-y-1">
                  <AttributeBar label="Velocidade" value={player.attributes?.physical?.speed || 0} />
                  <AttributeBar label="Força" value={player.attributes?.physical?.strength || 0} />
                  <AttributeBar label="Resistência" value={player.attributes?.physical?.stamina || 0} />
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium flex items-center">
                  <Brain className="w-4 h-4 text-purple-500 mr-2" />
                  Técnico
                </h4>
                <div className="space-y-1">
                  <AttributeBar label="Passe" value={player.attributes?.technical?.passing || 0} />
                  <AttributeBar label="Finalização" value={player.attributes?.technical?.shooting || 0} />
                  <AttributeBar label="Drible" value={player.attributes?.technical?.dribbling || 0} />
                </div>
              </div>
            </div>
          )}

          {/* Informações Contratuais */}
          <div className="pt-4 border-t">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Salário</span>
              <span className="font-medium">{formatCurrency(player.salary)}/mês</span>
            </div>
            {player.contract && (
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-600">Contrato até</span>
                <span className="font-medium">{new Date(player.contract.endDate).getFullYear()}</span>
              </div>
            )}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}

function AttributeBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-gray-600">{label}</span>
      <div className="flex items-center space-x-2">
        <div className="w-24 h-2 bg-gray-200 rounded-full">
          <div 
            className="h-full bg-blue-600 rounded-full"
            style={{ width: `${value}%` }}
          />
        </div>
        <span className="text-sm font-medium w-6 text-right">{value}</span>
      </div>
    </div>
  );
}