import React from 'react';
import { Card } from '../ui/card';
import { Player } from '../../types/game';
import { PlayerNameLink } from './PlayerNameLink';
import { Star, Activity, Search } from 'lucide-react';
import { Button } from '../ui/button';
import { formatCurrency } from '../../utils/formatters';
import { getPositionName, getPositionColor } from '../../utils/nameGenerator';

interface PlayerCardScoutProps {
  player: Player;
  onScout?: () => void;
}

export function PlayerCardScout({ player, onScout }: PlayerCardScoutProps) {
  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <Card.Body>
        <div className="space-y-4">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div>
              <PlayerNameLink 
                playerId={player.id} 
                playerName={player.name} 
                className="text-lg font-bold"
              />
              <div className="flex items-center space-x-2 mt-1">
                <span className={`px-2 py-0.5 text-xs rounded-full ${getPositionColor(player.position)}`}>
                  {getPositionName(player.position)}
                </span>
                <span className="text-sm text-gray-500">{player.age} anos</span>
              </div>
            </div>
            {onScout && (
              <Button
                variant="outline"
                size="sm"
                onClick={onScout}
                className="flex items-center space-x-2"
              >
                <Search className="w-4 h-4" />
                <span>Observar</span>
              </Button>
            )}
          </div>

          {/* Informações Básicas */}
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <Star className="w-5 h-5 text-yellow-500 mx-auto mb-1" />
              <span className="text-sm text-gray-600">Rating Estimado</span>
              <p className="font-medium mt-1">60-75</p>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <Activity className="w-5 h-5 text-green-500 mx-auto mb-1" />
              <span className="text-sm text-gray-600">Condição Física</span>
              <p className="font-medium mt-1">{player.stamina}%</p>
            </div>
          </div>

          {/* Informações Contratuais */}
          <div className="pt-4 border-t">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Salário Atual</span>
              <span className="font-medium">{formatCurrency(player.salary)}/mês</span>
            </div>
            {player.lastClub && (
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-600">Último Clube</span>
                <span className="font-medium">{player.lastClub}</span>
              </div>
            )}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}