import React from 'react';
import { Link } from 'react-router-dom';

interface PlayerNameLinkProps {
  playerId: string;
  playerName: string;
  className?: string;
}

export function PlayerNameLink({ playerId, playerName, className = '' }: PlayerNameLinkProps) {
  return (
    <Link 
      to={`/player/${playerId}`}
      className={`text-blue-600 hover:text-blue-800 hover:underline transition-colors ${className}`}
    >
      {playerName}
    </Link>
  );
}