import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Player } from '../../types/game';
import { ScoutReport } from '../../types/scouting';
import { useGameStore } from '../../store/gameStore';
import { getPositionName, getPositionColor } from '../../utils/nameGenerator';
import { Building2, ChevronDown, ChevronUp, Activity, MapPin, Search } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { formatCurrency } from '../../utils/formatters';

interface PlayerCardProps {
  player: Player;
  scoutReport?: ScoutReport;
  showAttributes?: boolean;
  onScout?: () => void;
}

export function PlayerCard({ player, scoutReport, showAttributes = false, onScout }: PlayerCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const currentTeam = useGameStore((state) => state.currentTeam);
  const isOwnPlayer = currentTeam?.players.some(p => p.id === player.id);

  const canViewAttributes = isOwnPlayer || showAttributes || scoutReport;

  return (
    <Card className="hover:shadow-lg transition-all duration-300 bg-white">
      <Card.Body>
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <Link 
                to={`/player/${player.id}`}
                className="text-lg font-bold text-gray-900 hover:text-blue-600 transition-colors"
              >
                {player.name}
              </Link>
              <div className="flex items-center space-x-2">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getPositionColor(player.position)}`}>
                  {getPositionName(player.position)}
                </span>
                <span className="text-sm text-gray-500">{player.age} anos</span>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4 py-2">
            {player.lastClub && (
              <div className="flex items-center space-x-2">
                <Building2 className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{player.lastClub}</span>
              </div>
            )}
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">{formatCurrency(player.salary)} /mês</span>
            </div>
          </div>

          {/* Attributes (if available) */}
          {canViewAttributes && showDetails && (
            <div className="space-y-4 pt-4 border-t">
              <h3 className="font-medium text-gray-900">Atributos</h3>
              {scoutReport ? (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Técnico</span>
                    <span className="font-medium">{scoutReport.attributes.technical}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Físico</span>
                    <span className="font-medium">{scoutReport.attributes.physical}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Mental</span>
                    <span className="font-medium">{scoutReport.attributes.mental}</span>
                  </div>
                  {scoutReport.potential && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Potencial</span>
                      <span className="font-medium text-blue-600">{scoutReport.potential}</span>
                    </div>
                  )}
                  <div className="mt-2 text-xs text-gray-500">
                    Confiança do relatório: {scoutReport.confidence}
                  </div>
                </div>
              ) : isOwnPlayer && player.attributes ? (
                <div className="space-y-2">
                  {/* Show full attributes for own players */}
                  {Object.entries(player.attributes).map(([category, value]) => (
                    <div key={category} className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">{category}</span>
                      <span className="font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-between pt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDetails(!showDetails)}
              className="text-gray-600 hover:text-gray-900"
            >
              {showDetails ? (
                <>
                  <ChevronUp className="w-4 h-4 mr-1" />
                  Menos
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4 mr-1" />
                  Mais
                </>
              )}
            </Button>
            {!isOwnPlayer && onScout && (
              <Button
                variant="primary"
                size="sm"
                onClick={onScout}
                className="flex items-center space-x-2"
              >
                <Search className="w-4 h-4" />
                <span>Observar Jogador</span>
              </Button>
            )}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}