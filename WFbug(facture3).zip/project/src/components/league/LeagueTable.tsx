```tsx
import React from 'react';
import { useLeagueStore } from '../../store/leagueStore';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/card';
import { Trophy, ArrowUp, ArrowDown } from 'lucide-react';
import { LeagueStanding } from '../../types/league';
import { LEAGUE_CONFIG } from '../../constants/leagues';

export function LeagueTable() {
  const { currentTeam } = useGameStore();
  const { getLeagueStandings } = useLeagueStore();

  if (!currentTeam) return null;

  const standings = getLeagueStandings(currentTeam.league);

  const getPositionStyle = (position: number) => {
    if (position <= LEAGUE_CONFIG.CONTINENTAL_SPOTS) {
      return 'bg-blue-100 text-blue-800';
    }
    if (position > standings.length - LEAGUE_CONFIG.RELEGATION_SPOTS) {
      return 'bg-red-100 text-red-800';
    }
    return '';
  };

  const getFormStyle = (result: 'W' | 'D' | 'L') => {
    switch (result) {
      case 'W': return 'bg-green-100 text-green-800';
      case 'D': return 'bg-yellow-100 text-yellow-800';
      case 'L': return 'bg-red-100 text-red-800';
      default: return '';
    }
  };

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Trophy className="w-6 h-6 text-yellow-500" />
          <h2 className="text-xl font-bold">Classificação</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b">
                <th className="pb-2">Pos</th>
                <th>Time</th>
                <th>P</th>
                <th>J</th>
                <th>V</th>
                <th>E</th>
                <th>D</th>
                <th>GP</th>
                <th>GC</th>
                <th>SG</th>
                <th>Pts</th>
                <th>Últimos 5</th>
              </tr>
            </thead>
            <tbody>
              {standings.map((team) => (
                <tr
                  key={team.teamId}
                  className={`border-b ${
                    team.teamId === currentTeam.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <td className={`py-2 ${getPositionStyle(team.position)}`}>
                    {team.position}
                  </td>
                  <td className="font-medium">{team.teamId}</td>
                  <td>{team.played}</td>
                  <td>{team.won}</td>
                  <td>{team.drawn}</td>
                  <td>{team.lost}</td>
                  <td>{team.goalsFor}</td>
                  <td>{team.goalsAgainst}</td>
                  <td>{team.goalDifference}</td>
                  <td className="font-bold">{team.points}</td>
                  <td>
                    <div className="flex space-x-1">
                      {team.form.map((result, index) => (
                        <span
                          key={index}
                          className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-medium ${getFormStyle(
                            result
                          )}`}
                        >
                          {result}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 space-y-2">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-blue-100 rounded" />
            <span className="text-sm text-gray-600">
              Classificação Continental (7 primeiros)
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-100 rounded" />
            <span className="text-sm text-gray-600">
              Zona de Rebaixamento (4 últimos)
            </span>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}
```