import React from 'react';
import { useGameStore } from '../store/gameStore';
import { Card } from './ui/card';
import { Users, Star, Activity } from 'lucide-react';
import { getPositionName, getPositionColor } from '../utils/nameGenerator';
import { formatCurrency } from '../utils/formatters';
import { PlayerNameLink } from './player/PlayerNameLink';

export function Squad() {
  const { currentTeam } = useGameStore();

  if (!currentTeam) {
    return (
      <Card className="p-6">
        <div className="text-center text-gray-500">
          <Users className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p>Nenhum time selecionado</p>
        </div>
      </Card>
    );
  }

  const playersByPosition = {
    GK: currentTeam.players.filter(p => p.position === 'GK'),
    DEF: currentTeam.players.filter(p => p.position === 'DEF'),
    MID: currentTeam.players.filter(p => p.position === 'MID'),
    FWD: currentTeam.players.filter(p => p.position === 'FWD'),
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Users className="w-6 h-6 text-blue-600 mr-2" />
          Elenco
        </h1>
        <p className="text-gray-500 mt-1">Gerencie os jogadores do seu time</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {Object.entries(playersByPosition).map(([position, players]) => (
          <Card key={position}>
            <Card.Header>
              <h2 className="text-lg font-semibold">
                {getPositionName(position)}
                <span className="text-sm text-gray-500 ml-2">
                  ({players.length} jogadores)
                </span>
              </h2>
            </Card.Header>
            <Card.Body>
              <div className="space-y-2">
                {players.map(player => (
                  <div
                    key={player.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div>
                      <PlayerNameLink 
                        playerId={player.id} 
                        playerName={player.name}
                        className="font-medium"
                      />
                      <div className="flex items-center space-x-2 mt-1">
                        <span className={`px-2 py-0.5 text-xs rounded-full ${getPositionColor(player.position)}`}>
                          {player.position}
                        </span>
                        <span className="text-sm text-gray-500">{player.age} anos</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span className="font-medium">{player.rating}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Activity className="w-4 h-4 text-green-500" />
                          <span className="font-medium">{player.stamina}%</span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        {formatCurrency(player.salary)}/mês
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
}