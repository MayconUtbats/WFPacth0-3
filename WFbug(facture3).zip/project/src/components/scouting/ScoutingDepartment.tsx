import React from 'react';
import { useScoutingStore } from '../../store/scoutingStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Users, TrendingUp, DollarSign } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

export function ScoutingDepartment() {
  const { department, upgradeScout } = useScoutingStore();

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Users className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold">Departamento de Observação</h2>
          </div>
          <span className="text-sm text-gray-500">
            Orçamento: {formatCurrency(department.budget)}
          </span>
        </div>
      </Card.Header>

      <Card.Body>
        <div className="space-y-6">
          {/* Scouts List */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Observadores</h3>
            <div className="grid gap-4">
              {department.scouts.map(scout => (
                <div 
                  key={scout.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <h4 className="font-medium">{scout.name}</h4>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>Nível {scout.level}</span>
                      <span>Precisão {scout.accuracy}%</span>
                      {scout.specialization && (
                        <span className="capitalize">{scout.specialization}</span>
                      )}
                    </div>
                  </div>

                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => upgradeScout(scout.id)}
                    disabled={scout.level >= 5}
                    className="flex items-center space-x-2"
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>Melhorar</span>
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Reports */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Relatórios Recentes</h3>
            <div className="grid gap-4">
              {department.reports.slice(-5).map(report => (
                <div 
                  key={report.id}
                  className="p-4 bg-gray-50 rounded-lg"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">
                        Relatório #{report.id.slice(0, 8)}
                      </p>
                      <p className="text-sm text-gray-600">
                        {new Date(report.date).toLocaleDateString()}
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded text-sm ${
                      report.confidence === 'high' ? 'bg-green-100 text-green-800' :
                      report.confidence === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {report.confidence === 'high' ? 'Alta Confiança' :
                       report.confidence === 'medium' ? 'Média Confiança' :
                       'Baixa Confiança'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}