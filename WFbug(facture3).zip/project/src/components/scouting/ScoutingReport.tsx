import React from 'react';
import { ScoutReport, Scout } from '../../types/scouting';
import { Player } from '../../types/game';
import { Card } from '../ui/card';
import { Search, Calendar, User, Percent } from 'lucide-react';
import { format } from 'date-fns';

interface ScoutingReportProps {
  report: ScoutReport;
  player: Player;
  scout: Scout;
}

export function ScoutingReport({ report, player, scout }: ScoutingReportProps) {
  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold">Relatório de Observação</h3>
          <span className={`px-2 py-1 rounded text-sm ${
            report.confidence === 'high' ? 'bg-green-100 text-green-800' :
            report.confidence === 'medium' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            {report.confidence === 'high' ? 'Alta Confiança' :
             report.confidence === 'medium' ? 'Média Confiança' :
             'Baixa Confiança'}
          </span>
        </div>
      </Card.Header>

      <Card.Body>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">
                {format(report.date, 'dd/MM/yyyy')}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">
                {scout.name} (Nível {scout.level})
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium text-gray-900">Atributos Observados</h4>
            {Object.entries(report.attributes).map(([attr, value]) => (
              <div key={attr} className="flex justify-between items-center">
                <span className="text-sm text-gray-600">{attr}</span>
                <div className="flex items-center space-x-2">
                  <span className="font-medium">{value}</span>
                  <Percent className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-500">{report.accuracy}% precisão</span>
                </div>
              </div>
            ))}
          </div>

          {report.potential && (
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Potencial</h4>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-blue-600">{report.potential}</span>
                <span className="text-sm text-gray-500">pontos estimados</span>
              </div>
            </div>
          )}

          {report.notes && (
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Observações</h4>
              <p className="text-sm text-gray-600">{report.notes}</p>
            </div>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}