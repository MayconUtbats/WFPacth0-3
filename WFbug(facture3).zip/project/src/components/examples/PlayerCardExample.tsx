import React, { useState } from 'react';
import { PlayerCard } from '../player/PlayerCard';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Search } from 'lucide-react';

// Example player data
const examplePlayer = {
  id: '1',
  name: 'Carlos Silva',
  position: 'ATA',
  age: 23,
  rating: 75,
  stamina: 85,
  salary: 15000,
  lastClub: 'Santos FC'
};

// Example scout report data
const exampleScoutReport = {
  id: '1',
  playerId: '1',
  scoutId: '1',
  date: new Date(),
  accuracy: 85,
  attributes: {
    technical: 76,
    physical: 82,
    mental: 73
  },
  potential: 85,
  notes: 'Jogador promissor com boa finalização e velocidade',
  confidence: 'high' as const
};

export function PlayerCardExample() {
  const [isScoutingComplete, setIsScoutingComplete] = useState(false);

  const handleScout = () => {
    // Simulate scouting delay
    setTimeout(() => {
      setIsScoutingComplete(true);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Before Scouting */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900">Antes da Observação</h2>
          <div className="bg-gray-50 p-6 rounded-lg">
            <PlayerCard
              player={examplePlayer}
              onScout={handleScout}
            />
          </div>
          <p className="text-sm text-gray-600">
            Apenas informações básicas são visíveis. Atributos e potencial estão ocultos.
          </p>
        </div>

        {/* After Scouting */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900">Após a Observação</h2>
          <div className="bg-gray-50 p-6 rounded-lg">
            <PlayerCard
              player={examplePlayer}
              scoutReport={isScoutingComplete ? exampleScoutReport : undefined}
              showAttributes={isScoutingComplete}
            />
          </div>
          <p className="text-sm text-gray-600">
            {isScoutingComplete 
              ? 'Atributos e potencial revelados pelo relatório do observador.'
              : 'Clique em "Observar Jogador" para revelar os atributos.'}
          </p>
        </div>
      </div>

      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <Card.Body>
          <h3 className="font-bold text-blue-900 mb-2">Como funciona:</h3>
          <ul className="list-disc list-inside space-y-2 text-blue-800">
            <li>Inicialmente, apenas informações básicas são visíveis (nome, idade, posição, etc.)</li>
            <li>Ao enviar um observador, os atributos do jogador são revelados gradualmente</li>
            <li>A precisão e confiança do relatório dependem do nível do observador</li>
            <li>O potencial do jogador só é revelado por observadores mais experientes</li>
          </ul>
        </Card.Body>
      </Card>
    </div>
  );
}