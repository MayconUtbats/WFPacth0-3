import React from 'react';
import { Trophy } from 'lucide-react';
import { useGameStore } from '../store/gameStore';
import { Team } from '../types/game';

const defaultTeams: Team[] = [
  {
    id: '1',
    name: 'Manchester United',
    players: [],
    budget: 100000000,
    league: 'Premier League',
    division: 1,
  },
  {
    id: '2',
    name: 'Real Madrid',
    players: [],
    budget: 120000000,
    league: 'La Liga',
    division: 1,
  },
];

export function TeamSelection() {
  const { setTeam, initializeTeam } = useGameStore();

  const handleTeamSelect = (team: Team) => {
    setTeam(team);
    initializeTeam(team);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-700 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-8">
          <Trophy className="w-12 h-12 text-yellow-400 mr-4" />
          <h1 className="text-4xl font-bold text-white">Football Manager</h1>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {defaultTeams.map((team) => (
            <button
              key={team.id}
              onClick={() => handleTeamSelect(team)}
              className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <h3 className="text-xl font-bold mb-2">{team.name}</h3>
              <p className="text-gray-600">{team.league}</p>
              <p className="text-sm text-gray-500">Budget: ${(team.budget / 1000000).toFixed(1)}M</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}