import React, { useState } from 'react';
import { useContractStore } from '../../store/contractStore';
import { Player } from '../../types/game';
import { ContractOffer, NegotiationCard } from '../../types/contracts';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { formatCurrency } from '../../utils/formatters';
import { DollarSign, Award, Clock, Shield, Sparkles } from 'lucide-react';

interface ContractNegotiationProps {
  player: Player;
  onClose: () => void;
}

export function ContractNegotiation({ player, onClose }: ContractNegotiationProps) {
  const { startNegotiation, makeOffer, useCard, activeNegotiations } = useContractStore();
  const [selectedCard, setSelectedCard] = useState<NegotiationCard | null>(null);

  const negotiation = Array.from(activeNegotiations.values())[0];

  const handleStartNegotiation = () => {
    startNegotiation(player);
  };

  const handleMakeOffer = (offer: Partial<ContractOffer>) => {
    makeOffer(player.id, offer);
  };

  const handleUseCard = (cardId: string) => {
    if (negotiation) {
      useCard(negotiation.currentOffer.id, cardId);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white">
        <Card.Header>
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Contract Negotiation</h2>
            <Button variant="ghost" onClick={onClose}>Close</Button>
          </div>
        </Card.Header>

        <Card.Body>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Player Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{player.name}</h3>
                  <p className="text-gray-600">{player.position} • {player.age} years</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">Current Salary</p>
                  <p className="font-bold">{formatCurrency(player.salary)}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">Rating</p>
                  <p className="font-bold">{player.rating}</p>
                </div>
              </div>
            </div>

            {/* Negotiation Area */}
            <div className="space-y-4">
              {negotiation ? (
                <>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold mb-2">Current Offer</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Base Salary:</span>
                        <span className="font-bold">
                          {formatCurrency(negotiation.currentOffer.baseSalary)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span className="font-bold">
                          {negotiation.currentOffer.duration} years
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {negotiation.availableCards.map(card => (
                      <button
                        key={card.id}
                        onClick={() => handleUseCard(card.id)}
                        className={`p-3 rounded-lg border transition-all ${
                          selectedCard?.id === card.id
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-blue-300'
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          <Sparkles className="w-4 h-4 text-blue-500" />
                          <span className="font-medium">{card.name}</span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{card.description}</p>
                      </button>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-8">
                  <Button
                    variant="primary"
                    onClick={handleStartNegotiation}
                    className="w-full"
                  >
                    Start Negotiation
                  </Button>
                </div>
              )}
            </div>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
}