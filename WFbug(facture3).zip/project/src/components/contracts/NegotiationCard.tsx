import React from 'react';
import { NegotiationCard as NegotiationCardType } from '../../types/contracts';
import { cn } from '../../utils/cn';

interface NegotiationCardProps {
  card: NegotiationCardType;
  onClick?: () => void;
  selected?: boolean;
  disabled?: boolean;
}

export function NegotiationCard({ card, onClick, selected, disabled }: NegotiationCardProps) {
  const rarityColors = {
    common: 'border-gray-200 bg-white',
    rare: 'border-blue-200 bg-blue-50',
    epic: 'border-purple-200 bg-purple-50',
    legendary: 'border-yellow-200 bg-yellow-50'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'p-4 rounded-lg border-2 transition-all duration-200 w-full text-left',
        rarityColors[card.rarity],
        selected && 'ring-2 ring-blue-500',
        disabled && 'opacity-50 cursor-not-allowed',
        !disabled && 'hover:shadow-md hover:-translate-y-1'
      )}
    >
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-gray-900">{card.name}</h3>
          <span className={cn(
            'text-xs px-2 py-1 rounded-full',
            {
              'bg-gray-100 text-gray-700': card.rarity === 'common',
              'bg-blue-100 text-blue-700': card.rarity === 'rare',
              'bg-purple-100 text-purple-700': card.rarity === 'epic',
              'bg-yellow-100 text-yellow-700': card.rarity === 'legendary',
            }
          )}>
            {card.rarity.toUpperCase()}
          </span>
        </div>
        
        <p className="text-sm text-gray-600">{card.description}</p>
        
        <div className="text-sm font-medium">
          {card.effect.modifier > 1 ? (
            <span className="text-green-600">+{((card.effect.modifier - 1) * 100).toFixed(0)}%</span>
          ) : (
            <span className="text-red-600">{((card.effect.modifier - 1) * 100).toFixed(0)}%</span>
          )}
          {' '}to {card.effect.target}
        </div>
      </div>
    </button>
  );
}