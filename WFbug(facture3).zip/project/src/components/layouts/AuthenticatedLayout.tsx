import React from 'react';
import { GameMenu } from '../menu/GameMenu';
import { Outlet } from 'react-router-dom';

export function AuthenticatedLayout() {
  return (
    <div className="flex min-h-screen bg-gray-100">
      <GameMenu />
      <main className="flex-1 p-6">
        <Outlet />
      </main>
    </div>
  );
}