import React from 'react';
import { useGameStore } from '../store/gameStore';
import { Trophy } from 'lucide-react';

interface TeamStats {
  teamId: string;
  teamName: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  points: number;
}

export function LeagueTable() {
  const { matches, currentTeam } = useGameStore();

  if (!currentTeam) return null;

  const leagueMatches = matches.filter(
    match => match.competition === 'league' && match.result
  );

  const calculateTeamStats = (): TeamStats[] => {
    const stats: Record<string, TeamStats> = {};

    leagueMatches.forEach(match => {
      const { homeTeam, awayTeam, result } = match;
      if (!result) return;

      // Initialize team stats if not exists
      [homeTeam, awayTeam].forEach(team => {
        if (!stats[team.id]) {
          stats[team.id] = {
            teamId: team.id,
            teamName: team.name,
            played: 0,
            won: 0,
            drawn: 0,
            lost: 0,
            goalsFor: 0,
            goalsAgainst: 0,
            points: 0,
          };
        }
      });

      // Update stats based on match result
      const homeStats = stats[homeTeam.id];
      const awayStats = stats[awayTeam.id];

      homeStats.played++;
      awayStats.played++;
      homeStats.goalsFor += result.homeScore;
      homeStats.goalsAgainst += result.awayScore;
      awayStats.goalsFor += result.awayScore;
      awayStats.goalsAgainst += result.homeScore;

      if (result.homeScore > result.awayScore) {
        homeStats.won++;
        awayStats.lost++;
        homeStats.points += 3;
      } else if (result.homeScore < result.awayScore) {
        awayStats.won++;
        homeStats.lost++;
        awayStats.points += 3;
      } else {
        homeStats.drawn++;
        awayStats.drawn++;
        homeStats.points += 1;
        awayStats.points += 1;
      }
    });

    return Object.values(stats).sort((a, b) => b.points - a.points);
  };

  const tableData = calculateTeamStats();

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <div className="flex items-center mb-4">
        <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
        <h2 className="text-2xl font-bold">League Table</h2>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left border-b-2">
              <th className="py-2">Pos</th>
              <th>Team</th>
              <th>P</th>
              <th>W</th>
              <th>D</th>
              <th>L</th>
              <th>GF</th>
              <th>GA</th>
              <th>Pts</th>
            </tr>
          </thead>
          <tbody>
            {tableData.map((team, index) => (
              <tr
                key={team.teamId}
                className={`border-b ${
                  team.teamId === currentTeam.id ? 'bg-blue-50' : ''
                }`}
              >
                <td className="py-2">{index + 1}</td>
                <td>{team.teamName}</td>
                <td>{team.played}</td>
                <td>{team.won}</td>
                <td>{team.drawn}</td>
                <td>{team.lost}</td>
                <td>{team.goalsFor}</td>
                <td>{team.goalsAgainst}</td>
                <td className="font-bold">{team.points}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}