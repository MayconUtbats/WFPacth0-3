import React, { useState } from 'react';
import { useTransferStore } from '../../store/transferStore';
import { useGameStore } from '../../store/gameStore';
import { Search, Filter, DollarSign } from 'lucide-react';
import { PlayerCard } from './PlayerCard';
import { TransferFilters } from './TransferFilters';
import { formatCurrency } from '../../utils/formatters';

export function TransferMarket() {
  const { listings, getPlayerOffers } = useTransferStore();
  const { currentTeam } = useGameStore();
  const [filters, setFilters] = useState({
    position: '',
    maxPrice: '',
    minPrice: '',
    searchTerm: '',
  });

  const filteredListings = listings.filter(listing => {
    const player = currentTeam?.players.find(p => p.id === listing.playerId);
    if (!player) return false;

    // Apply filters
    if (filters.position && player.position !== filters.position) return false;
    if (filters.maxPrice && listing.askingPrice > parseInt(filters.maxPrice)) return false;
    if (filters.minPrice && listing.askingPrice < parseInt(filters.minPrice)) return false;
    if (filters.searchTerm && !player.name.toLowerCase().includes(filters.searchTerm.toLowerCase())) return false;

    return listing.status === 'active';
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold flex items-center">
          <DollarSign className="w-8 h-8 text-green-600 mr-2" />
          Mercado de Transferências
        </h1>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar jogador..."
              className="pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => setFilters({ ...filters, searchTerm: e.target.value })}
            />
          </div>
          <TransferFilters filters={filters} onFilterChange={setFilters} />
        </div>
      </div>

      {filteredListings.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredListings.map(listing => {
            const player = currentTeam?.players.find(p => p.id === listing.playerId);
            const offers = getPlayerOffers(listing.playerId);
            
            if (!player) return null;

            return (
              <PlayerCard
                key={listing.id}
                player={player}
                listing={listing}
                offers={offers}
              />
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">
            Nenhum jogador encontrado com os filtros selecionados.
          </p>
        </div>
      )}
    </div>
  );
}