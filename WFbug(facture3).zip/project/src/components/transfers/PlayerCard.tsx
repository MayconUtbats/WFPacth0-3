import React, { useState } from 'react';
import { Player } from '../../types/game';
import { TransferListing, TransferOffer } from '../../types/transfer';
import { useTransferStore } from '../../store/transferStore';
import { formatCurrency } from '../../utils/formatters';
import { User, DollarSign, Clock, Award } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';

interface PlayerCardProps {
  player: Player;
  listing: TransferListing;
  offers: TransferOffer[];
}

export function PlayerCard({ player, listing, offers }: PlayerCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const { makeOffer, acceptOffer, rejectOffer } = useTransferStore();

  const handleMakeOffer = (amount: number) => {
    makeOffer(listing.id, amount);
  };

  const getPositionColor = (position: string) => {
    switch (position) {
      case 'GK': return 'bg-yellow-100 text-yellow-800';
      case 'DEF': return 'bg-blue-100 text-blue-800';
      case 'MID': return 'bg-green-100 text-green-800';
      case 'FWD': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <Card.Body>
        <div className="relative">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold">{player.name}</h3>
              <span className={`px-2 py-1 rounded-full text-sm font-medium ${getPositionColor(player.position)}`}>
                {player.position}
              </span>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Valor Pedido</div>
              <div className="text-lg font-bold text-green-600">
                {formatCurrency(listing.askingPrice)}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center">
                <Award className="w-4 h-4 text-yellow-500 mr-2" />
                <span className="text-sm">Rating: {player.rating}</span>
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-blue-500 mr-2" />
                <span className="text-sm">Idade: {player.age} anos</span>
              </div>
            </div>

            {showDetails && (
              <div className="space-y-2 pt-4 border-t">
                <h4 className="font-medium">Atributos</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {Object.entries(player.attributes || {}).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-gray-600">{key}</span>
                      <span className="font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-between items-center pt-4">
              <Button
                variant="default"
                size="sm"
                onClick={() => setShowDetails(!showDetails)}
              >
                {showDetails ? 'Menos Detalhes' : 'Mais Detalhes'}
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => handleMakeOffer(listing.askingPrice)}
              >
                Fazer Proposta
              </Button>
            </div>

            {offers.length > 0 && (
              <div className="mt-4 pt-4 border-t">
                <h4 className="font-medium mb-2">Propostas Recebidas</h4>
                <div className="space-y-2">
                  {offers.map(offer => (
                    <div key={offer.id} className="flex justify-between items-center text-sm">
                      <span>{formatCurrency(offer.offeredAmount)}</span>
                      <div className="space-x-2">
                        <Button
                          variant="success"
                          size="sm"
                          onClick={() => acceptOffer(offer.id)}
                        >
                          Aceitar
                        </Button>
                        <Button
                          variant="danger"
                          size="sm"
                          onClick={() => rejectOffer(offer.id)}
                        >
                          Rejeitar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}