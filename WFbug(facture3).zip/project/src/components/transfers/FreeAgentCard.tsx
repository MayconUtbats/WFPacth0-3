import React from 'react';
import { Link } from 'react-router-dom';
import { Player } from '../../types/game';
import { useTransferStore } from '../../store/transferStore';
import { Building2, ChevronDown, ChevronUp, Activity, MapPin } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { formatCurrency } from '../../utils/formatters';
import { getPositionName, getPositionColor } from '../../utils/nameGenerator';

interface FreeAgentCardProps {
  player: Player;
}

export function FreeAgentCard({ player }: FreeAgentCardProps) {
  const { makeContractOffer } = useTransferStore();

  return (
    <Card className="hover:shadow-lg transition-all duration-300 bg-white">
      <Card.Body>
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <Link 
                to={`/player/${player.id}`}
                className="text-lg font-bold text-gray-900 hover:text-blue-600 transition-colors"
              >
                {player.name}
              </Link>
              <div className="flex items-center space-x-2">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getPositionColor(player.position)}`}>
                  {getPositionName(player.position)}
                </span>
                <span className="text-sm text-gray-500">{player.age} anos</span>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4 py-2">
            {player.lastClub && (
              <div className="flex items-center space-x-2">
                <Building2 className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{player.lastClub}</span>
              </div>
            )}
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">{formatCurrency(player.salary)} /mês</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end pt-2">
            <Button
              variant="primary"
              onClick={() => makeContractOffer(player.id)}
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white"
            >
              Fazer Proposta
            </Button>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}