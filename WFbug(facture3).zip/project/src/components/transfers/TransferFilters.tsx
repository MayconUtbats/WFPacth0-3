import React from 'react';
import { Filter } from 'lucide-react';
import { Button } from '../ui/button';

interface TransferFiltersProps {
  filters: {
    position: string;
    maxPrice: string;
    minPrice: string;
    searchTerm: string;
  };
  onFilterChange: (filters: any) => void;
}

export function TransferFilters({ filters, onFilterChange }: TransferFiltersProps) {
  const positions = ['GK', 'DEF', 'MID', 'FWD'];

  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center space-x-2">
        <Filter className="w-5 h-5 text-gray-400" />
        <select
          value={filters.position}
          onChange={(e) => onFilterChange({ ...filters, position: e.target.value })}
          className="border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">Todas Posições</option>
          {positions.map(pos => (
            <option key={pos} value={pos}>{pos}</option>
          ))}
        </select>
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="number"
          placeholder="Preço Min"
          value={filters.minPrice}
          onChange={(e) => onFilterChange({ ...filters, minPrice: e.target.value })}
          className="border rounded-lg px-3 py-2 w-32 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
        <span>-</span>
        <input
          type="number"
          placeholder="Preço Max"
          value={filters.maxPrice}
          onChange={(e) => onFilterChange({ ...filters, maxPrice: e.target.value })}
          className="border rounded-lg px-3 py-2 w-32 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      <Button
        variant="default"
        onClick={() => onFilterChange({
          position: '',
          maxPrice: '',
          minPrice: '',
          searchTerm: '',
        })}
      >
        Limpar Filtros
      </Button>
    </div>
  );
}