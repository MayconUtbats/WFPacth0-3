import React, { useState } from 'react';
import { useTransferStore } from '../../store/transferStore';
import { Search, Users, Filter } from 'lucide-react';
import { FreeAgentCard } from './FreeAgentCard';
import { FreeAgentFilters } from './FreeAgentFilters';
import { Card } from '../ui/card';

export function FreeAgentsMarket() {
  const { freeAgents } = useTransferStore();
  const [filters, setFilters] = useState({
    position: '',
    maxAge: '',
    minAge: '',
    searchTerm: '',
  });
  const [showFilters, setShowFilters] = useState(false);

  const filteredAgents = freeAgents?.filter(player => {
    if (!player) return false;
    if (filters.position && player.position !== filters.position) return false;
    if (filters.maxAge && player.age > parseInt(filters.maxAge)) return false;
    if (filters.minAge && player.age < parseInt(filters.minAge)) return false;
    if (filters.searchTerm && !player.name.toLowerCase().includes(filters.searchTerm.toLowerCase())) return false;
    return true;
  }) || [];

  return (
    <Card className="overflow-hidden bg-gray-800">
      <div className="p-4 md:p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Users className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-bold text-white">Jogadores Livres</h2>
              <p className="text-sm text-gray-300">{filteredAgents.length} jogadores disponíveis</p>
            </div>
          </div>

          <div className="flex items-center space-x-2 md:space-x-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar jogador..."
                className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.searchTerm}
                onChange={(e) => setFilters({ ...filters, searchTerm: e.target.value })}
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="p-2 bg-gray-700 rounded-lg text-white hover:bg-gray-600 transition-colors"
            >
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="mb-6 pt-4 border-t border-gray-700">
            <FreeAgentFilters filters={filters} onFilterChange={setFilters} />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
          {filteredAgents.map(player => (
            <FreeAgentCard key={player.id} player={player} />
          ))}
        </div>

        {filteredAgents.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">
              Nenhum jogador livre encontrado com os filtros selecionados.
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}