import React from 'react';
import { Filter } from 'lucide-react';
import { Button } from '../ui/button';
import { Position } from '../../types/game';

interface FreeAgentFiltersProps {
  filters: {
    position: string;
    maxAge: string;
    minAge: string;
    searchTerm: string;
  };
  onFilterChange: (filters: any) => void;
}

export function FreeAgentFilters({ filters, onFilterChange }: FreeAgentFiltersProps) {
  const positionGroups = [
    {
      name: 'Goleiros',
      positions: ['GOL']
    },
    {
      name: 'Defensores',
      positions: ['ZAG', 'LD', 'LE']
    },
    {
      name: 'Meio-campistas',
      positions: ['VOL', 'MC', 'MD', 'ME', 'MEI']
    },
    {
      name: 'Atacantes',
      positions: ['PE', 'PD', 'SA', 'ATA']
    }
  ];

  const getPositionStyle = (pos: string) => {
    if (filters.position === pos) {
      switch (pos) {
        case 'GOL': return 'bg-yellow-600 text-white';
        case 'ZAG': case 'LD': case 'LE': return 'bg-blue-600 text-white';
        case 'VOL': case 'MC': case 'MD': case 'ME': case 'MEI': return 'bg-green-600 text-white';
        case 'PE': case 'PD': case 'SA': case 'ATA': return 'bg-red-600 text-white';
        default: return 'bg-gray-600 text-white';
      }
    }
    return 'bg-gray-700 text-white hover:bg-gray-600';
  };

  return (
    <div className="flex flex-col space-y-4">
      {positionGroups.map((group, index) => (
        <div key={index} className="space-y-2">
          <h3 className="text-sm font-medium text-gray-400">{group.name}</h3>
          <div className="flex flex-wrap gap-2">
            {group.positions.map(pos => (
              <button
                key={pos}
                onClick={() => onFilterChange({ ...filters, position: filters.position === pos ? '' : pos })}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${getPositionStyle(pos)}`}
              >
                {pos}
              </button>
            ))}
          </div>
        </div>
      ))}

      <div className="flex items-center space-x-2">
        <input
          type="number"
          placeholder="Idade Min"
          value={filters.minAge}
          onChange={(e) => onFilterChange({ ...filters, minAge: e.target.value })}
          className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 w-24 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <span className="text-white">-</span>
        <input
          type="number"
          placeholder="Idade Max"
          value={filters.maxAge}
          onChange={(e) => onFilterChange({ ...filters, maxAge: e.target.value })}
          className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 w-24 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <Button
        variant="ghost"
        onClick={() => onFilterChange({
          position: '',
          maxAge: '',
          minAge: '',
          searchTerm: '',
        })}
        className="text-white hover:bg-gray-700"
      >
        Limpar Filtros
      </Button>
    </div>
  );
}