import React from 'react';
import { TrendingUp } from 'lucide-react';
import { useFanStore } from '../../store/fanStore';
import { Card } from '../ui/card';
import { formatNumber } from '../../utils/formatters';

export function FanGrowthChart() {
  const { fanBase } = useFanStore();

  const growthData = [
    { label: 'Semanal', value: fanBase.growth.weekly },
    { label: 'Mensal', value: fanBase.growth.monthly },
    { label: 'Anual', value: fanBase.growth.yearly }
  ];

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-6 h-6 text-green-500" />
          <h2 className="text-xl font-bold">Crescimento da Torcida</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="grid grid-cols-3 gap-4">
          {growthData.map(({ label, value }) => (
            <div key={label} className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-600 mb-1">{label}</p>
              <p className="text-2xl font-bold text-green-500">
                +{formatNumber(value)}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-8">
          <h3 className="font-semibold mb-4">Fatores de Crescimento</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span>Lealdade</span>
                <span>{fanBase.loyalty}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-blue-500 rounded-full"
                  style={{ width: `${fanBase.loyalty}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span>Satisfação</span>
                <span>{fanBase.satisfaction}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${fanBase.satisfaction}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}