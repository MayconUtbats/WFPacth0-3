import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useFanStore } from '../../store/fanStore';
import { Card } from '../ui/card';
import { formatDate } from '../../utils/formatters';

export function FanEvents() {
  const { events } = useFanStore();

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'protest': return '🚫';
      case 'celebration': return '🎉';
      case 'support': return '👏';
      case 'criticism': return '😡';
      default: return '📢';
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'protest': return 'bg-red-50 text-red-700 border-red-200';
      case 'celebration': return 'bg-green-50 text-green-700 border-green-200';
      case 'support': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'criticism': return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <MessageCircle className="w-6 h-6 text-blue-500" />
          <h2 className="text-xl font-bold">Eventos da Torcida</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-4">
          {events.length > 0 ? (
            events.map((event) => (
              <div
                key={event.id}
                className={`p-4 rounded-lg border ${getEventColor(event.type)}`}
              >
                <div className="flex items-start space-x-3">
                  <span className="text-2xl">{getEventIcon(event.type)}</span>
                  <div className="flex-1">
                    <p className="font-medium">{event.description}</p>
                    <p className="text-sm mt-1 text-gray-500">
                      {formatDate(event.date)}
                    </p>
                  </div>
                  <span className={`text-sm ${event.impact > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {event.impact > 0 ? '+' : ''}{event.impact}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-gray-500 py-8">
              Nenhum evento da torcida registrado ainda.
            </p>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}