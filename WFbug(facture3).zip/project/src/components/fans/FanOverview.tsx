import React from 'react';
import { Users, TrendingUp, Heart, Activity } from 'lucide-react';
import { useFanStore } from '../../store/fanStore';
import { Card } from '../ui/card';
import { formatNumber } from '../../utils/formatters';

export function FanOverview() {
  const { fanBase, mood } = useFanStore();

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case 'ecstatic': return 'text-green-500';
      case 'happy': return 'text-green-400';
      case 'neutral': return 'text-gray-500';
      case 'unhappy': return 'text-red-400';
      case 'hostile': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Fan Base Overview */}
      <Card>
        <Card.Header>
          <div className="flex items-center space-x-2">
            <Users className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-bold">Base de Torcedores</h2>
          </div>
        </Card.Header>
        <Card.Body>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-600 mb-1">Total</p>
              <p className="text-2xl font-bold">{formatNumber(fanBase.total)}</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-600 mb-1">Presença no Estádio</p>
              <p className="text-2xl font-bold">{formatNumber(fanBase.matchdayAttendance)}</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-600 mb-1">Crescimento Mensal</p>
              <p className="text-2xl font-bold text-green-500">
                +{formatNumber(fanBase.growth.monthly)}
              </p>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-semibold mb-4">Distribuição de Torcedores</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Casuais</span>
                  <span>{formatNumber(fanBase.categories.casual)}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${(fanBase.categories.casual / fanBase.total) * 100}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Regulares</span>
                  <span>{formatNumber(fanBase.categories.regular)}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-green-500 rounded-full"
                    style={{ width: `${(fanBase.categories.regular / fanBase.total) * 100}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Fanáticos</span>
                  <span>{formatNumber(fanBase.categories.fanatic)}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-red-500 rounded-full"
                    style={{ width: `${(fanBase.categories.fanatic / fanBase.total) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Fan Mood */}
      <Card>
        <Card.Header>
          <div className="flex items-center space-x-2">
            <Heart className="w-6 h-6 text-red-500" />
            <h2 className="text-xl font-bold">Humor da Torcida</h2>
          </div>
        </Card.Header>
        <Card.Body>
          <div className="text-center mb-6">
            <p className="text-gray-600 mb-2">Humor Geral</p>
            <p className={`text-2xl font-bold ${getMoodColor(mood.overall)}`}>
              {mood.overall.charAt(0).toUpperCase() + mood.overall.slice(1)}
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span>Dia de Jogo</span>
                <span>{mood.matchday}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-blue-500 rounded-full"
                  style={{ width: `${mood.matchday}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span>Temporada</span>
                <span>{mood.season}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${mood.season}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span>Gestão</span>
                <span>{mood.management}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${mood.management}%` }}
                />
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
}