import React from 'react';
import { Users } from 'lucide-react';
import { useFanStore } from '../../store/fanStore';
import { Card } from '../ui/card';
import { formatNumber } from '../../utils/formatters';

export function FanDemographics() {
  const { fanBase } = useFanStore();
  const { demographics = { young: 0, adult: 0, senior: 0 }, losses = { natural: 0, inactive: 0 } } = fanBase;

  const total = demographics.young + demographics.adult + demographics.senior;

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Users className="w-6 h-6 text-indigo-500" />
          <h2 className="text-xl font-bold">Demografia da Torcida</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-6">
          {/* Age Groups */}
          <div>
            <h3 className="font-semibold mb-4">Faixas Etárias</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Jovens (0-25)</span>
                  <span>{formatNumber(demographics.young)}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-green-500 rounded-full"
                    style={{ width: `${total > 0 ? (demographics.young / total) * 100 : 0}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Adultos (26-45)</span>
                  <span>{formatNumber(demographics.adult)}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${total > 0 ? (demographics.adult / total) * 100 : 0}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Seniores (46+)</span>
                  <span>{formatNumber(demographics.senior)}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-purple-500 rounded-full"
                    style={{ width: `${total > 0 ? (demographics.senior / total) * 100 : 0}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Losses Statistics */}
          <div className="pt-4 border-t">
            <h3 className="font-semibold mb-4">Estatísticas de Perdas</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Perdas Naturais</p>
                <p className="text-xl font-bold text-red-600">
                  {formatNumber(losses.natural)}
                </p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Torcedores Inativos</p>
                <p className="text-xl font-bold text-yellow-600">
                  {formatNumber(losses.inactive)}
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}