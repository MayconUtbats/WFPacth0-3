import React from 'react';
import { Flag, TrendingUp, Heart } from 'lucide-react';
import { useFanStore } from '../../store/fanStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';

export function FanActions() {
  const { addEvent, updateMood } = useFanStore();

  const handlePromotion = () => {
    addEvent({
      type: 'support',
      description: 'Campanha promocional para atrair novos torcedores',
      impact: 25
    });
    updateMood({ matchday: 60, management: 65 });
  };

  const handleFanEvent = () => {
    addEvent({
      type: 'celebration',
      description: 'Evento especial com torcedores organizado pelo clube',
      impact: 35
    });
    updateMood({ management: 70 });
  };

  const handleSocialMedia = () => {
    addEvent({
      type: 'support',
      description: 'Campanha nas redes sociais para engajamento dos torcedores',
      impact: 15
    });
    updateMood({ management: 55 });
  };

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center space-x-2">
          <Flag className="w-6 h-6 text-purple-500" />
          <h2 className="text-xl font-bold">Ações</h2>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <h3 className="font-semibold text-blue-900 mb-2">
              Campanha Promocional
            </h3>
            <p className="text-sm text-blue-700 mb-4">
              Lance uma campanha para atrair novos torcedores com descontos e benefícios especiais.
            </p>
            <Button
              onClick={handlePromotion}
              className="w-full"
              icon={<TrendingUp className="w-4 h-4" />}
            >
              Iniciar Campanha
            </Button>
          </div>

          <div className="p-4 bg-green-50 rounded-lg">
            <h3 className="font-semibold text-green-900 mb-2">
              Evento com Torcedores
            </h3>
            <p className="text-sm text-green-700 mb-4">
              Organize um evento especial para aproximar torcedores do clube.
            </p>
            <Button
              onClick={handleFanEvent}
              className="w-full"
              icon={<Heart className="w-4 h-4" />}
            >
              Organizar Evento
            </Button>
          </div>

          <div className="p-4 bg-purple-50 rounded-lg">
            <h3 className="font-semibold text-purple-900 mb-2">
              Redes Sociais
            </h3>
            <p className="text-sm text-purple-700 mb-4">
              Aumente o engajamento nas redes sociais com conteúdo exclusivo.
            </p>
            <Button
              onClick={handleSocialMedia}
              className="w-full"
              icon={<Flag className="w-4 h-4" />}
            >
              Criar Campanha
            </Button>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}