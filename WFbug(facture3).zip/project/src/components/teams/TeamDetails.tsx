import React from 'react';
import { Team } from '../../types/game';
import { Trophy, Users, Building2, DollarSign, Star } from 'lucide-react';
import { Card } from '../ui/card';
import { formatCurrency } from '../../utils/formatters';

interface TeamDetailsProps {
  team: Team;
}

export function TeamDetails({ team }: TeamDetailsProps) {
  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center space-x-6">
          <div className="w-24 h-24 relative">
            {/* Logo do Time */}
            <div 
              className="w-full h-full rounded-full"
              style={{
                backgroundColor: team.colors.primary,
                border: `4px solid ${team.colors.secondary}`
              }}
            />
          </div>

          <div>
            <h2 className="text-2xl font-bold text-gray-900">{team.name}</h2>
            <p className="text-gray-500">Fundado em {team.founded}</p>
          </div>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          icon={Users}
          title="Elenco"
          value={`${team.players.length} jogadores`}
          color="text-blue-600"
        />
        <StatCard
          icon={DollarSign}
          title="Orçamento"
          value={formatCurrency(team.budget)}
          color="text-green-600"
        />
        <StatCard
          icon={Trophy}
          title="Divisão"
          value={`${team.division}ª Divisão`}
          color="text-yellow-600"
        />
      </div>

      {/* Detalhes do Elenco */}
      <Card>
        <Card.Header>
          <h3 className="text-xl font-bold">Elenco</h3>
        </Card.Header>
        <Card.Body>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {team.players.map((player) => (
              <div 
                key={player.id}
                className="p-4 bg-gray-50 rounded-lg flex justify-between items-center"
              >
                <div>
                  <p className="font-medium">{player.name}</p>
                  <p className="text-sm text-gray-500">{player.position}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{player.rating}</p>
                  <p className="text-xs text-gray-500">Rating</p>
                </div>
              </div>
            ))}
          </div>
        </Card.Body>
      </Card>
    </div>
  );
}

function StatCard({ icon: Icon, title, value, color }: {
  icon: React.ElementType;
  title: string;
  value: string;
  color: string;
}) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center space-x-3">
        <Icon className={`w-6 h-6 ${color}`} />
        <div>
          <p className="text-sm text-gray-500">{title}</p>
          <p className="text-lg font-bold">{value}</p>
        </div>
      </div>
    </div>
  );
}