import React from 'react';
import { TeamCard } from './TeamCard';
import { useTeamStore } from '../../store/teamStore';

export function TeamList() {
  const { teams, selectTeam, selectedTeam } = useTeamStore();

  return (
    <div className="space-y-4">
      {teams.map((team) => (
        <TeamCard
          key={team.id}
          team={team}
          isSelected={selectedTeam?.id === team.id}
          onClick={() => selectTeam(team.id)}
        />
      ))}
    </div>
  );
}