import React from 'react';
import { Team } from '../../types/game';
import { Trophy, Users, Building2 } from 'lucide-react';
import { cn } from '../../utils/cn';

interface TeamCardProps {
  team: Team;
  isSelected: boolean;
  onClick: () => void;
}

export function TeamCard({ team, isSelected, onClick }: TeamCardProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full text-left p-4 rounded-lg transition-all duration-200',
        'hover:shadow-lg border',
        isSelected 
          ? 'bg-blue-50 border-blue-500 shadow-md' 
          : 'bg-white border-gray-200 hover:border-blue-300'
      )}
    >
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 relative">
          {/* Logo do Time */}
          <div 
            className="w-full h-full rounded-full"
            style={{
              backgroundColor: team.colors.primary,
              border: `2px solid ${team.colors.secondary}`
            }}
          />
        </div>

        <div>
          <h3 className="font-bold text-gray-900">{team.name}</h3>
          <p className="text-sm text-gray-500">
            {team.division}ª Divisão
          </p>
        </div>
      </div>
    </button>
  );
}