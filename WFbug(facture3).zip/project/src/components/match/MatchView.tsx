import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Users, Settings, TrendingUp, Activity } from 'lucide-react';
import { Team } from '../../types/game';
import { TacticalSetup } from '../../utils/simulation/tactics';

interface Props {
  homeTeam: Team;
  awayTeam: Team;
  onClose: () => void;
}

export function MatchView({ homeTeam, awayTeam, onClose }: Props) {
  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto">
      <div className="container mx-auto py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Left sidebar - Teams & Players */}
          <div className="col-span-3">
            <Card>
              <Card.Header>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <h3 className="font-bold">Escalações</h3>
                </div>
              </Card.Header>
              <Card.Body>
                <div className="space-y-4">
                  {/* Home Team */}
                  <div>
                    <h4 className="font-semibold mb-2">{homeTeam.name}</h4>
                    <div className="space-y-1">
                      {homeTeam.players.map(player => (
                        <div key={player.id} className="flex justify-between items-center p-2 bg-gray-50 rounded text-sm">
                          <span>{player.name}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-500">{player.position}</span>
                            <span className="text-yellow-600">{player.rating}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Away Team */}
                  <div>
                    <h4 className="font-semibold mb-2">{awayTeam.name}</h4>
                    <div className="space-y-1">
                      {awayTeam.players.map(player => (
                        <div key={player.id} className="flex justify-between items-center p-2 bg-gray-50 rounded text-sm">
                          <span>{player.name}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-500">{player.position}</span>
                            <span className="text-yellow-600">{player.rating}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </div>

          {/* Main content - Match Events */}
          <div className="col-span-6">
            <Card>
              <Card.Header>
                <div className="text-center">
                  <div className="text-2xl font-bold mb-2">
                    {homeTeam.name} vs {awayTeam.name}
                  </div>
                  <div className="text-4xl font-bold">
                    0 - 0
                  </div>
                  <div className="text-lg mt-2">0'</div>
                </div>
              </Card.Header>
              <Card.Body>
                <div className="space-y-4">
                  {/* Match Controls */}
                  <div className="flex justify-center space-x-4">
                    <Button variant="primary">Iniciar Partida</Button>
                    <Button variant="secondary">Táticas</Button>
                    <Button variant="default">Substituições</Button>
                  </div>

                  {/* Match Events */}
                  <div className="bg-gray-50 p-4 rounded-lg h-96 overflow-y-auto">
                    <div className="space-y-2">
                      {/* Events will be populated here */}
                    </div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </div>

          {/* Right sidebar - Stats & Tactics */}
          <div className="col-span-3">
            <Card>
              <Card.Header>
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <h3 className="font-bold">Estatísticas</h3>
                </div>
              </Card.Header>
              <Card.Body>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="text-right">0%</div>
                    <div className="text-center text-gray-600">Posse</div>
                    <div className="text-left">0%</div>

                    <div className="text-right">0</div>
                    <div className="text-center text-gray-600">Finalizações</div>
                    <div className="text-left">0</div>

                    <div className="text-right">0</div>
                    <div className="text-center text-gray-600">No Gol</div>
                    <div className="text-left">0</div>

                    <div className="text-right">0</div>
                    <div className="text-center text-gray-600">Passes</div>
                    <div className="text-left">0</div>
                  </div>
                </div>
              </Card.Body>
            </Card>

            <Card className="mt-4">
              <Card.Header>
                <div className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  <h3 className="font-bold">Táticas</h3>
                </div>
              </Card.Header>
              <Card.Body>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Formação</label>
                    <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                      <option>4-4-2</option>
                      <option>4-3-3</option>
                      <option>3-5-2</option>
                      <option>5-3-2</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Estilo de Jogo</label>
                    <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                      <option>Posse de Bola</option>
                      <option>Contra-Ataque</option>
                      <option>Pressão Alta</option>
                      <option>Defensivo</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mentalidade</label>
                    <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                      <option>Equilibrado</option>
                      <option>Ofensivo</option>
                      <option>Defensivo</option>
                      <option>Ultra Ofensivo</option>
                    </select>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}