import React, { useState } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Play } from 'lucide-react';
import { MatchSimulation } from './MatchSimulation';
import { generatePlayerName } from '../../utils/nameGenerator';
import { Team } from '../../types/game';

export function TestMatch() {
  const [showSimulation, setShowSimulation] = useState(false);

  // Create test teams
  const createTestTeam = (name: string, rating: number): Team => ({
    id: crypto.randomUUID(),
    name,
    shortName: name.substring(0, 3).toUpperCase(),
    country: 'BRA',
    league: 'Test League',
    division: 1,
    founded: 2024,
    colors: {
      primary: '#1a365d',
      secondary: '#ffffff',
      accent: '#e53e3e',
    },
    logo: {
      shape: 'shield',
      icon: 'star',
    },
    players: Array(11).fill(null).map((_, i) => ({
      id: `player-${i}`,
      name: generatePlayerName('BRA'),
      position: i === 0 ? 'GK' : i <= 4 ? 'DEF' : i <= 8 ? 'MID' : 'FWD',
      rating: rating + Math.floor(Math.random() * 10 - 5),
      stamina: 100,
      salary: 10000,
    })),
    budget: 1000000,
  });

  const homeTeam = createTestTeam('Time A', 75);
  const awayTeam = createTestTeam('Time B', 70);

  return (
    <>
      <Card>
        <Card.Header>
          <h2 className="text-2xl font-bold text-center">Simulação de Partida</h2>
        </Card.Header>

        <Card.Body>
          <div className="space-y-6">
            <div className="text-center">
              <div className="text-xl font-bold mb-4">
                {homeTeam.name} vs {awayTeam.name}
              </div>
              <Button
                variant="primary"
                onClick={() => setShowSimulation(true)}
                icon={<Play className="w-4 h-4" />}
              >
                Iniciar Partida
              </Button>
            </div>
          </div>
        </Card.Body>
      </Card>

      {showSimulation && (
        <MatchSimulation
          homeTeam={homeTeam}
          awayTeam={awayTeam}
          onClose={() => setShowSimulation(false)}
        />
      )}
    </>
  );
}