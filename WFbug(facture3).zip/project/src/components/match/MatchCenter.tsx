import React, { useState } from 'react';
import { useTranslation } from '../../hooks/useTranslation';
import { useGameStore } from '../../store/gameStore';
import { MatchSimulation } from './MatchSimulation';
import { MatchResultView } from './MatchResult';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Play, Calendar } from 'lucide-react';
import { formatDate } from '../../utils/formatters';

export function MatchCenter() {
  const { t } = useTranslation();
  const { currentTeam, matches, currentDate } = useGameStore();
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [matchResult, setMatchResult] = useState(null);

  const todayMatches = matches.filter(match => 
    formatDate(match.date) === formatDate(currentDate) &&
    !match.result &&
    (match.homeTeam.id === currentTeam?.id || match.awayTeam.id === currentTeam?.id)
  );

  const handlePlayMatch = (match) => {
    setSelectedMatch(match);
  };

  const handleMatchEnd = (result) => {
    setMatchResult(result);
    // Update match result in store
    // Update team stats, player stats, etc.
  };

  if (selectedMatch && !matchResult) {
    return (
      <MatchSimulation
        homeTeam={selectedMatch.homeTeam}
        awayTeam={selectedMatch.awayTeam}
        onMatchEnd={handleMatchEnd}
      />
    );
  }

  if (matchResult) {
    return (
      <MatchResultView
        result={matchResult}
        homeTeam={selectedMatch.homeTeam}
        awayTeam={selectedMatch.awayTeam}
      />
    );
  }

  return (
    <Card>
      <Card.Header>
        <h2 className="text-2xl font-bold">{t('match.center.title')}</h2>
      </Card.Header>
      <Card.Body>
        {todayMatches.length > 0 ? (
          <div className="space-y-4">
            {todayMatches.map(match => (
              <div key={match.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                    <span className="text-sm text-gray-500">
                      {formatDate(match.date)}
                    </span>
                  </div>
                  <span className="text-sm font-semibold text-blue-600">
                    {t(`competition.types.${match.competition}`)}
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="font-semibold">{match.homeTeam.name}</p>
                    <p className="font-semibold">{match.awayTeam.name}</p>
                  </div>
                  
                  <Button
                    variant="success"
                    onClick={() => handlePlayMatch(match)}
                    icon={<Play className="w-4 h-4" />}
                  >
                    {t('match.play')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">
            {t('match.center.noMatches')}
          </p>
        )}
      </Card.Body>
    </Card>
  );
}