import React, { useState, useEffect } from 'react';
import { X, Users, Settings, TrendingUp, Activity, Clock, RefreshCw, Play, Pause } from 'lucide-react';
import { Team, Player } from '../../types/game';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { TacticalSetup } from '../../utils/simulation/tactics';
import { SIMULATION_CONFIG } from '../../utils/simulation/config';
import { formatTime } from '../../utils/formatters';
import { MatchEventList } from './simulation/MatchEventList';
import { TeamLineup } from './simulation/TeamLineup';
import { TacticsPanel } from './simulation/TacticsPanel';
import { MatchStats } from './simulation/MatchStats';
import { useMatchSimulation } from '../../hooks/useMatchSimulation';

interface FullScreenMatchProps {
  homeTeam: Team;
  awayTeam: Team;
  onClose: () => void;
}

export function FullScreenMatch({ homeTeam, awayTeam, onClose }: FullScreenMatchProps) {
  const {
    matchState,
    isSimulating,
    isPaused,
    startMatch,
    pauseMatch,
    resumeMatch,
    updateTactics,
    makeSubstitution
  } = useMatchSimulation(homeTeam, awayTeam);

  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [showTactics, setShowTactics] = useState(false);

  const handleStartMatch = () => {
    startMatch();
  };

  const handlePauseResume = () => {
    if (isPaused) {
      resumeMatch();
    } else {
      pauseMatch();
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b p-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Clock className="w-5 h-5 text-blue-600" />
          <span className="text-xl font-bold">{formatTime(matchState.minute)}</span>
          {matchState.isHalfTime && <span className="text-gray-600">(Intervalo)</span>}
        </div>
        
        <div className="text-3xl font-bold flex items-center space-x-8">
          <div className="flex items-center space-x-3">
            <span className="text-gray-800">{homeTeam.name}</span>
            <span className="text-2xl text-blue-600">{matchState.homeScore}</span>
          </div>
          <span className="text-gray-400">-</span>
          <div className="flex items-center space-x-3">
            <span className="text-2xl text-blue-600">{matchState.awayScore}</span>
            <span className="text-gray-800">{awayTeam.name}</span>
          </div>
        </div>

        <Button variant="ghost" onClick={onClose} icon={<X className="w-5 h-5" />}>
          Fechar
        </Button>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-12 gap-4 p-4 h-[calc(100vh-80px)]">
        {/* Left Column - Teams */}
        <div className="col-span-3 space-y-4 overflow-auto">
          <TeamLineup
            team={homeTeam}
            isHome={true}
            onPlayerSelect={setSelectedPlayer}
            onSubstitution={(out, in_) => makeSubstitution('home', out.id, in_.id)}
          />
          <TeamLineup
            team={awayTeam}
            isHome={false}
            onPlayerSelect={setSelectedPlayer}
            onSubstitution={(out, in_) => makeSubstitution('away', out.id, in_.id)}
          />
        </div>

        {/* Center Column - Match Events */}
        <div className="col-span-6 flex flex-col">
          <Card className="flex-1 overflow-hidden">
            <Card.Header>
              <div className="flex justify-center space-x-4">
                {!isSimulating ? (
                  <Button
                    variant="primary"
                    onClick={handleStartMatch}
                    icon={<Play className="w-4 h-4" />}
                  >
                    Iniciar Partida
                  </Button>
                ) : (
                  <>
                    <Button
                      variant={isPaused ? "primary" : "secondary"}
                      onClick={handlePauseResume}
                      icon={isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                    >
                      {isPaused ? "Continuar" : "Pausar"}
                    </Button>
                    <Button
                      variant="default"
                      onClick={() => setShowTactics(true)}
                      icon={<Settings className="w-4 h-4" />}
                    >
                      Táticas
                    </Button>
                  </>
                )}
              </div>
            </Card.Header>

            <Card.Body className="overflow-auto bg-gray-50 h-full">
              <MatchEventList events={matchState.events} />
            </Card.Body>
          </Card>
        </div>

        {/* Right Column - Stats & Info */}
        <div className="col-span-3 space-y-4 overflow-auto">
          <MatchStats
            homeStats={matchState.homeStats}
            awayStats={matchState.awayStats}
            homeTeam={homeTeam}
            awayTeam={awayTeam}
          />
          
          {selectedPlayer && (
            <Card>
              <Card.Header>
                <h3 className="font-bold text-lg">{selectedPlayer.name}</h3>
              </Card.Header>
              <Card.Body>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Posição</span>
                    <span className="font-medium">{selectedPlayer.position}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Rating</span>
                    <span className="font-medium text-yellow-600">{selectedPlayer.rating}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Stamina</span>
                    <span className="font-medium text-green-600">{selectedPlayer.stamina}%</span>
                  </div>
                </div>
              </Card.Body>
            </Card>
          )}
        </div>
      </div>

      {/* Tactics Modal */}
      {showTactics && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">Táticas</h2>
              <Button
                variant="ghost"
                onClick={() => setShowTactics(false)}
                icon={<X className="w-5 h-5" />}
              />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold mb-4">{homeTeam.name}</h3>
                <TacticsPanel
                  currentTactics={{
                    formation: '4-4-2',
                    style: 'balanced',
                    pressing: 'medium',
                    mentality: 'balanced'
                  }}
                  onTacticsChange={(tactics) => updateTactics('home', tactics)}
                />
              </div>
              <div>
                <h3 className="font-bold mb-4">{awayTeam.name}</h3>
                <TacticsPanel
                  currentTactics={{
                    formation: '4-4-2',
                    style: 'balanced',
                    pressing: 'medium',
                    mentality: 'balanced'
                  }}
                  onTacticsChange={(tactics) => updateTactics('away', tactics)}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Half Time Modal */}
      {matchState.isHalfTime && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <Card className="w-96">
            <Card.Header>
              <h2 className="text-xl font-bold text-center">Intervalo</h2>
            </Card.Header>
            <Card.Body>
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">
                    {matchState.homeScore} - {matchState.awayScore}
                  </div>
                  <p className="text-gray-600">
                    Aproveite para fazer alterações táticas e substituições
                  </p>
                </div>
                <div className="flex justify-center">
                  <Button
                    variant="primary"
                    onClick={resumeMatch}
                    icon={<RefreshCw className="w-4 h-4" />}
                  >
                    Iniciar Segundo Tempo
                  </Button>
                </div>
              </div>
            </Card.Body>
          </Card>
        </div>
      )}
    </div>
  );
}