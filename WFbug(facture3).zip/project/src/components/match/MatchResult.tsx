import React from 'react';
import { useTranslation } from '../../hooks/useTranslation';
import { MatchResult, TeamMatchStats } from '../../utils/simulation/types';
import { Card } from '../ui/card';
import { Team } from '../../types/game';

interface MatchResultProps {
  result: MatchResult;
  homeTeam: Team;
  awayTeam: Team;
}

export function MatchResultView({ result, homeTeam, awayTeam }: MatchResultProps) {
  const { t } = useTranslation();

  const StatRow = ({ label, home, away }: { label: string; home: number; away: number }) => (
    <div className="grid grid-cols-3 gap-4 py-2 border-b last:border-0">
      <div className="text-right">{home}</div>
      <div className="text-center text-gray-600">{label}</div>
      <div className="text-left">{away}</div>
    </div>
  );

  return (
    <Card>
      <Card.Header>
        <div className="text-center">
          <div className="text-2xl font-bold mb-2">
            {homeTeam.name} {result.homeScore} - {result.awayScore} {awayTeam.name}
          </div>
          {result.extraTime && (
            <div className="text-gray-600">
              (AET: {result.extraTime.homeScore} - {result.extraTime.awayScore})
            </div>
          )}
          {result.penalties && (
            <div className="text-gray-600">
              (Penalties: {result.penalties.homeScore} - {result.penalties.awayScore})
            </div>
          )}
        </div>
      </Card.Header>

      <Card.Body>
        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium mb-4 text-center">{t('match.stats.title')}</h3>
            <StatRow
              label={t('match.stats.possession')}
              home={Math.round(result.stats.home.possession)}
              away={Math.round(result.stats.away.possession)}
            />
            <StatRow
              label={t('match.stats.shots')}
              home={result.stats.home.shots}
              away={result.stats.away.shots}
            />
            <StatRow
              label={t('match.stats.shotsOnTarget')}
              home={result.stats.home.shotsOnTarget}
              away={result.stats.away.shotsOnTarget}
            />
            <StatRow
              label={t('match.stats.passes')}
              home={result.stats.home.passes}
              away={result.stats.away.passes}
            />
            <StatRow
              label={t('match.stats.corners')}
              home={result.stats.home.corners}
              away={result.stats.away.corners}
            />
            <StatRow
              label={t('match.stats.fouls')}
              home={result.stats.home.fouls}
              away={result.stats.away.fouls}
            />
          </div>

          <div className="space-y-4">
            <h3 className="font-medium text-center">{t('match.events.title')}</h3>
            {result.events.map((event, index) => (
              <div
                key={index}
                className={`p-2 ${
                  event.type === 'goal'
                    ? 'bg-green-50 text-green-700'
                    : event.type === 'card'
                    ? 'bg-yellow-50 text-yellow-700'
                    : 'bg-gray-50 text-gray-700'
                } rounded-lg`}
              >
                <span className="font-bold">{event.minute}'</span> - {event.description}
              </div>
            ))}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}