import React from 'react';
import { MatchEvent } from '../../../types/match';

interface Props {
  events: MatchEvent[];
}

export function MatchEvents({ events }: Props) {
  return (
    <div className="bg-gray-50 p-4 rounded-lg h-96 overflow-y-auto">
      <div className="space-y-2">
        {events.map((event, index) => (
          <div
            key={index}
            className={`p-2 ${
              event.type === 'goal'
                ? 'bg-green-50 text-green-700'
                : event.type === 'card'
                ? 'bg-yellow-50 text-yellow-700'
                : event.type === 'chance'
                ? 'bg-blue-50 text-blue-700'
                : 'bg-gray-100 text-gray-700'
            } rounded-lg`}
          >
            <span className="font-bold">{event.minute}'</span> - {event.description}
          </div>
        ))}
      </div>
    </div>
  );
}