import React from 'react';
import { cn } from '../../../utils/cn';

interface StatBarProps {
  leftValue: number;
  rightValue: number;
  leftColor?: string;
  rightColor?: string;
  height?: string;
}

export function StatBar({
  leftValue,
  rightValue,
  leftColor = 'bg-blue-500',
  rightColor = 'bg-red-500',
  height = 'h-2'
}: StatBarProps) {
  const total = leftValue + rightValue;
  const leftPercentage = total > 0 ? (leftValue / total) * 100 : 50;

  return (
    <div className={cn('w-full bg-gray-800 rounded-full overflow-hidden', height)}>
      <div
        className={cn('h-full transition-all duration-500', leftColor)}
        style={{ width: `${leftPercentage}%` }}
      />
    </div>
  );
}