import React from 'react';
import { MatchEvent } from '../../../types/match';
import { cn } from '../../../utils/cn';
import { formatMatchTime } from '../../../utils/formatters';

interface EventItemProps {
  event: MatchEvent;
  isLatest: boolean;
}

export function EventItem({ event, isLatest }: EventItemProps) {
  const getEventStyle = (type: string): string => {
    switch (type) {
      case 'goal':
        return 'bg-green-900/50 text-green-300 border-green-700';
      case 'chance':
        return 'bg-blue-900/50 text-blue-300 border-blue-700';
      case 'card':
        return 'bg-yellow-900/50 text-yellow-300 border-yellow-700';
      case 'injury':
        return 'bg-red-900/50 text-red-300 border-red-700';
      case 'substitution':
        return 'bg-purple-900/50 text-purple-300 border-purple-700';
      case 'buildup':
      case 'transition':
      case 'general':
        return 'bg-gray-800/50 text-gray-300 border-gray-700';
      default:
        return 'bg-gray-800/50 text-gray-300 border-gray-700';
    }
  };

  return (
    <div 
      className={cn(
        'p-3 rounded-lg text-sm transition-all duration-500 border',
        getEventStyle(event.type),
        isLatest && 'animate-slide-in-bottom'
      )}
    >
      <div className="flex items-start space-x-2">
        <span className="font-bold text-gray-400 min-w-[30px]">
          {formatMatchTime(event.minute)}
        </span>
        <div className="flex-1">
          <p className="leading-relaxed">{event.description}</p>
          {event.type === 'goal' && event.assistPlayer && (
            <div className="mt-1 text-xs text-gray-400">
              ⚽ {event.player.name} (Assist: {event.assistPlayer.name})
            </div>
          )}
        </div>
      </div>
    </div>
  );
}