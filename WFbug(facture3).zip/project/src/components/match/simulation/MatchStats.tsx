import React from 'react';
import { TeamMatchStats } from '../../../types/match';
import { Team } from '../../../types/game';
import { Card } from '../../ui/card';
import { Activity } from 'lucide-react';
import { StatRow } from './StatRow';

interface MatchStatsProps {
  homeStats: TeamMatchStats;
  awayStats: TeamMatchStats;
  homeTeam?: Team;
  awayTeam?: Team;
}

export function MatchStats({ 
  homeStats, 
  awayStats, 
  homeTeam, 
  awayTeam 
}: MatchStatsProps) {
  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <Card.Header className="border-gray-700">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-blue-400" />
          <h3 className="font-bold text-white">Estatísticas</h3>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-right font-bold text-sm text-white">{homeTeam?.name || 'Time Casa'}</div>
            <div className="text-center text-gray-400 text-sm">Time</div>
            <div className="text-left font-bold text-sm text-white">{awayTeam?.name || 'Time Visitante'}</div>
          </div>

          <StatRow
            label="Posse de Bola"
            home={Math.round(homeStats.possession)}
            away={Math.round(awayStats.possession)}
            type="percentage"
          />
          <StatRow
            label="Finalizações"
            home={homeStats.shots}
            away={awayStats.shots}
          />
          <StatRow
            label="No Gol"
            home={homeStats.shotsOnTarget}
            away={awayStats.shotsOnTarget}
          />
          <StatRow
            label="Passes"
            home={homeStats.passes}
            away={awayStats.passes}
          />
          <StatRow
            label="Precisão"
            home={Math.round(homeStats.passAccuracy)}
            away={Math.round(awayStats.passAccuracy)}
            type="percentage"
          />
          <StatRow
            label="Faltas"
            home={homeStats.fouls}
            away={awayStats.fouls}
          />
          <StatRow
            label="Cartões Amarelos"
            home={homeStats.yellowCards}
            away={awayStats.yellowCards}
          />
          <StatRow
            label="Cartões Vermelhos"
            home={homeStats.redCards}
            away={awayStats.redCards}
          />
          <StatRow
            label="Escanteios"
            home={homeStats.corners}
            away={awayStats.corners}
          />
          <StatRow
            label="Impedimentos"
            home={homeStats.offsides}
            away={awayStats.offsides}
          />
        </div>
      </Card.Body>
    </Card>
  );
}