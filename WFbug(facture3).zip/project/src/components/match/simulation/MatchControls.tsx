import React from 'react';
import { Button } from '../../ui/button';
import { Play, Pause, Settings, Users } from 'lucide-react';

interface Props {
  isSimulating: boolean;
  isPaused: boolean;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
}

export function MatchControls({
  isSimulating,
  isPaused,
  onStart,
  onPause,
  onResume
}: Props) {
  return (
    <div className="flex justify-center space-x-4">
      {!isSimulating ? (
        <Button
          variant="primary"
          onClick={onStart}
          icon={<Play className="w-4 h-4" />}
        >
          Iniciar Partida
        </Button>
      ) : (
        <>
          <Button
            variant={isPaused ? "primary" : "secondary"}
            onClick={isPaused ? onResume : onPause}
            icon={isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          >
            {isPaused ? "Continuar" : "Pausar"}
          </Button>
          <Button
            variant="default"
            icon={<Settings className="w-4 h-4" />}
          >
            Táticas
          </Button>
          <Button
            variant="default"
            icon={<Users className="w-4 h-4" />}
          >
            Substituições
          </Button>
        </>
      )}
    </div>
  );
}