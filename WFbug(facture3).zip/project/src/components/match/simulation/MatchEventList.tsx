import React, { useEffect, useRef } from 'react';
import { MatchEvent } from '../../../types/match';
import { EventItem } from './EventItem';

interface MatchEventListProps {
  events: MatchEvent[];
}

export function MatchEventList({ events }: MatchEventListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollElement = scrollRef.current;
      scrollElement.scrollTo({
        top: scrollElement.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [events]);

  return (
    <div 
      ref={scrollRef} 
      className="space-y-2 p-4 h-[calc(100vh-300px)] md:h-[calc(100vh-200px)] overflow-y-auto scroll-smooth"
    >
      {events.map((event, index) => (
        <EventItem 
          key={`${event.minute}-${index}`} 
          event={event} 
          isLatest={index === events.length - 1}
        />
      ))}
    </div>
  );
}