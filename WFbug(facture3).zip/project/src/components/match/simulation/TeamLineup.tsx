import React from 'react';
import { Card } from '../../ui/card';
import { Button } from '../../ui/button';
import { Users, ArrowDownUp } from 'lucide-react';
import { Team, Player } from '../../../types/game';

interface TeamLineupProps {
  team: Team;
  isHome: boolean;
  onPlayerSelect?: (player: Player) => void;
  onSubstitution?: (playerOut: Player, playerIn: Player) => void;
}

export function TeamLineup({ team, isHome, onPlayerSelect, onSubstitution }: TeamLineupProps) {
  const [showSubs, setShowSubs] = useState(false);
  const starters = team.players.slice(0, 11);
  const substitutes = team.players.slice(11);

  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold">{team.name}</h3>
          </div>
          {onSubstitution && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSubs(!showSubs)}
              icon={<ArrowDownUp className="w-4 h-4" />}
            >
              Substituições
            </Button>
          )}
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-4">
          <div className="space-y-1">
            <h4 className="text-sm font-medium text-gray-600 mb-2">Titulares</h4>
            {starters.map(player => (
              <PlayerCard
                key={player.id}
                player={player}
                onClick={() => onPlayerSelect?.(player)}
                showSubOption={showSubs}
                onSubstitute={
                  onSubstitution && showSubs
                    ? () => setSelectedPlayer(player)
                    : undefined
                }
              />
            ))}
          </div>

          {substitutes.length > 0 && (
            <div className="space-y-1">
              <h4 className="text-sm font-medium text-gray-600 mb-2">Reservas</h4>
              {substitutes.map(player => (
                <PlayerCard
                  key={player.id}
                  player={player}
                  onClick={() => onPlayerSelect?.(player)}
                  showSubOption={showSubs}
                  onSubstitute={
                    onSubstitution && showSubs
                      ? () => handleSubstitution(player)
                      : undefined
                  }
                />
              ))}
            </div>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}

interface PlayerCardProps {
  player: Player;
  onClick?: () => void;
  showSubOption?: boolean;
  onSubstitute?: () => void;
}

function PlayerCard({ player, onClick, showSubOption, onSubstitute }: PlayerCardProps) {
  return (
    <div
      className={`flex justify-between items-center p-2 bg-gray-50 rounded hover:bg-gray-100 ${
        onClick ? 'cursor-pointer' : ''
      }`}
      onClick={onClick}
    >
      <div>
        <span className="font-medium">{player.name}</span>
        <span className="text-sm text-gray-500 ml-2">{player.position}</span>
      </div>
      <div className="flex items-center space-x-2">
        <div className="text-sm">
          <span className="text-yellow-600">{player.rating}</span>
          <span className="text-gray-400 mx-1">|</span>
          <span className="text-green-600">{player.stamina}%</span>
        </div>
        {showSubOption && onSubstitute && (
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onSubstitute();
            }}
            icon={<ArrowDownUp className="w-4 h-4" />}
          />
        )}
      </div>
    </div>
  );
}