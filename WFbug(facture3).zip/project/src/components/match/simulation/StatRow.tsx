import React from 'react';

interface StatRowProps {
  label: string;
  home: number;
  away: number;
  type?: 'number' | 'percentage';
}

export function StatRow({ label, home, away, type = 'number' }: StatRowProps) {
  return (
    <div className="grid grid-cols-3 gap-4 py-2 border-b border-gray-700 last:border-0">
      <div className="text-right font-medium text-white">
        {type === 'percentage' ? `${home}%` : home}
      </div>
      <div className="text-center text-gray-400">{label}</div>
      <div className="text-left font-medium text-white">
        {type === 'percentage' ? `${away}%` : away}
      </div>
    </div>
  );
}