import React from 'react';
import { Card } from '../../ui/card';
import { Button } from '../../ui/button';
import { Settings } from 'lucide-react';
import { TacticalSetup } from '../../../utils/simulation/tactics';

interface TacticsPanelProps {
  currentTactics: TacticalSetup;
  onTacticsChange: (newTactics: TacticalSetup) => void;
  isDisabled?: boolean;
}

export function TacticsPanel({ currentTactics, onTacticsChange, isDisabled }: TacticsPanelProps) {
  return (
    <Card>
      <Card.Header>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold">Táticas</h3>
          </div>
        </div>
      </Card.Header>
      <Card.Body>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Formação
            </label>
            <select
              value={currentTactics.formation}
              onChange={(e) => onTacticsChange({ ...currentTactics, formation: e.target.value })}
              disabled={isDisabled}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="4-4-2">4-4-2</option>
              <option value="4-3-3">4-3-3</option>
              <option value="3-5-2">3-5-2</option>
              <option value="4-2-3-1">4-2-3-1</option>
              <option value="5-3-2">5-3-2</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Estilo de Jogo
            </label>
            <select
              value={currentTactics.style}
              onChange={(e) => onTacticsChange({ ...currentTactics, style: e.target.value as any })}
              disabled={isDisabled}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="possession">Posse de Bola</option>
              <option value="counter">Contra-Ataque</option>
              <option value="direct">Jogo Direto</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Pressão
            </label>
            <select
              value={currentTactics.pressing}
              onChange={(e) => onTacticsChange({ ...currentTactics, pressing: e.target.value as any })}
              disabled={isDisabled}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="high">Alta</option>
              <option value="medium">Média</option>
              <option value="low">Baixa</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Mentalidade
            </label>
            <select
              value={currentTactics.mentality}
              onChange={(e) => onTacticsChange({ ...currentTactics, mentality: e.target.value as any })}
              disabled={isDisabled}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="attacking">Ofensiva</option>
              <option value="balanced">Equilibrada</option>
              <option value="defensive">Defensiva</option>
            </select>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}