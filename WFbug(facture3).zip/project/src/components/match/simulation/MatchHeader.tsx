import React from 'react';
import { Card } from '../../ui/card';
import { Team } from '../../../types/game';
import { MatchState } from '../../../types/match';
import { formatMatchTime } from '../../../utils/formatters';

interface Props {
  homeTeam: Team;
  awayTeam: Team;
  matchState: MatchState;
}

export function MatchHeader({ homeTeam, awayTeam, matchState }: Props) {
  return (
    <Card.Header>
      <div className="text-center">
        <div className="text-2xl font-bold mb-2">
          {homeTeam.name} vs {awayTeam.name}
        </div>
        <div className="text-4xl font-bold">
          {matchState.homeScore} - {matchState.awayScore}
        </div>
        <div className="text-lg mt-2">
          {formatMatchTime(matchState.minute)}
          {matchState.isHalfTime && ' (Intervalo)'}
        </div>
      </div>
    </Card.Header>
  );
}