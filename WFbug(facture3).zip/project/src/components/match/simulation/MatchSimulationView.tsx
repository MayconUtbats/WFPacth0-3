import React from 'react';
import { Card } from '../../ui/card';
import { MatchHeader } from './MatchHeader';
import { MatchControls } from './MatchControls';
import { MatchEventList } from './MatchEventList';
import { TeamLineup } from './TeamLineup';
import { MatchStats } from './MatchStats';
import { TacticsPanel } from './TacticsPanel';
import { Team } from '../../../types/game';
import { useMatchSimulation } from '../../../hooks/useMatchSimulation';

interface Props {
  homeTeam: Team;
  awayTeam: Team;
  onClose: () => void;
}

export function MatchSimulationView({ homeTeam, awayTeam, onClose }: Props) {
  const {
    matchState,
    isSimulating,
    isPaused,
    startMatch,
    pauseMatch,
    resumeMatch,
    updateTactics,
    makeSubstitution
  } = useMatchSimulation(homeTeam, awayTeam);

  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto">
      <div className="container mx-auto py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Left Column - Teams */}
          <div className="col-span-3">
            <TeamLineup
              homeTeam={homeTeam}
              awayTeam={awayTeam}
              onSubstitution={makeSubstitution}
              isSimulating={isSimulating}
            />
          </div>

          {/* Center Column - Match */}
          <div className="col-span-6">
            <Card>
              <MatchHeader
                homeTeam={homeTeam}
                awayTeam={awayTeam}
                matchState={matchState}
              />
              <Card.Body>
                <div className="space-y-4">
                  <MatchControls
                    isSimulating={isSimulating}
                    isPaused={isPaused}
                    onStart={startMatch}
                    onPause={pauseMatch}
                    onResume={resumeMatch}
                  />
                  <MatchEventList events={matchState.events} />
                </div>
              </Card.Body>
            </Card>
          </div>

          {/* Right Column - Stats & Tactics */}
          <div className="col-span-3 space-y-6">
            <MatchStats
              homeStats={matchState.homeStats}
              awayStats={matchState.awayStats}
            />
            <TacticsPanel
              homeTeam={homeTeam}
              awayTeam={awayTeam}
              onTacticsChange={updateTactics}
              isSimulating={isSimulating}
            />
          </div>
        </div>
      </div>
    </div>
  );
}