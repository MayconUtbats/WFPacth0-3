```tsx
import React from 'react';
import { Match } from '../../types/match';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Play, Calendar, Trophy } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface MatchCardProps {
  match: Match;
  onPlay: () => void;
}

export function MatchCard({ match, onPlay }: MatchCardProps) {
  const { currentTeam } = useGameStore();
  const isPlaying = match.homeTeam === currentTeam?.id || match.awayTeam === currentTeam?.id;

  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <Card.Body>
        <div className="space-y-4">
          {/* Header */}
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-500">
                {format(match.date, "d 'de' MMMM", { locale: ptBR })}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Trophy className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-medium text-gray-600">
                {match.competition}
              </span>
            </div>
          </div>

          {/* Teams */}
          <div className="flex justify-between items-center">
            <div className="text-center flex-1">
              <p className="font-semibold">{match.homeTeam}</p>
              {match.result && (
                <p className="text-2xl font-bold">{match.result.homeScore}</p>
              )}
            </div>
            <div className="px-4">
              <span className="text-gray-400">vs</span>
            </div>
            <div className="text-center flex-1">
              <p className="font-semibold">{match.awayTeam}</p>
              {match.result && (
                <p className="text-2xl font-bold">{match.result.awayScore}</p>
              )}
            </div>
          </div>

          {/* Actions */}
          {isPlaying && !match.isPlayed && (
            <div className="flex justify-center">
              <Button
                variant="primary"
                onClick={onPlay}
                icon={<Play className="w-4 h-4" />}
              >
                Jogar Partida
              </Button>
            </div>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}
```