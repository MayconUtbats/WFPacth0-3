```tsx
import React, { useState, useEffect } from 'react';
import { Match, MatchEvent } from '../../types/match';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Play, Pause, Clock, X } from 'lucide-react';
import { formatMatchTime } from '../../utils/formatters';
import { useMatchStore } from '../../store/matchStore';

interface MatchSimulationProps {
  matchId: string;
  onClose: () => void;
}

export function MatchSimulation({ matchId, onClose }: MatchSimulationProps) {
  const { getMatchDetails, playMatch } = useMatchStore();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentMinute, setCurrentMinute] = useState(0);
  const [events, setEvents] = useState<MatchEvent[]>([]);

  const match = getMatchDetails(matchId);
  if (!match) return null;

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isPlaying && !isPaused) {
      interval = setInterval(() => {
        setCurrentMinute(prev => {
          if (prev >= 90) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isPlaying, isPaused]);

  const handleStart = () => {
    setIsPlaying(true);
    playMatch(matchId);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  return (
    <div className="fixed inset-0 bg-gray-900/95 z-50 text-white">
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <Clock className="w-6 h-6 text-blue-400" />
            <span className="text-2xl font-bold">
              {formatMatchTime(currentMinute)}
            </span>
          </div>
          <Button variant="ghost" onClick={onClose} icon={<X className="w-5 h-5" />}>
            Fechar
          </Button>
        </div>

        {/* Match Info */}
        <Card className="bg-gray-800 border-gray-700">
          <Card.Body>
            <div className="text-center mb-6">
              <div className="text-3xl font-bold mb-2">
                {match.homeTeam} vs {match.awayTeam}
              </div>
              {match.result && (
                <div className="text-4xl font-bold text-blue-400">
                  {match.result.homeScore} - {match.result.awayScore}
                </div>
              )}
            </div>

            <div className="flex justify-center space-x-4 mb-6">
              {!isPlaying ? (
                <Button
                  variant="primary"
                  onClick={handleStart}
                  icon={<Play className="w-4 h-4" />}
                >
                  Iniciar Partida
                </Button>
              ) : (
                <Button
                  variant={isPaused ? "primary" : "secondary"}
                  onClick={handlePause}
                  icon={isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                >
                  {isPaused ? "Continuar" : "Pausar"}
                </Button>
              )}
            </div>

            {/* Match Events */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {events.map((event, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg ${
                    event.type === 'goal'
                      ? 'bg-green-900/50 text-green-300'
                      : event.type === 'card'
                      ? 'bg-yellow-900/50 text-yellow-300'
                      : 'bg-gray-800/50 text-gray-300'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    <span className="font-bold text-gray-400">
                      {event.minute}'
                    </span>
                    <p>{event.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}
```