```typescript
import { addDays, startOfMonth, endOfMonth } from 'date-fns';

export const SEASON_CONFIG = {
  SEASON_START_MONTH: 8, // August
  SEASON_END_MONTH: 5, // May
  MATCHES_PER_MONTH: 30,
  DAYS_PER_MONTH: 30,
  
  COMPETITIONS: {
    LEAGUE: {
      startDay: 1,
      matchesPerTeam: 30,
      matchesPerDay: 1,
    },
    CONTINENTAL: {
      startDay: 15, // Mid-month for continental matches
      matchesPerRound: 2, // Home and away legs
      daysPerRound: 14, // Two weeks between rounds
    },
  },

  MATCH_TIMES: {
    AFTERNOON: '16:00',
    EVENING: '20:00',
  },
};

export function generateMonthlySchedule(date: Date) {
  const monthStart = startOfMonth(date);
  const monthEnd = endOfMonth(date);
  const schedule = [];

  let currentDate = monthStart;
  while (currentDate <= monthEnd) {
    schedule.push({
      date: currentDate,
      competitions: [],
    });
    currentDate = addDays(currentDate, 1);
  }

  return schedule;
}
```