// Constantes de texto em português para todo o aplicativo
export const TEXT = {
  auth: {
    email: 'E-mail',
    password: 'Senha',
    confirmPassword: 'Confirmar Senha',
    login: 'Entrar',
    register: 'Cadastrar',
    forgotPassword: 'Esqueceu a senha?',
    rememberMe: 'Lembrar-me',
    dontHaveAccount: 'Não tem uma conta?',
    alreadyHaveAccount: 'Já tem uma conta?',
    signUp: 'Cadastre-se',
    signIn: 'Entre',
    privacyPolicy: 'Política de Privacidade',
    termsOfService: 'Termos de Serviço',
    support: 'Suporte'
  },
  
  menu: {
    overview: 'Visão Geral',
    squad: 'Elenco',
    stadium: 'Estádio',
    youthAcademy: 'Base',
    fans: 'Torcida',
    finances: 'Finanças',
    freeAgents: 'Jogadores Livres',
    division: 'Divisão',
    transfers: 'Transferências',
    competitions: 'Competições'
  },

  academy: {
    title: 'Academia de Base',
    description: 'Gerencie os jovens talentos do seu clube',
    level: 'Nível',
    upgrade: 'Melhorar',
    players: 'Jogadores',
    monthlyCost: 'Custo Mensal',
    nextGraduation: 'Próxima Formatura',
    youthPlayers: 'Jogadores da Base',
    recruitPlayer: 'Recrutar Jogador',
    noPlayers: 'Nenhum jogador na base ainda',
    promote: 'Promover',
    dismiss: 'Dispensar',
    
    facilities: {
      title: 'Instalações',
      training: 'Centro de Treinamento',
      scouting: 'Departamento de Observação',
      education: 'Centro Educacional',
      medical: 'Departamento Médico'
    }
  },

  finances: {
    title: 'Finanças',
    description: 'Gestão financeira do clube',
    balance: 'Saldo',
    income: 'Receitas',
    expenses: 'Despesas',
    monthlyIncome: 'Receita Mensal',
    monthlyExpenses: 'Despesas Mensais',
    monthlyBalance: 'Saldo Mensal',
    transactions: 'Transações'
  },

  common: {
    save: 'Salvar',
    cancel: 'Cancelar',
    confirm: 'Confirmar',
    delete: 'Excluir',
    edit: 'Editar',
    back: 'Voltar',
    next: 'Próximo',
    previous: 'Anterior',
    loading: 'Carregando...'
  }
};