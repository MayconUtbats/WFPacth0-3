```typescript
export const STADIUM_CONFIG = {
  INITIAL_CAPACITY: 5000,
  MAX_CAPACITY: 100000,
  EXPANSION_STEP: 5000,
  
  COSTS: {
    BASE_EXPANSION: 100,
    MAINTENANCE_PER_SEAT: 2,
    FACILITY_UPGRADE: {
      parking: 100000,
      shops: 150000,
      food: 120000,
      vip: 200000,
      screens: 180000,
      wifi: 90000,
      accessibility: 130000,
    },
  },
  
  MAINTENANCE: {
    MAX_LEVEL: 100,
    TYPES: {
      routine: { cost: 50000, improvement: 20 },
      major: { cost: 200000, improvement: 50 },
      emergency: { cost: 100000, improvement: 30 },
    },
  },
  
  FACILITY_MAX_LEVEL: 5,
};

export const FACILITY_DESCRIPTIONS = {
  parking: 'Estacionamento para torcedores',
  shops: 'Lojas oficiais do clube',
  food: 'Praça de alimentação',
  vip: 'Áreas VIP e camarotes',
  screens: 'Telões e placares eletrônicos',
  wifi: 'Internet para os torcedores',
  accessibility: 'Acessibilidade e mobilidade',
};
```