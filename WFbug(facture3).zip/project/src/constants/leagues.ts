```typescript
export const LEAGUE_CONFIG = {
  TEAMS_PER_LEAGUE: 16,
  MATCHES_PER_TEAM: 30,
  MATCHES_PER_DAY: 1,
  RELEGATION_SPOTS: 4,
  CONTINENTAL_SPOTS: 7,

  COUNTRIES: {
    BRA: {
      name: 'Brasil',
      divisions: ['Série A', 'Série B', 'Série C'],
      continentalCompetition: 'libertadores',
      teams: 16,
    },
    ARG: {
      name: 'Argentina',
      divisions: ['Primera División', 'Primera B Nacional', 'Primera B'],
      continentalCompetition: 'libertadores',
      teams: 16,
    },
    ENG: {
      name: 'Inglaterra',
      divisions: ['Premier League', 'Championship', 'League One'],
      continentalCompetition: 'champions',
      teams: 16,
    },
    ESP: {
      name: 'Espanha',
      divisions: ['La Liga', 'Segunda División', 'Segunda B'],
      continentalCompetition: 'champions',
      teams: 16,
    },
  },

  CONTINENTAL: {
    libertadores: {
      name: 'Copa Libertadores',
      spots: 7,
      teams: 32,
      groups: 8,
      teamsPerGroup: 4,
      knockoutRounds: ['round_of_16', 'quarter', 'semi', 'final'],
    },
    champions: {
      name: 'Champions League',
      spots: 7,
      teams: 32,
      groups: 8,
      teamsPerGroup: 4,
      knockoutRounds: ['round_of_16', 'quarter', 'semi', 'final'],
    },
  },

  POINTS: {
    WIN: 3,
    DRAW: 1,
    LOSS: 0,
  },
};
```