```typescript
export const ACADEMY_CONFIG = {
  BASE_SALARY: 1000,
  MIN_AGE: 15,
  MAX_AGE: 19,
  BASE_ABILITY: 40,
  MAX_ABILITY: 60,
  MIN_POTENTIAL: 60,
  MAX_POTENTIAL: 99,
  TRAINING_INTERVAL: 7, // days
  MAX_PLAYERS: 10,
  GRADUATION_TIME: 90, // days
  FACILITY_MAX_LEVEL: 5,
  
  COSTS: {
    MONTHLY_BASE: 50000,
    UPGRADE_BASE: 1000000,
    FACILITY_UPGRADE: 500000,
  },
  
  DEVELOPMENT: {
    BASE_PROGRESS: 5,
    TRAINING_BONUS: 2,
    AGE_MODIFIER: 1.2,
  },
};

export const FACILITY_DESCRIPTIONS = {
  training: 'Centro de treinamento para desenvolvimento técnico',
  scouting: 'Departamento de observação para encontrar talentos',
  education: 'Centro educacional para desenvolvimento mental',
  medical: 'Departamento médico para cuidar da saúde dos atletas',
};
```