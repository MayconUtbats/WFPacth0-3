import React from 'react';
import { useTransferStore } from '../store/transferStore';
import { FreeAgentsMarket } from '../components/transfers/FreeAgentsMarket';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';

export function FreeAgentsPage() {
  const navigate = useNavigate();
  const { freeAgents } = useTransferStore();

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate(-1)}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Jogadores Livres</h1>
                <p className="text-sm text-gray-500">
                  {freeAgents?.length || 0} jogadores disponíveis para contratação
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Free Agents Market */}
          <FreeAgentsMarket />
        </div>
      </div>
    </div>
  );
}