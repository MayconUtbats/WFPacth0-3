import React from 'react';
import { Users, Heart, TrendingUp, MessageCircle, Flag } from 'lucide-react';
import { FanOverview } from '../components/fans/FanOverview';
import { FanEvents } from '../components/fans/FanEvents';
import { FanGrowthChart } from '../components/fans/FanGrowthChart';
import { FanActions } from '../components/fans/FanActions';
import { FanDemographics } from '../components/fans/FanDemographics';
import { Button } from '../components/ui/button';
import { useNavigate } from 'react-router-dom';

export function FansPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate(-1)}
                className="text-gray-600 hover:text-gray-900"
              >
                Voltar
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Torcida</h1>
                <p className="text-sm text-gray-500">
                  Gerencie sua base de torcedores e acompanhe seu crescimento
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            <FanOverview />
            <FanDemographics />
            <FanGrowthChart />
            <FanEvents />
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            <FanActions />
          </div>
        </div>
      </div>
    </div>
  );
}