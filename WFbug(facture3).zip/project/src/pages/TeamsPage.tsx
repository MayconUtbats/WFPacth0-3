import React from 'react';
import { TeamList } from '../components/teams/TeamList';
import { TeamDetails } from '../components/teams/TeamDetails';
import { useTeamStore } from '../store/teamStore';

export function TeamsPage() {
  const { selectedTeam } = useTeamStore();

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Times</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Lista de times à esquerda */}
          <div className="lg:col-span-1">
            <TeamList />
          </div>

          {/* Detalhes do time selecionado à direita */}
          <div className="lg:col-span-2">
            {selectedTeam ? (
              <TeamDetails team={selectedTeam} />
            ) : (
              <div className="bg-white rounded-lg shadow p-6 text-center text-gray-500">
                Selecione um time para ver mais detalhes
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}