import { TEXT } from '../constants/text';

export function useText() {
  return TEXT;
}