import { useState, useEffect, useRef } from 'react';
import { Team } from '../types/game';
import { MatchState, TacticalSetup } from '../types/match';
import { SIMULATION_CONFIG } from '../utils/simulation/config';
import { simulateMatchMinute } from '../utils/simulation/engine';

export function useMatchSimulation(homeTeam: Team, awayTeam: Team) {
  const [matchState, setMatchState] = useState<MatchState>({
    minute: 0,
    homeScore: 0,
    awayScore: 0,
    possession: Math.random() > 0.5 ? 'home' : 'away',
    homePossession: 0,
    awayPossession: 0,
    events: [],
    homeStats: {
      shots: 0,
      shotsOnTarget: 0,
      possession: 50,
      passes: 0,
      passAccuracy: 0,
      fouls: 0,
      yellowCards: 0,
      redCards: 0,
      corners: 0,
      offsides: 0,
    },
    awayStats: {
      shots: 0,
      shotsOnTarget: 0,
      possession: 50,
      passes: 0,
      passAccuracy: 0,
      fouls: 0,
      yellowCards: 0,
      redCards: 0,
      corners: 0,
      offsides: 0,
    },
    isHalfTime: false,
  });

  const [isSimulating, setIsSimulating] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const intervalRef = useRef<number | null>(null);

  const [tactics, setTactics] = useState<{
    home: TacticalSetup;
    away: TacticalSetup;
  }>({
    home: {
      formation: '4-3-3',
      style: 'balanced',
      pressing: 'medium',
      mentality: 'balanced'
    },
    away: {
      formation: '4-4-2',
      style: 'balanced',
      pressing: 'medium',
      mentality: 'balanced'
    },
  });

  useEffect(() => {
    return () => {
      if (intervalRef.current !== null) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (isSimulating && !isPaused) {
      intervalRef.current = window.setInterval(() => {
        setMatchState(prevState => {
          if (prevState.minute === 45) {
            setIsPaused(true);
            return { ...prevState, isHalfTime: true };
          }

          if (prevState.minute >= 90) {
            setIsSimulating(false);
            if (intervalRef.current !== null) {
              clearInterval(intervalRef.current);
            }
            return prevState;
          }

          return simulateMatchMinute(
            prevState,
            homeTeam,
            awayTeam,
            tactics.home,
            tactics.away
          );
        });
      }, SIMULATION_CONFIG.simulationSpeed);
    }

    return () => {
      if (intervalRef.current !== null) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isSimulating, isPaused, homeTeam, awayTeam, tactics]);

  const startMatch = () => {
    setIsSimulating(true);
    setIsPaused(false);
  };

  const pauseMatch = () => setIsPaused(true);
  const resumeMatch = () => setIsPaused(false);

  const updateTactics = (team: 'home' | 'away', newTactics: TacticalSetup) => {
    setTactics(prev => ({
      ...prev,
      [team]: newTactics,
    }));
  };

  const makeSubstitution = (
    team: 'home' | 'away',
    playerOutId: string,
    playerInId: string
  ) => {
    // Implement substitution logic
  };

  return {
    matchState,
    isSimulating,
    isPaused,
    startMatch,
    pauseMatch,
    resumeMatch,
    updateTactics,
    makeSubstitution,
  };
}