import { ptBR } from '../i18n/pt-BR';

export function useTranslation() {
  const t = (key: string) => {
    const keys = key.split('.');
    let value: any = ptBR;
    
    for (const k of keys) {
      if (value[k] === undefined) {
        console.warn(`Tradução não encontrada para: ${key}`);
        return key;
      }
      value = value[k];
    }
    
    return value;
  };

  return { t };
}