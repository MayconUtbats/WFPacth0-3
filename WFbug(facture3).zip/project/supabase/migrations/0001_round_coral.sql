/*
  # Initial Schema for World Manager

  1. New Tables
    - teams
      - Basic team info and configuration
    - players
      - Player details and attributes  
    - matches
      - Match records and results
    - competitions
      - League and tournament data
    - youth_academy
      - Youth development system
    - finances
      - Financial transactions and budgets
    - stadiums
      - Stadium info and facilities

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Teams table
CREATE TABLE IF NOT EXISTS teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  short_name varchar(3) NOT NULL,
  country text NOT NULL,
  league text NOT NULL,
  division integer NOT NULL,
  founded integer NOT NULL,
  colors jsonb NOT NULL DEFAULT '{"primary": "#000000", "secondary": "#ffffff", "accent": "#cccccc"}',
  logo jsonb NOT NULL DEFAULT '{"shape": "shield", "icon": "star"}',
  budget bigint NOT NULL DEFAULT 1000000,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

-- Players table
CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid REFERENCES teams(id),
  name text NOT NULL,
  position text NOT NULL,
  age integer NOT NULL,
  rating integer NOT NULL,
  potential integer,
  stamina integer NOT NULL,
  salary integer NOT NULL,
  attributes jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Matches table
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id uuid NOT NULL,
  home_team_id uuid REFERENCES teams(id),
  away_team_id uuid REFERENCES teams(id),
  date timestamptz NOT NULL,
  result jsonb,
  events jsonb[] DEFAULT array[]::jsonb[],
  stats jsonb,
  created_at timestamptz DEFAULT now()
);

-- Competitions table
CREATE TABLE IF NOT EXISTS competitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  season integer NOT NULL,
  teams jsonb NOT NULL DEFAULT '[]',
  schedule jsonb NOT NULL DEFAULT '{}',
  standings jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Youth Academy table
CREATE TABLE IF NOT EXISTS youth_academy (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid REFERENCES teams(id),
  level integer NOT NULL DEFAULT 1,
  max_players integer NOT NULL DEFAULT 5,
  monthly_fee integer NOT NULL DEFAULT 50000,
  facilities jsonb NOT NULL DEFAULT '{"training": 1, "scouting": 1, "education": 1, "medical": 1}',
  players jsonb[] DEFAULT array[]::jsonb[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Finances table
CREATE TABLE IF NOT EXISTS finances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid REFERENCES teams(id),
  type text NOT NULL,
  amount bigint NOT NULL,
  category text NOT NULL,
  description text,
  date timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Stadiums table
CREATE TABLE IF NOT EXISTS stadiums (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid REFERENCES teams(id),
  name text NOT NULL,
  capacity integer NOT NULL DEFAULT 5000,
  ticket_price integer NOT NULL DEFAULT 20,
  maintenance_level integer NOT NULL DEFAULT 100,
  facilities jsonb NOT NULL DEFAULT '{"parking": 1, "shops": 1, "food": 1, "vip": 1}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE youth_academy ENABLE ROW LEVEL SECURITY;
ALTER TABLE finances ENABLE ROW LEVEL SECURITY;
ALTER TABLE stadiums ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own team data"
  ON teams FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can read players from their team"
  ON players FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM teams 
    WHERE teams.id = players.team_id 
    AND teams.user_id = auth.uid()
  ));

CREATE POLICY "Users can read matches involving their team"
  ON matches FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM teams 
    WHERE teams.user_id = auth.uid() 
    AND (teams.id = matches.home_team_id OR teams.id = matches.away_team_id)
  ));

CREATE POLICY "Users can read competitions their team is in"
  ON competitions FOR SELECT
  TO authenticated
  USING (teams::jsonb ? auth.uid());

CREATE POLICY "Users can read own youth academy"
  ON youth_academy FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM teams 
    WHERE teams.id = youth_academy.team_id 
    AND teams.user_id = auth.uid()
  ));

CREATE POLICY "Users can read own finances"
  ON finances FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM teams 
    WHERE teams.id = finances.team_id 
    AND teams.user_id = auth.uid()
  ));

CREATE POLICY "Users can read own stadium"
  ON stadiums FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM teams 
    WHERE teams.id = stadiums.team_id 
    AND teams.user_id = auth.uid()
  ));